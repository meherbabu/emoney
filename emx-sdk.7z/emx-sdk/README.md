## Introduction 

This component allows for audit messages to be published by Emoney Integration Service 