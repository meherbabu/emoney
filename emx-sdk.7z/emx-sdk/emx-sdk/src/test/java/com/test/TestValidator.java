package com.test;

import java.io.ByteArrayInputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

public class TestValidator {

	@Autowired
	JsonValidator validator;

	/**
	 * 
	 * @param jsonStream
	 * @throws Exception
	 */
	public void testJsonValidator(String jsonStream) throws Exception {

		String templateId = "sample-mapping";
		String rootTemplate = "root-template";

		List<ErrorBean> errors = validator.validate(templateId, rootTemplate,
				new ByteArrayInputStream(jsonStream.getBytes()));

		for (ErrorBean errorBean : errors) {
			
			System.out.println(errorBean.getMessage());

		}

	}

}
