package com.integration.exception;

import java.util.List;

import com.integration.bean.common.IntegrationError;

/**
 * for HTTP BAD_RESYUQ errors
 */
public class DataValidationException extends AbstractIntegrationException {


    public DataValidationException(String s) {
        super(s);
    }

    public DataValidationException(List<IntegrationError> integrationErrors) {
        super(integrationErrors);
    }

    public DataValidationException(IntegrationError integrationError) {
        super(integrationError);
    }
    
    @Override
    public String getMessage() {
    	StringBuffer buffer = new StringBuffer();
    	if ( integrationErrors != null && !integrationErrors.isEmpty())
    	{
    		integrationErrors.forEach(k->{
    			buffer.append(" [").append(k.getErrorCode()).append("] ");
    			buffer.append(k.getErrorDesc()).append(" **** ");
    		});
    	}
    	return buffer.toString();
    }
}