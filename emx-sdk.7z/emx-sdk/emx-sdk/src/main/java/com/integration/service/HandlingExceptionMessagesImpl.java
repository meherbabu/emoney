package com.integration.service;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.integration.bean.common.ExchangeExceptionMessageBean;
import com.integration.bean.common.SourceSystem;
import com.integration.exception.SendToExchangeException;

@Service
public class HandlingExceptionMessagesImpl implements HandlingExceptionMessages {

	private Log logger = LoggerUtil.getLog(this);

	@Value("${mq.error.handling.exchange}")
	private String exchange;

	@Value("${mq.error.handling.routingkey}")
	private String routingkey;
	
	@Value("${mq.error.handling.persistence: true}")
	private boolean isPersistent;

	@Value("application/xml")
	private String contextType;

	private ApplicationContext appContext;

	private MessageSender messageSender;

	private JsonUtility jsonUtility;

	public HandlingExceptionMessagesImpl(MessageSender messageSender, ApplicationContext appContext,
			JsonUtility jsonUtility) {
		this.messageSender = messageSender;
		this.appContext = appContext;
		this.jsonUtility = jsonUtility;
	}

	/**
	 * 
	 * @param destination
	 * @param exception
	 */
	private void handleMessage(ExchangeExceptionMessageBean exception) {
		String finalMessage = "";
		try {
			if (exception == null) {
				logger.debug("SendToExchangeException is null");
				return;
			}

			finalMessage = buildJsonMessage(exception);
			logger.debug("finalMessage " + finalMessage);

			messageSender.send(exchange, routingkey, isPersistent, finalMessage);

		} catch (Exception e) {
			logger.error("--------------------------------------------------------------\n\n");
			logger.error("Exception in HandlingExceptionMessagesImpl.handleMessage\n\n" + finalMessage);
			logger.error("--------------------------------------------------------------");
			logger.error(" Exception in HandlingExceptionMessagesImpl.handleMessage", e);
		}
	}

	/**
	 * 
	 * @param exc
	 * @param source
	 * @param url
	 * @param method
	 * @param headersMap
	 * @param message
	 * @param requestParamsValues
	 */
	@Override
	public void processException(SourceSystem sourceSystem, SendToExchangeException exc, String source, String url,
			HttpMethod method, Map<String, String> headersMap, String message,
			Map<String, Object> requestParamsValues) {
		try {

			ExchangeExceptionMessageBean bean = (ExchangeExceptionMessageBean) appContext.getBean("exceptionMsgBean");
			bean.setSourceSystem(String.valueOf(sourceSystem));
			bean.setSource(source);
			bean.setDestination(url);
			bean.setMethod(method);
			bean.setHeaders(headersMap);
			bean.setPayload(message);
			bean.setRequestParamsValues(requestParamsValues);
			bean.setErrorCode("" + exc.getStatusCode());
			bean.setErrorMessage(exc.getMessage());
			handleMessage(bean);

		} catch (Exception e) {
			logger.error("Exception processException ", e);
		}
	}

	@Override
	public void processException(SourceSystem sourceSystem, SendToExchangeException exc, String source,
			String message) {
		processException(sourceSystem, exc, source, null, null, null, message, null);

	}

	/**
	 * 
	 * @param message
	 * @param exMsgBean
	 * @returnF
	 */
	private String buildMessage(ExchangeExceptionMessageBean exMsgBean) throws Exception {

		String value = "";

		try {
			XmlMapper xmlMapper = new XmlMapper();
			value = xmlMapper.writeValueAsString(exMsgBean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}
		return value;
	}

	/**
	 * 
	 * @param message
	 * @param exMsgBean
	 * @returnF
	 */
	private String buildJsonMessage(ExchangeExceptionMessageBean exMsgBean) throws Exception {

		String value = "";
		final String  placeHolder="#placeHolder#";

		try {
			String payLoad = exMsgBean.getPayload();
			exMsgBean.setPayload(placeHolder);
			value = jsonUtility.getJsonStringFromObject(exMsgBean);
			if (value != null && payLoad != null) {
				value = value.replaceFirst("\"#placeHolder#\"", payLoad );
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}
		return value;
	}

	@Override
	public void processException(SourceSystem sourceSystem, String url, HttpMethod method, String errorCode,
			String errorMessage, String source, String messagePayload) {
		processException(sourceSystem, null, source, url, method, null, messagePayload, null, errorCode, errorMessage);

	}

	public void processException(SourceSystem sourceSystem, SendToExchangeException exc, String source, String url,
			HttpMethod method, Map<String, String> headersMap, String message, Map<String, Object> requestParamsValues,
			String errorCode, String errorMessage) {
		try {

			ExchangeExceptionMessageBean bean = (ExchangeExceptionMessageBean) appContext.getBean("exceptionMsgBean");
			bean.setSourceSystem(String.valueOf(sourceSystem));
			bean.setSource(source);
			bean.setDestination(url);
			bean.setMethod(method);
			bean.setHeaders(headersMap);
			bean.setPayload(message);
			bean.setRequestParamsValues(requestParamsValues);
			bean.setErrorCode("" + errorCode);
			bean.setErrorMessage(errorMessage);
			handleMessage(bean);
		} catch (Exception e) {
			logger.error("Exception processException ", e);
		}
	}

}
