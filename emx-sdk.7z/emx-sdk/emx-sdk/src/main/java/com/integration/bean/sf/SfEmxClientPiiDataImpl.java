package com.integration.bean.sf;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.PiiDataLog;
@Component
public class SfEmxClientPiiDataImpl implements  PiiDataLog {
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("ownerId")
	private String ownerId;
	
	@JsonProperty("eMoneyId")
	private String eMoneyId;
	
 public void setPiiData(String id, String ownerId, String eMoneyId) {
	 this.seteMoneyId(eMoneyId);
	 this.setownerId(ownerId);
	 this.setId(id);
 }
	
  public String getId() {
         return id;
    }


  public void setId(String id) {
        this.id = id;
    }
 
  public String getownerId() {
        return ownerId;
   }

  
  public void setownerId(String ownerId) {
       this.ownerId = ownerId;
   }
 
  public String geteMoneyId() {
       return eMoneyId;
  }


  public void seteMoneyId(String eMoneyId) {
      this.eMoneyId = eMoneyId;
  }
	
 
	@Override
	public String logPiiData() {
    return "EmxClientData{" +
				    "id='" + id + '\'' +
				    ", ownerId='" + ownerId+ '\'' +
				    ", emoneyId=" + eMoneyId +
				    '}';

	}

}
