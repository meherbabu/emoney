package com.integration.bean.sf;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.PiiDataLog;
@Component
public class SfEmxTasksPiiDataImpl implements PiiDataLog{

	  @JsonProperty("clientId")
	  private String clientId;
	
	  @JsonProperty("assignedTo")
	  private String assignedTo;
	
	  public void setPiiData(String clientId, String assignedTo) {
		  this.setclientId(clientId);
		  this.setassignedTo(assignedTo);
	  }
	  
	  @JsonProperty("clientId")
	  public String getclientId() {
	       return clientId;
	  }

	  @JsonProperty("clientId")
	  public void setclientId(String clientId) {
	      this.clientId= clientId;
	  }
		
	  @JsonProperty("assignedTo")
	  public String getassignedTo() {
	       return assignedTo;
	  }

	  @JsonProperty("assignedTo")
	  public void setassignedTo(String assignedTo) {
	      this.assignedTo = assignedTo;
	  }

	@Override
	public String logPiiData() {

    return "EmxTask{" +
		    "clientId='" + clientId + '\'' +
		    ", assignedTo='" + assignedTo+ '\'' +
		    '}';

	}
	
}
