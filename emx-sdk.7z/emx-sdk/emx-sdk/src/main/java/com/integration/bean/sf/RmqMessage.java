package com.integration.bean.sf;

public interface RmqMessage {

}
