package com.integration.model;

//@Entity
public class EMoneyOffice {

    SfOrganization sfOrganization ;

}
