package com.integration.bean.emx;
import java.io.Serializable;
import java.util.List;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.integration.bean.sf.RmqMessage;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "id",
        "userId",
        "factId",
        "lastUpdatedBy",
        "lastUpdated",
        "text",
        "links",
        "orgId",
        "noteId"
})
public class EmxNotesResponse implements Serializable,RmqMessage {

    @JsonProperty("id")
    private String id;
    @JsonProperty("userId")
    private String userId;
    @JsonProperty("factId")
    private Object factId;
    @JsonProperty("lastUpdatedBy")
    private String lastUpdatedBy;
    @JsonProperty("lastUpdated")
    private String lastUpdated;
    @JsonProperty("text")
    private String text;
    @JsonProperty("noteId")
    private String sfNoteId;

    @JsonProperty("orgId")
    private String orgId;

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @JsonProperty("links")
    @Valid
    private List<Link> links = null;

    private final static long serialVersionUID = 3424240356974542215L;

    @JsonProperty("id")
    public String getId() {
        return id;
    }
    @JsonProperty("orgId")
    public String getOrgId() {
        return orgId;
    }
    @JsonProperty("orgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("noteId")
    public String getSfNoteId() {
        return sfNoteId;
    }
    @JsonProperty("noteId")
    public void setSfNoteId(String sfNoteId) {
        this.sfNoteId = sfNoteId;
    }

    @JsonProperty("userId")
    public String getUserId() {
        return userId;
    }

    @JsonProperty("userId")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    @JsonProperty("factId")
    public Object getFactId() {
        return factId;
    }

    @JsonProperty("factId")
    public void setFactId(Object factId) {
        this.factId = factId;
    }

    @JsonProperty("lastUpdatedBy")
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    @JsonProperty("lastUpdatedBy")
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    @JsonProperty("lastUpdated")
    public String getLastUpdated() {
        return lastUpdated;
    }

    @JsonProperty("lastUpdated")
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @JsonProperty("text")
    public String getText() {
        return text;
    }

    @JsonProperty("text")
    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "EMoneyNotesResponse{" +
                "id='" + id + '\'' +
                ", userId='" + userId + '\'' +
                ", factId=" + factId +
                ", lastUpdatedBy='" + lastUpdatedBy + '\'' +
                ", lastUpdated='" + lastUpdated + '\'' +
                ", text='" + text + '\'' +
                ", sfNoteId='" + sfNoteId + '\'' +
                ", orgId='" + orgId + '\'' +
                ", links=" + links +
                '}';
    }
}