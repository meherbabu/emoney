package com.integration.bean.common;

public enum EnumGender {
MALE,
FEMALE,
NULL
}
