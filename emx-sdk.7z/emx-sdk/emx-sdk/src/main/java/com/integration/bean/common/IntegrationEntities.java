package com.integration.bean.common;

public enum IntegrationEntities {
    CLIENT,
    ALERT,
    NOTE,
    TASK,
    CLIENT_ID,
    ANALYTICS
}
