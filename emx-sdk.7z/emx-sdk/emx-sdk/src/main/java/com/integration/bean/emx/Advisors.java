package com.integration.bean.emx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.List;

@JsonSerialize
public class Advisors implements Serializable {
    @JsonProperty("totalUsers")
    private String totalUsers;
   @JsonProperty("users")
  private List<User> users;
    @JsonProperty("totalUsers")
    public String getTotalUsers() {
        return totalUsers;
    }
    @JsonProperty("totalUsers")
    public void setTotalUsers(String totalUsers) {
        this.totalUsers = totalUsers;
    }
    @JsonProperty("users")
    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    @Override
    public String toString() {
        return "Advisors{" +
                "totalUsers='" + totalUsers + '\'' +
                ", users=" + users +
                '}';
    }
}
