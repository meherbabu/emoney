package com.integration.transformation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.integration.bean.common.Client;
import com.integration.bean.common.MessageType;
import com.integration.bean.emx.EmxAddress;
import com.integration.bean.emx.EmxClient;
import com.integration.bean.emx.EmxClientRequest;
import com.integration.bean.emx.EmxJob;
import com.integration.bean.sf.SfClientData;
import com.integration.bean.sf.SfClientRequest;

@Service
public class SFToEMoneyRequest {

	public List<EmxClientRequest> transformObject(SfClientRequest sfClientRequest, MessageType operation) {

		int clientLength = 0;

		List<EmxClientRequest> allRequest = new ArrayList<EmxClientRequest>();

		EmxClientRequest eMoneyRequest = null;

		EmxClient eMoneyClient = null;
		EmxClient eMoneySpouse = null;

		EmxJob eMoneyClientJob = null;
		EmxJob EmoneySpouseJob = null;

		EmxAddress address = null;
		EmxAddress clientAddress = null;
		EmxAddress spouseAddress = null;

		clientLength = sfClientRequest.getClients().length;

		for (int term = 0; term < clientLength; term++) {
			SfClientData sfClientData = sfClientRequest.getClients()[term];
			eMoneyRequest = new EmxClientRequest();

			/********** Global Address ******************/
			address = new EmxAddress();
			splitSFAddress(sfClientData.getAddress1(), address);
			address.setCity(sfClientData.getCity());
			address.setState(sfClientData.getState());
			address.setPostalCode(sfClientData.getPostalCode());
			/********** Global Address ******************/

			/********** Client Job Address ******************/
			clientAddress = new EmxAddress();
			clientAddress = this.transformAddressClient(sfClientData.getClient());
			/********** Client Job Address ******************/

			/********** Spouse Job Address ******************/
			spouseAddress = new EmxAddress();
			spouseAddress = this.transformAddressClient(sfClientData.getSpouse());

			/********** Spouse Job Address ******************/

			eMoneyClientJob = new EmxJob();
			eMoneyClientJob.setCompanyName(sfClientData.getClient().getCompanyName());
			eMoneyClientJob.setJobTitle(sfClientData.getClient().getJobTitle());
			eMoneyClientJob.setBusinessEmail(sfClientData.getClient().getBusinessEmail());
			eMoneyClientJob.setBusinessPhone(sfClientData.getClient().getBusinessPhone());
			eMoneyClientJob.setBusinessFax(sfClientData.getClient().getBusinessFax());

			eMoneyClientJob.setPreviousEmployerName(sfClientData.getClient().getPreviousEmployerName());
			eMoneyClientJob.setPreviousJobTitle(sfClientData.getClient().getPreviousJobTitle());

			String yearsEmployedTemp = String.valueOf(sfClientData.getClient().getYearsEmployed());
			String yearsEmpValue = this.getNumericValue(yearsEmployedTemp);
			eMoneyClientJob.setYearsEmployed(yearsEmpValue);

			String previousYearsEmployedTemp = String.valueOf(sfClientData.getClient().getPreviousYearsEmployed());
			String previousYearsEmpValue = this.getNumericValue(previousYearsEmployedTemp);
			eMoneyClientJob.setPreviousYearsEmployed(previousYearsEmpValue);

			eMoneyClientJob.setAddress(clientAddress);

			eMoneyClient = new EmxClient();
			eMoneyClient.setFirstName(sfClientData.getClient().getFirstName());
			eMoneyClient.setLastName(sfClientData.getClient().getLastName());
			eMoneyClient.setDateOfBirth(sfClientData.getClient().getDateOfBirth());
			eMoneyClient.setGender(sfClientData.getClient().getGender());
			eMoneyClient.setSpecialNeeds(sfClientData.getClient().isSpecialNeeds());
			eMoneyClient.setInGoodHealth(sfClientData.getClient().isInGoodHealth());
			eMoneyClient.setPreviousMarriages(sfClientData.getClient().isPreviousMarriages());
			eMoneyClient.setCitizenship(sfClientData.getClient().getCitizenship());
			eMoneyClient.setEmail(sfClientData.getClient().getEmail());
			eMoneyClient.setCellPhone(sfClientData.getClient().getCellPhone());
			eMoneyClient.setJob(eMoneyClientJob);

			if (sfClientData.getSpouse() != null) {
				EmoneySpouseJob = new EmxJob();
				EmoneySpouseJob.setCompanyName(sfClientData.getSpouse().getCompanyName());
				EmoneySpouseJob.setJobTitle(sfClientData.getSpouse().getJobTitle());
				EmoneySpouseJob.setBusinessEmail(sfClientData.getSpouse().getBusinessEmail());
				EmoneySpouseJob.setBusinessPhone(sfClientData.getSpouse().getBusinessPhone());
				EmoneySpouseJob.setBusinessFax(sfClientData.getSpouse().getBusinessFax());

				String yearsEmployedSpouceTemp = String.valueOf(sfClientData.getSpouse().getYearsEmployed());
				String yearsEmpSpouceValue = this.getNumericValue(yearsEmployedSpouceTemp);
				EmoneySpouseJob.setYearsEmployed(yearsEmpSpouceValue);

				String previousYearsEmployedSpouceTemp = String
						.valueOf(sfClientData.getSpouse().getPreviousYearsEmployed());
				String previousYearsEmpSpouceValue = this.getNumericValue(previousYearsEmployedSpouceTemp);
				EmoneySpouseJob.setPreviousYearsEmployed(previousYearsEmpSpouceValue);

				EmoneySpouseJob.setPreviousEmployerName(sfClientData.getSpouse().getPreviousEmployerName());
				EmoneySpouseJob.setPreviousJobTitle(sfClientData.getSpouse().getPreviousJobTitle());
				EmoneySpouseJob.setAddress(spouseAddress);

				eMoneySpouse = new EmxClient();
				eMoneySpouse.setFirstName(sfClientData.getSpouse().getFirstName());
				eMoneySpouse.setLastName(sfClientData.getSpouse().getLastName());
				eMoneySpouse.setDateOfBirth(sfClientData.getSpouse().getDateOfBirth());
				eMoneySpouse.setGender(sfClientData.getSpouse().getGender());
				eMoneySpouse.setSpecialNeeds(sfClientData.getSpouse().isSpecialNeeds());
				eMoneySpouse.setInGoodHealth(sfClientData.getSpouse().isInGoodHealth());
				eMoneySpouse.setPreviousMarriages(sfClientData.getSpouse().isPreviousMarriages());
				eMoneySpouse.setCitizenship(sfClientData.getSpouse().getCitizenship());
				eMoneySpouse.setEmail(sfClientData.getSpouse().getEmail());
				eMoneySpouse.setCellPhone(sfClientData.getSpouse().getCellPhone());
				eMoneySpouse.setJob(EmoneySpouseJob);
			}
			if (operation == MessageType.CREATE) {
				eMoneyRequest.setId(sfClientData.getId());
			} else if (operation == MessageType.UPDATE) {
				eMoneyRequest.setId(sfClientData.geteMoneyId());
			} else {
				eMoneyRequest.setId(sfClientData.getId());
			}
			eMoneyRequest.setClient(eMoneyClient);
			eMoneyRequest.setSpouse(eMoneySpouse);
			eMoneyRequest.setAddress(address);
			eMoneyRequest.setHomePhone(sfClientData.getHomePhone());
			eMoneyRequest.setFax(sfClientData.getFax());
			eMoneyRequest.setMaritalStatus(sfClientData.getMaritalStatus());
			eMoneyRequest.setOwnerId(sfClientData.getOwnerId());
			eMoneyRequest.setBasePlanId(sfClientData.getBasePlanId());

			allRequest.add(eMoneyRequest);

		}
		return allRequest;

	}

	private List<String> getEMoneyAddresses(String address) {
		String[] arr = new String[2];
		if (StringUtils.isNotEmpty(address)) {
			if (address.contains("\\r\\n")) {
				arr = address.split("\\\\r\\\\n");
			} else if (address.contains("\\n")) {
				arr = address.split("\\\\n");
			}
		}
		return Arrays.<String>asList(arr);
	}

	private String getNumericValue(String yearsEmployed) {
		if (yearsEmployed != null) {
			if (yearsEmployed.trim() != "") {
				if (yearsEmployed.equals("null")) {
					return "0";
				} else {
					return yearsEmployed;
				}
			} else {
				return "0";
			}
		} else {
			return "0";
		}
	}

	/**
	 * 
	 * @param sfAdd1
	 * @return
	 */
	public EmxAddress transformAddressClient(Client sfClientorSpouceObj) {
		EmxAddress emoneyAddress = new EmxAddress();
		if (sfClientorSpouceObj != null) {
			splitSFAddress(sfClientorSpouceObj.getJobAddress1(), emoneyAddress);
			emoneyAddress.setCity(sfClientorSpouceObj.getJobCity());
			emoneyAddress.setState(sfClientorSpouceObj.getJobState());
			emoneyAddress.setPostalCode(sfClientorSpouceObj.getJobPostalCode());
		}
		return emoneyAddress;
	}

	private void splitSFAddress(final String address, final EmxAddress emoneyAddress) {
		List<String> addressesList = getEMoneyAddresses(address);
		if (addressesList.size() > 0) {
			emoneyAddress.setAddress1(addressesList.get(0));
			if (addressesList.size() > 1) {
				emoneyAddress.setAddress2(addressesList.get(1));
			}
		} else {
			emoneyAddress.setAddress1(address);
		}
	}

}
