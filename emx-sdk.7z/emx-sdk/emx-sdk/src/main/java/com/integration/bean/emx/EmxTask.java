package com.integration.bean.emx;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "clientId",
        "subject",
        "message",
        "assignedTo",
        "isVisibleToClient",
        "isAssignedToClient",
        "dueDate",
        "reminderDate",
        "completed"
})

public class EmxTask implements Serializable {

    @JsonProperty("clientId")
    private String clientId;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("message")
    private String message;
    @JsonProperty("assignedTo")
    private String assignedTo;
    @JsonProperty("isVisibleToClient")
    private Boolean isVisibleToClient;
    @JsonProperty("isAssignedToClient")
    private Boolean isAssignedToClient;
    @JsonProperty("dueDate")
    private String dueDate;
    @JsonProperty("reminderDate")
    private String reminderDate;
    @JsonProperty("completed")
    private Boolean completed;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -6533306884889491472L;

    @JsonProperty("clientId")
    public String getClientId() {
        return clientId;
    }

    @JsonProperty("clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public EmxTask withClientId(String clientId) {
        this.clientId = clientId;
        return this;
    }

    @JsonProperty("subject")
    public String getSubject() {
        return subject;
    }

    @JsonProperty("subject")
    public void setSubject(String subject) {
        this.subject = subject;
    }

    public EmxTask withSubject(String subject) {
        this.subject = subject;
        return this;
    }

    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    public EmxTask withMessage(String message) {
        this.message = message;
        return this;
    }

    @JsonProperty("assignedTo")
    public String getAssignedTo() {
        return assignedTo;
    }

    @JsonProperty("assignedTo")
    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    public EmxTask withAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
        return this;
    }

    @JsonProperty("isVisibleToClient")
    public Boolean getIsVisibleToClient() {
        return isVisibleToClient;
    }

    @JsonProperty("isVisibleToClient")
    public void setIsVisibleToClient(Boolean isVisibleToClient) {
        this.isVisibleToClient = isVisibleToClient;
    }

    public EmxTask withIsVisibleToClient(Boolean isVisibleToClient) {
        this.isVisibleToClient = isVisibleToClient;
        return this;
    }

    @JsonProperty("isAssignedToClient")
    public Boolean getIsAssignedToClient() {
        return isAssignedToClient;
    }

    @JsonProperty("isAssignedToClient")
    public void setIsAssignedToClient(Boolean isAssignedToClient) {
        this.isAssignedToClient = isAssignedToClient;
    }

    public EmxTask withIsAssignedToClient(Boolean isAssignedToClient) {
        this.isAssignedToClient = isAssignedToClient;
        return this;
    }

    @JsonProperty("dueDate")
    public String getDueDate() {
        return dueDate;
    }

    @JsonProperty("dueDate")
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public EmxTask withDueDate(String dueDate) {
        this.dueDate = dueDate;
        return this;
    }

    @JsonProperty("reminderDate")
    public String getReminderDate() {
        return reminderDate;
    }

    @JsonProperty("reminderDate")
    public void setReminderDate(String reminderDate) {
        this.reminderDate = reminderDate;
    }

    public EmxTask withReminderDate(String reminderDate) {
        this.reminderDate = reminderDate;
        return this;
    }

    @JsonProperty("completed")
    public Boolean getCompleted() {
        return completed;
    }

    @JsonProperty("completed")
    public void setCompleted(Boolean completed) {
        this.completed = completed;
    }

    public EmxTask withCompleted(Boolean completed) {
        this.completed = completed;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EmxTask withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return "EMoneyTask{" +
                "clientId='" + clientId + '\'' +
                ", subject='" + subject + '\'' +
                ", message='" + message + '\'' +
                ", assignedTo='" + assignedTo + '\'' +
                ", isVisibleToClient=" + isVisibleToClient +
                ", isAssignedToClient=" + isAssignedToClient +
                ", dueDate='" + dueDate + '\'' +
                ", reminderDate='" + reminderDate + '\'' +
                ", completed=" + completed +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}