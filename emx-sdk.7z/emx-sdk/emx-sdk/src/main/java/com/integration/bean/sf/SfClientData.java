package com.integration.bean.sf;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.common.Client;
import com.integration.bean.common.Metadata;

import io.swagger.annotations.ApiModel;

@JsonSerialize
@ApiModel(description = "Sample SFClientRequest Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
public class SfClientData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1581945807582990347L;
	
	//@NotNull(message="Metadata cannotbe null")
	//@Valid
	@JsonProperty("metadata")
	private Metadata metadata;
	
	//@NotNull(message="MessageID cannotbe null")
	@JsonProperty("messageID")
	private String messageID;
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("eMoneyId")
	private String eMoneyId;
	
	//@Size(max = 100)
	@JsonProperty("address1")
	private String address1;
	
	//@Size( max = 100)
/*	@JsonProperty("address2")
	private String address2;*/
	
	//@Size(max = 50)
	@JsonProperty("city")
	private String city;
	
	//@Size(max = 5)	
	@JsonProperty("postalCode")
	//@Pattern(regexp = "^[0-9]{5}$", message="PostalCode must be number only and 5 digits")
	private String postalCode;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("basePlanId")
	private String basePlanId;
	@JsonProperty("ownerId")
	private String ownerId ;
	
	//@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message="homephone must be 1 to 9 numbers only and spl charecters (, - and x) are allowed")
	//@Size(max = 19)
	@JsonProperty("homePhone")
	private String homePhone;
	
	//@Size(max = 19)
	@JsonProperty("fax")
	//@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message="Fax must be 1 to 9 numbers only and spl charecters (, - and x) are allowed")
	private String fax;

	@JsonProperty("maritalStatus")
	private String maritalStatus;
	
	//@NotNull(message="Client cannotbe null")
	//@Valid
	@JsonProperty("client")
	private Client client;
	
	//@NotNull(message="spouse cannotbe null")
	//@Valid
	@JsonProperty("spouse")
	private Client spouse;

	//@Valid
	//@ApiModelProperty(required = true, value = "The request message must contain Metadata.It cannot be null and empty")
	public Metadata getMetadata() {
	return metadata;
	}

	public void setMetadata(Metadata metadata) {
	this.metadata = metadata;
	}
	
	//@ApiModelProperty(required = true, value = "The request message must contain MessageID.It cannot be null and empty")
	public String getMessageID() {
	return messageID;
	}
	
	public void setMessageID(String messageID) {
	this.messageID = messageID;
	}

	public String getId() {
	return id;
	}

	public void setId(String id) {
	this.id = id;
	}

	public String geteMoneyId() {
		return eMoneyId;
	}

	public void seteMoneyId(String eMoneyId) {
		this.eMoneyId = eMoneyId;
	}
	
	public String getAddress1() {
	return address1;
	}

	public void setAddress1(String address1) {
	this.address1 = address1;
	}

/*	public String getAddress2() {
	return address2;
	}

	public void setAddress2(String address2) {
	this.address2 = address2;
	}*/

	public String getCity() {
	return city;
	}

	public void setCity(String city) {
	this.city = city;
	}

	public String getPostalCode() {
	return postalCode;
	}

	public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
	}

	public String getState() {
	return state;
	}

	public void setState(String state) {
	this.state = state;
	}

	public String getBasePlanId() {
	return basePlanId;
	}

	public void setBasePlanId(String basePlanId) {
	this.basePlanId = basePlanId;
	}

	public String getHomePhone() {
	return homePhone;
	}

	public void setHomePhone(String homePhone) {
	this.homePhone = homePhone;
	}

	public String getFax() {
	return fax;
	}

	public void setFax(String fax) {
	this.fax = fax;
	}

	public String getMaritalStatus() {
	return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
	this.maritalStatus = maritalStatus;
	}

	//@Valid
	//@ApiModelProperty(required = true, value = "The request message must contain Client. It cannot be null and empty")
	public Client getClient() {
	return client;
	}

	public void setClient(Client client) {
	this.client = client;
	}

	//@Valid
	//@ApiModelProperty(required = true, value = "The request message must contain Client. It cannot be null and empty")
	public Client getSpouse() {
	return spouse;
	}

	public void setSpouse(Client spouse) {
	this.spouse = spouse;
	}
	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	@Override
	public String toString() {
		return "SfClientData{" +
				"metadata=" + metadata +
				", messageID='" + messageID + '\'' +
				", id='" + id + '\'' +
				", eMoneyId='" + eMoneyId + '\'' +
				", address1='" + address1 + '\'' +
				", city='" + city + '\'' +
				", postalCode='" + postalCode + '\'' +
				", state='" + state + '\'' +
				", basePlanId='" + basePlanId + '\'' +
				", ownerId='" + ownerId + '\'' +
				", homePhone='" + homePhone + '\'' +
				", fax='" + fax + '\'' +
				", maritalStatus='" + maritalStatus + '\'' +
				", client=" + client +
				", spouse=" + spouse +
				'}';
	}
}
