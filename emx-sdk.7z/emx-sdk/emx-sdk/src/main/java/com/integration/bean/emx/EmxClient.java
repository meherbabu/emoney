package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class EmxClient implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7210636391871942519L;

	@NotNull(message = "firstName cannotbe null")
	@Size(min = 1, max = 50)
	@JsonProperty("firstName")
	private String firstName;

	@NotNull(message = "lastName cannotbe null")
	@Size(min = 1, max = 50)
	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("dateOfBirth")
	private String dateOfBirth;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("specialNeeds")
	private boolean specialNeeds;

	@JsonProperty("inGoodHealth")
	private boolean inGoodHealth;

	@JsonProperty("previousMarriages")
	private boolean previousMarriages;

	@JsonProperty("citizenship")
	private String citizenship;

	@Pattern(regexp = "^[A-Za-z0-9._%-]{1,2}+@[A-Za-z0-9.-]{1,2}+\\\\.[a-zA-Z]{1,2}$", message = "email must 2characters@2characters.2characters - ab@cd.ef is acceptable\n" + "@ is necessary")
	@JsonProperty("email")
	private String email;

	@JsonProperty("cellPhone")
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "cellPhone must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	private String cellPhone;

	@NotNull(message="job cannot be Null")
	@Valid
	@JsonProperty("job")
	private EmxJob job;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isSpecialNeeds() {
		return specialNeeds;
	}

	public void setSpecialNeeds(boolean specialNeeds) {
		this.specialNeeds = specialNeeds;
	}

	public boolean isInGoodHealth() {
		return inGoodHealth;
	}

	public void setInGoodHealth(boolean inGoodHealth) {
		this.inGoodHealth = inGoodHealth;
	}

	public boolean isPreviousMarriages() {
		return previousMarriages;
	}

	public void setPreviousMarriages(boolean previousMarriages) {
		this.previousMarriages = previousMarriages;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public EmxJob getJob() {
		return job;
	}

	public void setJob(EmxJob job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "EMoneyClient [firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth
				+ ", gender=" + gender + ", specialNeeds=" + specialNeeds + ", inGoodHealth=" + inGoodHealth
				+ ", previousMarriages=" + previousMarriages + ", citizenship=" + citizenship + ", email=" + email
				+ ", cellPhone=" + cellPhone + ", job=" + job + "]";
	}
}
