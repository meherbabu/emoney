package com.integration.bean.common;

public enum EnumMaritalStatus {
	 SINGLE, MARRIED, SEPARATED, DIVORCED, DOMESTICPARTNERSHIP, WIDOW , WIDOWER
}
