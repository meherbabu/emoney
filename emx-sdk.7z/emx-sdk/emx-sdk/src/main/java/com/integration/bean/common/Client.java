package com.integration.bean.common;

import java.io.Serializable;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Client Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
@JsonSerialize
@Valid
public class Client implements Serializable{
	
	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -465803773152689670L;
	
	//@NotNull(message="firstName cannotbe null")
	//@Size(min = 1, max=50)
	@JsonProperty("firstName")
	private String firstName;
	
	//@NotNull(message="lastName cannotbe null")
	//@Size(min = 1, max=50)
	@JsonProperty("lastName")
	private String lastName;
	
	@JsonProperty("dateOfBirth")
	private String dateOfBirth;
	
	@JsonProperty("gender")
	private String gender;
	
	@JsonProperty("specialNeeds")
	private boolean specialNeeds;
	
	@JsonProperty("inGoodHealth")
	private boolean inGoodHealth;
	
	@JsonProperty("previousMarriages")
	private boolean previousMarriages;
	
	@JsonProperty("citizenship")
	private String citizenship;
	
//	@Pattern(regexp = "^[A-Za-z0-9._%-]{1,2}+@[A-Za-z0-9.-]{1,2}+\\\\.[a-zA-Z]{1,2}$", message = "email must 2characters@2characters.2characters - ab@cd.ef is acceptable\n" + "@ is necessary")
	@JsonProperty("email")
	private String email;
	
	//@Size(max=19)
	@JsonProperty("cellPhone")	
	//@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message="cellphone must be 1 to 9 numbers only and spl charecters (, - and x) are allowed")
	private String cellPhone;
	
	//@Size(max=100)
	@JsonProperty("jobTitle")
	private String jobTitle;
	
	//@Size(max=100)
	@JsonProperty("job.address1")
	private String jobAddress1;
	
	//@Size(max=100)
	@JsonProperty("job.address2")
	private String jobAddress2;
	
	//@Size(max=50)
	@JsonProperty("job.city")
	private String jobCity;
	
	@JsonProperty("job.state")
	private String jobState;
	
	//@Size(max = 5)
	@JsonProperty("job.postalcode")
	//@Pattern(regexp = "^[0-9]{5}$", message="JobPostal must be only number and 5 digits")
	private String jobPostalCode;
	
	
//	@JsonProperty("job")
//	private Job job;
	@JsonProperty("businessEmail")
//	@Pattern(regexp = "^[A-Za-z0-9._%-]{1,2}+@[A-Za-z0-9.-]{1,2}+\\\\.[a-zA-Z]{1,2}$", message = "businessEmail must 2characters@2characters.2characters - ab@cd.ef is acceptable\n" + "@ is necessary")
	private String businessEmail;
	
	//@Size(max = 19)
	@JsonProperty("businessFax")
	//@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message="Fax must be 1 to 9 numbers only and spl charecters (, - and x) are allowed")
	private String businessFax;

	//@Size(max = 19)
	@JsonProperty("businessPhone")
	//@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message="BusinessPhone must be 1 to 9 numbers only and spl charecters (, - and x) are allowed")
	private String businessPhone;
	
	//@Size(max = 100)
	@JsonProperty("companyName")
	private String companyName;
	
	//@Size(max = 100)
	@JsonProperty("previousEmployerName")
	private String previousEmployerName;
	
	//@Size(max = 100)
	@JsonProperty("previousJobTitle")
	private String previousJobTitle;
	
	//@Size(min = 0, max = 100)
	@JsonProperty("previousYearsEmployed")
	private Integer previousYearsEmployed;
	
	//@Size(min = 0, max = 100)
	@JsonProperty("yearsEmployed")
	private Integer yearsEmployed;

	//@ApiModelProperty(required = true, value = "The request message must contain firstName. It cannot be null and empty")
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	//@ApiModelProperty(required = true, value = "The request message must contain lastName. It cannot be null and empty")
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isSpecialNeeds() {
		return specialNeeds;
	}

	public void setSpecialNeeds(boolean specialNeeds) {
		this.specialNeeds = specialNeeds;
	}

	public boolean isInGoodHealth() {
		return inGoodHealth;
	}

	public void setInGoodHealth(boolean inGoodHealth) {
		this.inGoodHealth = inGoodHealth;
	}

	public boolean isPreviousMarriages() {
		return previousMarriages;
	}

	public void setPreviousMarriages(boolean previousMarriages) {
		this.previousMarriages = previousMarriages;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobAddress1() {
		return jobAddress1;
	}

	public void setJobAddress1(String jobAddress1) {
		this.jobAddress1 = jobAddress1;
	}

	public String getJobAddress2() {
		return jobAddress2;
	}

	public void setJobAddress2(String jobAddress2) {
		this.jobAddress2 = jobAddress2;
	}

	public String getJobCity() {
		return jobCity;
	}

	public void setJobcity(String jobCity) {
		this.jobCity = jobCity;
	}

	public String getJobState() {
		return jobState;
	}

	public void setJobState(String jobState) {
		this.jobState = jobState;
	}

	public String getJobPostalCode() {
		return jobPostalCode;
	}

	public void setJobPostalCode(String jobPostalCode) {
		this.jobPostalCode = jobPostalCode;
	}

//	public Job getJob() {
//		return job;
//	}
//
//	public void setJob(Job job) {
//		this.job = job;
//	}

	public String getBusinessEmail() {
		return businessEmail;
	}

	public void setBusinessEmail(String businessEmail) {
		this.businessEmail = businessEmail;
	}

	public String getBusinessFax() {
		return businessFax;
	}

	public void setBusinessFax(String businessFax) {
		this.businessFax = businessFax;
	}

	public String getBusinessPhone() {
		return businessPhone;
	}

	public void setBusinessPhone(String businessPhone) {
		this.businessPhone = businessPhone;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getPreviousEmployerName() {
		return previousEmployerName;
	}

	public void setPreviousEmployerName(String previousEmployerName) {
		this.previousEmployerName = previousEmployerName;
	}

	public String getPreviousJobTitle() {
		return previousJobTitle;
	}

	public void setPreviousJobTitle(String previousJobTitle) {
		this.previousJobTitle = previousJobTitle;
	}

	public Integer getPreviousYearsEmployed() {
		return previousYearsEmployed;
	}

	public void setPreviousYearsEmployed(Integer previousYearsEmployed) {
		this.previousYearsEmployed = previousYearsEmployed;
	}

	public Integer getYearsEmployed() {
		return yearsEmployed;
	}

	public void setYearsEmployed(Integer yearsEmployed) {
		this.yearsEmployed = yearsEmployed;
	}

	@Override
	public String toString() {
		return "Client [firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth
				+ ", gender=" + gender + ", specialNeeds=" + specialNeeds + ", inGoodHealth=" + inGoodHealth
				+ ", previousMarriages=" + previousMarriages + ", citizenship=" + citizenship + ", email=" + email
				+ ", cellPhone=" + cellPhone + ", jobTitle=" + jobTitle + ", businessEmail="
				+ businessEmail + ", businessFax=" + businessFax + ", businessPhone=" + businessPhone + ", companyName="
				+ companyName + ", previousEmployerName=" + previousEmployerName + ", previousJobTitle="
				+ previousJobTitle + ", previousYearsEmployed=" + previousYearsEmployed + ", yearsEmployed="
				+ yearsEmployed + "]";
	}

	
}
