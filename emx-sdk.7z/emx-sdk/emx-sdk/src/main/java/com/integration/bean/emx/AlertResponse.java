package com.integration.bean.emx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.sf.RmqMessage;


import java.io.Serializable;
@JsonSerialize
public class AlertResponse implements Serializable,RmqMessage {

    @JsonProperty("id")
    private String id;
    @JsonProperty("timeStamp")
    private String timeStamp;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("description")
    private String description;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("dismissed")
    private Boolean dismissed;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Boolean getDismissed() {
        return dismissed;
    }

    public void setDismissed(Boolean dismissed) {
        this.dismissed = dismissed;
    }

    @Override
    public String toString() {
        return "AlertResponse{" +
                "id='" + id + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", subject='" + subject + '\'' +
                ", description='" + description + '\'' +
                ", displayName='" + displayName + '\'' +
                ", dismissed=" + dismissed +
                '}';
    }
}


