package com.integration.bean.common;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author dkapa
 * 
 * POJO Class for ErrorData
 * 
 */
@JsonSerialize
public class ErrorData implements  IntegrationError {



	public ErrorData(String errorCode, String errorDesc) {

		this.errorCode = errorCode;
		this.errorDesc = errorDesc;
	}



	public ErrorData() {
	}

	private String errorCode;

	private String errorDesc;

	@Override
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@Override
	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

}
