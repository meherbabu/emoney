package com.integration.bean.sf;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.common.Metadata;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "metadata",
        "task"
})
@JsonSerialize
public class SfTaskWrapper implements Serializable
{

    @JsonProperty("metadata")
    @Valid
    @NotNull(message="Metadata can't be null")
    private Metadata metadata;
    @JsonProperty("task")
    @Valid
    @NotNull(message = "task can't be null")
    private SfTask task;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 6465387818994390918L;

    @JsonProperty("metadata")
    public Metadata getMetadata() {
        return metadata;
    }

    @JsonProperty("metadata")
    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    @JsonProperty("task")
    public SfTask getTask() {
        return task;
    }

    @JsonProperty("task")
    public void setTask(SfTask task) {
        this.task = task;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "SFTaskWrapper{" +
                "metadata=" + metadata +
                ", task=" + task +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}