package com.integration.bean.common;

public enum EnumEventFinalStatus {
	PROCESSING,
	SUCCESS,
	ERROR;	
}
