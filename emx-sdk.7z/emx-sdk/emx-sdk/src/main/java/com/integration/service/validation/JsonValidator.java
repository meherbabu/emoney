package com.integration.service.validation;

import java.io.InputStream;
import java.util.List;

import com.integration.service.validation.beans.ErrorBean;

public interface JsonValidator {

	/**
	 * 
	 * @param input
	 * @return
	 */
	public List<ErrorBean> validate(String id, String templateName, InputStream input) throws Exception;

	/**
	 * 
	 * @param input
	 * @return
	 */
	public List<ErrorBean> validate(String id, InputStream input) throws Exception;

}
