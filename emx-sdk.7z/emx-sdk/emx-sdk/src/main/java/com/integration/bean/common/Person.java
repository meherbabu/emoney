package com.integration.bean.common;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "firstName",
        "lastName",
        "dateOfBirth",
        "gender",
        "specialNeeds",
        "inGoodHealth",
        "previousMarriages",
        "citizenship",
        "email",
        "cellPhone",
        "job"
})
public class Person implements Serializable {

    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("specialNeeds")
    private Boolean specialNeeds;
    @JsonProperty("inGoodHealth")
    private Boolean inGoodHealth;
    @JsonProperty("previousMarriages")
    private Boolean previousMarriages;
    @JsonProperty("citizenship")
    private String citizenship;
    @JsonProperty("email")
    private String email;
    @JsonProperty("cellPhone")
    private String cellPhone;
    @JsonProperty("job")
    private Job job;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 3478632572972989074L;

    /**
     * No args constructor for use in serialization
     */
    public Person() {
    }

    /**
     * @param dateOfBirth
     * @param lastName
     * @param email
     * @param specialNeeds
     * @param cellPhone
     * @param job
     * @param previousMarriages
     * @param gender
     * @param citizenship
     * @param firstName
     * @param inGoodHealth
     */
    public Person(String firstName, String lastName, String dateOfBirth, String gender, Boolean specialNeeds, Boolean inGoodHealth, Boolean previousMarriages, String citizenship, String email, String cellPhone, Job job) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.specialNeeds = specialNeeds;
        this.inGoodHealth = inGoodHealth;
        this.previousMarriages = previousMarriages;
        this.citizenship = citizenship;
        this.email = email;
        this.cellPhone = cellPhone;
        this.job = job;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("specialNeeds")
    public Boolean getSpecialNeeds() {
        return specialNeeds;
    }

    @JsonProperty("specialNeeds")
    public void setSpecialNeeds(Boolean specialNeeds) {
        this.specialNeeds = specialNeeds;
    }

    @JsonProperty("inGoodHealth")
    public Boolean getInGoodHealth() {
        return inGoodHealth;
    }

    @JsonProperty("inGoodHealth")
    public void setInGoodHealth(Boolean inGoodHealth) {
        this.inGoodHealth = inGoodHealth;
    }

    @JsonProperty("previousMarriages")
    public Boolean getPreviousMarriages() {
        return previousMarriages;
    }

    @JsonProperty("previousMarriages")
    public void setPreviousMarriages(Boolean previousMarriages) {
        this.previousMarriages = previousMarriages;
    }

    @JsonProperty("citizenship")
    public String getCitizenship() {
        return citizenship;
    }

    @JsonProperty("citizenship")
    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("cellPhone")
    public String getCellPhone() {
        return cellPhone;
    }

    @JsonProperty("cellPhone")
    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    @JsonProperty("job")
    public Job getJob() {
        return job;
    }

    @JsonProperty("job")
    public void setJob(Job job) {
        this.job = job;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("firstName", firstName).append("lastName", lastName).append("dateOfBirth", dateOfBirth).append("gender", gender).append("specialNeeds", specialNeeds).append("inGoodHealth", inGoodHealth).append("previousMarriages", previousMarriages).append("citizenship", citizenship).append("email", email).append("cellPhone", cellPhone).append("job", job).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dateOfBirth).append(lastName).append(specialNeeds).append(cellPhone).append(job).append(previousMarriages).append(citizenship).append(email).append(additionalProperties).append(gender).append(firstName).append(inGoodHealth).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Person) == false) {
            return false;
        }
        Person rhs = ((Person) other);
        return new EqualsBuilder().append(dateOfBirth, rhs.dateOfBirth).append(lastName, rhs.lastName).append(specialNeeds, rhs.specialNeeds).append(cellPhone, rhs.cellPhone).append(job, rhs.job).append(previousMarriages, rhs.previousMarriages).append(citizenship, rhs.citizenship).append(email, rhs.email).append(additionalProperties, rhs.additionalProperties).append(gender, rhs.gender).append(firstName, rhs.firstName).append(inGoodHealth, rhs.inGoodHealth).isEquals();
    }

}