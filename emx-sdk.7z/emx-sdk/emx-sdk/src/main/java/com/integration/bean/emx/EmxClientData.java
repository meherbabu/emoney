package com.integration.bean.emx;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.common.Metadata;
import com.integration.bean.common.MockClient;

@JsonSerialize
public class EmxClientData implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2633858004422092784L;

	@JsonProperty("metadata")
	private Metadata metadata;
	
	@JsonProperty("messageID")
	private String messageID;
	
	@JsonProperty("eMoneyId")
	private String eMoneyId;
	
	@JsonProperty("address1")
	private String address1;
	
	@JsonProperty("address2")
	private String address2;
	
	@JsonProperty("city")
	private String city;
	
	
	@JsonProperty("postalCode")
	private String postalCode;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("basePlanId")
	private String basePlanId;
	
	@JsonProperty("homePhone")
	private String homePhone;
	
	@JsonProperty("fax")
	private String fax;
	
	@JsonProperty("maritalStatus")
	private String maritalStatus;
	
	@JsonProperty("client")
	private MockClient client;
	
	@JsonProperty("spouse")
	private MockClient spouse;

	public Metadata getMetadata() {
		return metadata;
	}

	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

	public String getMessageID() {
		return messageID;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}
	
	public String geteMoneyId() {
		return eMoneyId;
	}

	public void seteMoneyId(String eMoneyId) {
		this.eMoneyId = eMoneyId;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getBasePlanId() {
		return basePlanId;
	}

	public void setBasePlanId(String basePlanId) {
		this.basePlanId = basePlanId;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public MockClient getClient() {
		return client;
	}

	public void setClient(MockClient client) {
		this.client = client;
	}

	public MockClient getSpouse() {
		return spouse;
	}

	public void setSpouse(MockClient spouse) {
		this.spouse = spouse;
	}

	@Override
	public String toString() {
		return "ClientData [metadata=" + metadata + ", messageID=" + messageID +  ", address1=" + address1
				+ ", address2=" + address2 + ", city=" + city + ", postalCode=" + postalCode + ", state=" + state
				+ ", basePlanId=" + basePlanId + ", homePhone=" + homePhone + ", fax=" + fax + ", maritalStatus="
				+ maritalStatus + ", client=" + client + ", spouse=" + spouse + "]";
	}
}
