package com.integration.service.validation;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.integration.service.LoggerUtil;
import com.integration.service.validation.beans.ErrorBean;
import com.integration.service.validation.beans.PropertyBean;
import com.integration.service.validation.beans.TemplateBean;
import com.integration.service.validation.beans.ValidatorConfigurationBean;
import com.integration.service.validation.beans.VarBean;

/**
 * 
 * @author ldo
 * 
 */
@Component
public class JsonValidatorImpl implements JsonValidator {

	Log log = LoggerUtil.getLog(this);

	
	private static Map<String, ValidatorConfigurationBean> map;
	
	
	@Value("${validator.file.path:classpath:/*.xml}")
	private String resourcePath;
	
	

	private ResourceLoader resourceLoader;
	private ApplicationContext appContext;


	@Autowired
	public JsonValidatorImpl(ResourceLoader resourceLoader,
			ApplicationContext appContext) {
		this.resourceLoader = resourceLoader;
		this.appContext = appContext;
	}

	@PostConstruct
	protected void init() {
		initResources(resourcePath);
	}

	/**
	 * 
	 * @param resourcePath
	 */
	protected void initResources(String resourcePath) {
		try {
			map = new HashMap<String, ValidatorConfigurationBean>();
			XMLInputFactory xMLInputFactory = XMLInputFactory.newFactory();

			Resource[] resources = loadResources(resourcePath);
			Arrays.asList(resources).forEach(resource -> {

				try {
					XMLStreamReader sr = xMLInputFactory.createXMLStreamReader(resource.getInputStream());
					ValidatorConfigurationBean vars = new XmlMapper().readValue(sr, ValidatorConfigurationBean.class);
					sr.close();

					InputStream stream = substituteVariablesInputStream(resource.getInputStream(),
							getMap(vars.getVarBeanList()));

					sr = xMLInputFactory.createXMLStreamReader(stream);
					ValidatorConfigurationBean valid = new XmlMapper().readValue(sr, ValidatorConfigurationBean.class);
					sr.close();
					map.put(valid.getId(), valid);
				} catch (XMLStreamException e) {
					log.error("JsonValidatorImpl.initResources ", e);
				} catch (IOException e) {
					log.error("IOException.initResources ", e);
				}

			});

		} catch (Exception e) {
			log.error("Exception ", e);
		}
	}

	/**
	 * 
	 * @param resourcePath
	 * @return
	 * @throws Exception
	 */
	private Resource[] loadResources(String resourcePath) throws Exception {
		try {
			return ResourcePatternUtils.getResourcePatternResolver(resourceLoader).getResources(resourcePath);
		} catch (IOException e) {
			throw e;
		}

	}

	/**
	 * @return
	 */
	private Map<String, String> getMap(List<VarBean> list) {
		Map<String, String> map = new HashMap<String, String>();
		for (VarBean varBean : list) {
			map.put(varBean.getName(), varBean.getValue());
		}
		return map;
	}

	/**
	 * 
	 * @param template
	 * @param variables
	 * @return
	 */
	private static String substituteVariables(String template, Map<String, String> variables) {
		Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
		Matcher matcher = pattern.matcher(template);
		// StringBuilder cannot be used here because Matcher expects StringBuffer
		StringBuffer buffer = new StringBuffer();
		while (matcher.find()) {
			if (variables.containsKey(matcher.group(1))) {
				String replacement = variables.get(matcher.group(1));
				// quote to work properly with $ and {,} signs
				matcher.appendReplacement(buffer, replacement != null ? Matcher.quoteReplacement(replacement) : "null");
			}
		}
		matcher.appendTail(buffer);
		return buffer.toString();
	}

	/**
	 * 
	 * @param in
	 * @param variables
	 * @return
	 */
	private static InputStream substituteVariablesInputStream(InputStream in, Map<String, String> variables) {

		try {
			BufferedInputStream inputStream = new BufferedInputStream(in);
			int avail = inputStream.available();
			byte[] data = new byte[avail];
			inputStream.read(data);
			inputStream.close();
			String returnValue = substituteVariables(new String(data), variables);
			// System.out.println(returnValue);
			ByteArrayInputStream byteInputStream = new ByteArrayInputStream(returnValue.getBytes());
			return byteInputStream;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<ErrorBean> validate(String id, String templateName, InputStream input) throws JsonValidationException {
		log.info("Start JsonValidatorImpl.validate");
		List<ErrorBean> error = new ArrayList<ErrorBean>();
		try {
			if (input == null || input.available() == 0) {
				throw new JsonValidationException("Message cannot be blank or empty");
			}
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(input);
			TemplateBean bean = getTemplateBean(id, templateName);
			if (bean == null) {
				throw new Exception(
						"Template id [" + id + "] or/and templateName [" + templateName + "] does not exist");
			}
			validate(id, bean, rootNode, error);
		} catch (Exception e) {
			throw new JsonValidationException(e.getMessage(), e);
		} finally {
			log.info("End JsonValidatorImpl.validate");
		}
		return error;
	}

	/**
	 * 
	 * @param bean
	 * @param rootNode
	 * @param error
	 */
	private void validate(String id, TemplateBean bean, JsonNode rootNode, List<ErrorBean> error) {
		List<PropertyBean> list = bean.getPropertyList();

		for (PropertyBean propertyBean : list) {
			String name = propertyBean.getName();

			processTemplateProperty(id, propertyBean, rootNode, error);

			JsonNode value = rootNode.get(name);
			if (value == null) {
				processIsRequiredProperty(propertyBean, rootNode, value, name, error);
				continue;
			}
			
			processEmptyProperty(propertyBean, rootNode, value, name, error);
			processSizeProperty(propertyBean, rootNode, value, name, error);
			processMinProperty(propertyBean, rootNode, value, name, error);
			processMaxProperty(propertyBean, rootNode, value, name, error);
			processMatchPatternProperty(propertyBean, rootNode, value, name, error);
			processIsDateProperty(propertyBean, rootNode, value, name, error);
			processIsContainProperty(propertyBean, rootNode, value, name, error);
			processIsValidProperty(propertyBean, rootNode, value, name, error);

		}
	}
	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processIsValidProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		if (value == null || value.isNull() || StringUtils.isEmpty(value.asText())) {			
			return;
		}
		// not matchPattern Attribute
		if (propertyBean.getIsValid() != null) {
			String component = propertyBean.getIsValid().getComponent();
			String method = propertyBean.getIsValid().getMethod();
			
			boolean valid = false;
			try {
				valid = isValidValue (component, method, value.asText());
				if ( !valid)
				{
					error.add(new ErrorBean(name, " -> '" +value.asText()+"'." +  propertyBean.getIsValid().getMessage()));
				}
			} catch (Exception e) {
				error.add(new ErrorBean(name, "Exception in bean "+component+"."+method+". message-> " +  e.getMessage()));
			}
		}
		
	}

	/**
	 * 
	 * @param component
	 * @param method
	 * @param value
	 * @return
	 */
	private boolean isValidValue(String component, String method, String value) throws Exception {
		try {
			Object bean = appContext.getBean(component);
			Method m = bean.getClass().getMethod(method, String.class);

			// calling method in java using reflection dynamically
			boolean isValid = (boolean) m.invoke(bean, value);

			return isValid;
		} catch (Exception e) {
			log.error("Exception in isValid value ");
			throw e;
		}

	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processIsRequiredProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		// not Empty Attribute
		boolean attribute = (propertyBean.getRequired_() != null
				&& "true".equalsIgnoreCase(propertyBean.getRequired_()));
		if (attribute || propertyBean.getRequired() != null) {

			if (value == null || value.isMissingNode()) {
				String tempMessage = attribute ? null : propertyBean.getRequired().getMessage();
				String message = formatMessage(tempMessage, "is a required property", "");
				error.add(new ErrorBean(name, message));
			}
		}

	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processIsDateProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		if (propertyBean.getIsDate() != null) {

			if (!StringUtils.isEmpty(value.textValue())
					&& !StringUtils.isEmpty(propertyBean.getIsDate().getPattern())) {

				String message = "";

				if (!isValidDate(value.textValue(), propertyBean.getIsDate().getPattern())) {
					message = formatMessage(propertyBean.getIsDate().getMessage(),
							" must be a valid date and in the format of [" + propertyBean.getIsDate().getPattern()
									+ "]",
							value.asText());
					error.add(new ErrorBean(name, message));
				} else {
					// check min and max
					String minValue = propertyBean.getIsDate().getMin();
					if (!StringUtils.isEmpty(minValue)) {
						int compareValue = compareValue(minValue, value, propertyBean, name);
						if (UNKNOWN_VALUE != compareValue && compareValue < 0) {
							message = formatMessage(propertyBean.getIsDate().getMessage(),
									" must be a valid date and in the format of [" + propertyBean.getIsDate().getPattern()
											+ "]",
									value.asText());
							error.add(new ErrorBean(name, message));
						}
					}

					String maxValue = propertyBean.getIsDate().getMax();
					if (!StringUtils.isEmpty(maxValue)) {
						int compareValue = compareValue(maxValue, value, propertyBean, name);
						if (UNKNOWN_VALUE != compareValue && compareValue > 0) {
							message = formatMessage(propertyBean.getIsDate().getMessage(),
									" must be a valid date and in the format of [" + propertyBean.getIsDate().getPattern()
											+ "]",
									value.asText());
							error.add(new ErrorBean(name, message));
						}
					}
				}

			}

		}

	}

	/**
	 * 
	 * @param message
	 * @param defaultMessage
	 * @param nodeName
	 * @param value
	 * @return
	 */
	private String formatMessage(String message, String defaultMessage, String value) {
		StringBuffer buffer = new StringBuffer();
		if (StringUtils.isEmpty(message)) {
			message = defaultMessage;
		}
		buffer.append(message);
		if (!StringUtils.isEmpty(value)) {
			buffer.append(" {").append(value).append("} ");
		}
		return buffer.toString();
	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processIsContainProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		if (value == null || value.isNull() || StringUtils.isEmpty(value.asText())) {
			return;
		}
		if (propertyBean.getIsContain() != null) {

			String matchValues = propertyBean.getIsContain().getValue();

			if (!StringUtils.isEmpty(value.textValue()) && !StringUtils.isEmpty(matchValues)) {

				String compareValue = value.textValue();
				if (!"true".equalsIgnoreCase(propertyBean.getIsContain().getCaseSensitive())) {
					matchValues = matchValues.toUpperCase();
					compareValue = compareValue.toUpperCase();
				}
				if (matchValues.indexOf(compareValue) == -1) {
					String message = formatMessage(propertyBean.getIsContain().getMessage(), " Invalid choice",
							value.asText());

					error.add(new ErrorBean(name, message));

				}

			}

		}

	}

	/**
	 * 
	 * @param givenValue
	 * @param pattern
	 * @return
	 */
	private Date getCompareDate(String givenValue, String pattern) {
		Date finalDate = null;
		try {
			if (givenValue.startsWith("(") && givenValue.endsWith(")")) {
				givenValue = givenValue.substring(1, givenValue.length() - 1);
				String[] givenValues = givenValue.split(",");
				Date myDate = "@todate".equalsIgnoreCase(givenValues[0]) ? Calendar.getInstance().getTime()
						: DateUtils.parseDate(givenValues[0], new String[] { pattern });
				int amount = Integer.parseInt(givenValues[1]);
				finalDate = "Y".equalsIgnoreCase(givenValues[2]) ? DateUtils.addYears(myDate, amount)
						: ("M".equalsIgnoreCase(givenValues[2]) ? DateUtils.addMonths(myDate, amount)
								: DateUtils.addDays(myDate, amount));

			} else {
				finalDate = DateUtils.parseDate(givenValue, new String[] { pattern });
			}

		} catch (Exception e) {
			log.error("Exception in getCompareDate ", e);
			return null;
		}

		return finalDate;
	}

	final static int UNKNOWN_VALUE = -2000;

	/**
	 * 
	 * @param minValue
	 * @param value
	 * @param propertyBean
	 * @param name
	 * @return
	 */
	private int compareValue(String minValue, JsonNode value, PropertyBean propertyBean, String name) {
		int finalValue = UNKNOWN_VALUE;
		try {
			if (!StringUtils.isEmpty(minValue)) {
				Date givenDate = DateUtils.parseDate(value.textValue(),
						new String[] { propertyBean.getIsDate().getPattern() });
				Date minDate = getCompareDate(minValue, propertyBean.getIsDate().getPattern());
				if (minDate != null) {
					finalValue = DateUtils.truncatedCompareTo(givenDate, minDate, Calendar.DAY_OF_MONTH);
				}
			}

		} catch (Exception e) {
			log.error("Exception in compareValue ", e);

		}

		return finalValue;

	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processMatchPatternProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		if (value == null || value.isNull() || StringUtils.isEmpty(value.asText())) {
			return;
		}
		// not matchPattern Attribute
		if (propertyBean.getMatchPattern() != null) {

			if (!StringUtils.isEmpty(value.textValue())
					&& !StringUtils.isEmpty(propertyBean.getMatchPattern().getValue())) {
				if (!value.textValue().matches(propertyBean.getMatchPattern().getValue())) {

					error.add(new ErrorBean(name,
							propertyBean.getMatchPattern().getMessage() + " {" + value.textValue() + "}"));
				}
			}

		}

	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processMaxProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {

		if (value == null || value.isNull() || StringUtils.isEmpty(value.asText())) {
			return;
		}

		if (propertyBean.getMax() != null) {

			if (propertyBean.getMax().getValue() == null || !isNum(propertyBean.getMax().getValue())) {
				error.add(new ErrorBean(name, "value of max in configure file must be an integer"));
				return;
			}

			if (value == null || !value.isNumber()) {
				error.add(new ErrorBean(name, propertyBean.getMax().getMessage()));
				return;
			}
			if (value.intValue() > Integer.parseInt(propertyBean.getMax().getValue())) {
				error.add(new ErrorBean(name, propertyBean.getMax().getMessage()));
			}
		}

	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processMinProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		if (value == null || value.isNull() || StringUtils.isEmpty(value.asText())) {
			return;
		}
		// not min Attribute
		if (propertyBean.getMin() != null) {

			if (propertyBean.getMin().getValue() == null || !isNum(propertyBean.getMin().getValue())) {
				error.add(new ErrorBean(name, "value of min in configure file must be an integer"));
				return;
			}

			if (value == null || !value.isNumber()) {
				error.add(new ErrorBean(name, propertyBean.getMin().getMessage()));
				return;
			}
			if (value.intValue() < Integer.parseInt(propertyBean.getMin().getValue())) {
				error.add(new ErrorBean(name, propertyBean.getMin().getMessage()));
			}
		}
	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processSizeProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		if (value == null || value.isNull() || StringUtils.isEmpty(value.asText())) {
			return;
		}
		// Size Attribute
		if (propertyBean.getSize() != null) {
			if (!StringUtils.isEmpty(propertyBean.getSize().getMin()) && isNum(propertyBean.getSize().getMin())) {
				int min = Integer.parseInt(propertyBean.getSize().getMin());
				if (value.textValue().length() < min) {
					error.add(new ErrorBean(name, propertyBean.getSize().getMessage()));
				}
			}

			if (!StringUtils.isEmpty(propertyBean.getSize().getMax()) && isNum(propertyBean.getSize().getMax())) {
				int max = Integer.parseInt(propertyBean.getSize().getMax());
				if (value.textValue().length() > max) {
					error.add(new ErrorBean(name, propertyBean.getSize().getMessage()));
				}
			}

			// }

		}
	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param value
	 * @param name
	 * @param error
	 */
	private void processEmptyProperty(PropertyBean propertyBean, JsonNode rootNode, JsonNode value, String name,
			List<ErrorBean> error) {
		// not Empty Attribute
		boolean attribute = (propertyBean.getNotEmpty_() != null
				&& "true".equalsIgnoreCase(propertyBean.getNotEmpty_()));
		if (attribute || propertyBean.getNotEmpty() != null) {
			if (value.isValueNode()) {
				if (value.isNull() || (value.isTextual() && StringUtils.isEmpty(value.asText()))) {
					String tempMessage = attribute ? null : propertyBean.getNotEmpty().getMessage();
					String message = formatMessage(tempMessage, "'s value cannot be blank", value.asText());
					error.add(new ErrorBean(name, message));
				}
			}
		}
	}

	/**
	 * 
	 * @param propertyBean
	 * @param rootNode
	 * @param error
	 */
	private void processTemplateProperty(String id, PropertyBean propertyBean, JsonNode rootNode,
			List<ErrorBean> error) {
		// Template Attribute
		if (propertyBean.getTemplate() != null) {
			String templateName = propertyBean.getTemplate();
			TemplateBean tempList = getTemplateBean(id, templateName);
			// make sure template exist and root node exist also.
			if (tempList != null && null != rootNode.get(propertyBean.getName())) {
				// if isList element is true, iterate through the list of nodes
				if (!StringUtils.isEmpty(propertyBean.getIsList())
						&& "true".equalsIgnoreCase(propertyBean.getIsList())) {
					JsonNode node = rootNode.get(propertyBean.getName());
					// if empty attribute exist and equals to false and empty node, throw an error
					if (!StringUtils.isEmpty(propertyBean.getEmpty())
							&& "false".equalsIgnoreCase(propertyBean.getEmpty()) && node.size() == 0) {
						error.add(new ErrorBean(propertyBean.getName(),
								propertyBean.getName() + " cannot be an empty list"));
					}
					for (Iterator<JsonNode> iterator = node.elements(); iterator.hasNext();) {
						validate(id, tempList, iterator.next(), error);

					}
				} else {
					// single node.
					validate(id, tempList, rootNode.get(propertyBean.getName()), error);
				}
			}
		}

	}

	/**
	 * 
	 * @param id
	 * @param templateName
	 * @return
	 */
	private TemplateBean getTemplateBean(String id, String templateName) {

		if (!map.containsKey(id)) {
			log.warn("Template id [" + id + "] doesn't exist");
			return null;
		}
		List<TemplateBean> list = map.get(id).getTemplateBeanList();

		TemplateBean bean = null;
		for (TemplateBean templateBean : list) {
			if (templateBean.getName().equalsIgnoreCase(templateName)) {
				bean = templateBean;
				break;
			}
		}
		if (bean == null) {
			log.info("Template [" + templateName + "] does not exist");
		}

		return bean;

	}

	/**
	 * 
	 * @param strNum
	 * @return
	 */
	private static boolean isNum(String strNum) {
		boolean ret = true;
		try {

			Integer.parseInt(strNum);

		} catch (NumberFormatException e) {
			ret = false;
		}
		return ret;
	}

	/**
	 * 
	 * @param inDate
	 * @param format
	 * @return
	 */
	private static boolean isValidDate(String inDate, String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		dateFormat.setLenient(false);
		try {
			dateFormat.parse(inDate.trim());
		} catch (Exception pe) {
			return false;
		}
		return true;
	}

	@Override
	public List<ErrorBean> validate(String id, InputStream input) throws Exception {
		return validate(id, "RootTemplate", input);
	}

//	public static void main(String[] args) {
//		try {
//			// String pattern =
//			// "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
//
//			// String pattern
//			// ="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
//			String pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@([A-Za-z0-9-]{2,})(\\.[A-Za-z]{2,})$";
//
//			Pattern p = Pattern.compile(
//					"(?:(?:\\r\\n)?[ \\t])*(?:(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*)|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*:(?:(?:\\r\\n)?[ \\t])*(?:(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*)(?:,\\s*(?:(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*|(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)*\\<(?:(?:\\r\\n)?[ \\t])*(?:@(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*(?:,@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*)*:(?:(?:\\r\\n)?[ \\t])*)?(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\"(?:[^\\\"\\r\\\\]|\\\\.|(?:(?:\\r\\n)?[ \\t]))*\"(?:(?:\\r\\n)?[ \\t])*))*@(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*)(?:\\.(?:(?:\\r\\n)?[ \\t])*(?:[^()<>@,;:\\\\\".\\[\\] \\000-\\031]+(?:(?:(?:\\r\\n)?[ \\t])+|\\Z|(?=[\\[\"()<>@,;:\\\\\".\\[\\]]))|\\[([^\\[\\]\\r\\\\]|\\\\.)*\\](?:(?:\\r\\n)?[ \\t])*))*\\>(?:(?:\\r\\n)?[ \\t])*))*)?;\\s*)");
//			String[] values = new String[] { "leerobertdo@yahoo.com", "leerob.ertdo@ya.hoo.com",
//					"leerob1234ertdo@ya.co", "doo@yo.co", "o@y.c", "leerob@ertdo@yahoo.com",
//					"leerobe-090rtdo@ya23hoo.com", "leerobertdo@com"
//
//			};
//
//			for (String string : values) {
//				System.out.println("Match Value " + string + "		" + string.matches(pattern));
//			}
//
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//	}

}
