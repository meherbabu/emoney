package com.integration.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.SfOrgEmxOffMap;

@Transactional
@Repository
public interface SforgEmxoffMapRepository extends JpaRepository<SfOrgEmxOffMap, Long> {
	
    @Query("SELECT p.orgId FROM SfOrgEmxOffMap p WHERE p.emxOffice = :emxOffice")
    public String findOrgId(@Param("emxOffice") String emxOffice);

    @Query("SELECT p.emxOffice FROM SfOrgEmxOffMap p WHERE p.orgId = :orgId")
    public String findEmxOffice(@Param("orgId") String orgId);
    
    @Query("SELECT p FROM SfOrgEmxOffMap p WHERE p.emxOffice = :emxOffice")
    public SfOrgEmxOffMap findSfOrgEmxOffMapByemxOfficeId(@Param("emxOffice") String emxOffice);

    @Query("SELECT p FROM SfOrgEmxOffMap p WHERE p.orgId = :orgId")
    public SfOrgEmxOffMap findSfOrgEmxOffMapByOrgId(@Param("orgId") String orgId);

    @Query("SELECT p.emxOffice FROM SfOrgEmxOffMap p WHERE p.orgId = :orgId")
    public List<String> findEmxOfficeByOrgId(@Param("orgId") String orgId);
    
    @Query("SELECT p.emxOffice FROM SfOrgEmxOffMap p WHERE p.orgId = :orgId and p.isActive = 'true' ")
    public List<String> findActiveEmxOfficesByOrgId(@Param("orgId") String orgId);
    
    
    
    public List<SfOrgEmxOffMap> findAllByOrderByOrgId();
    
    public SfOrgEmxOffMap findByOrgIdAndEmxOffice (String orgId, String emxOffice);
    

    public boolean existsByEmxOffice (String emxOffice);
    
    public boolean existsByOrgId (String byOrgId);
    
   

}
