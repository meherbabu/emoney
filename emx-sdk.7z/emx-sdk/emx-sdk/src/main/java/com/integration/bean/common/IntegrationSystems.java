package com.integration.bean.common;

public enum IntegrationSystems {

    SALESFORCE,
    EMX,
    RMQ
}
