package com.integration.bean.common;

public enum SourceSystem {
	SALESFORCE,
	EMONEY

}
