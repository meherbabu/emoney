package com.integration.bean.common;

import java.io.Serializable;
import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.emx.EmxClientData;

@JsonSerialize
public class Clients implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6839480397130943635L;
	
	@JsonIgnore
	private EmxClientData[] data;

	public EmxClientData[] getData() {
		return data;
	}

	public void setData(EmxClientData[] data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Clients [data=" + Arrays.toString(data) + "]";
	}
}
