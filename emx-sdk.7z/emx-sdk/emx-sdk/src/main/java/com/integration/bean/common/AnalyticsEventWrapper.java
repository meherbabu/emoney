package com.integration.bean.common;

import java.sql.Timestamp;

public class AnalyticsEventWrapper extends AnalyticsEvent {

	
	public AnalyticsEventWrapper() {
		super();
	}
	public AnalyticsEventWrapper setTrackingIdValue(String value) {
		super.setTrackingId(value);
		return this;
	}

	public AnalyticsEventWrapper setClientIdValue(String value) {
		super.setClientId(value);
		return this;
	}

	public AnalyticsEventWrapper setNoteIdValue(String value) {
		super.setNoteId(value);
		return this;
	}

	public AnalyticsEventWrapper setMessageIdValue(String value) {
		super.setMessageId(value);
		return this;
	}

	public AnalyticsEventWrapper setIdValue(Id value) {
		super.setIds(value);
		return this;
	}

	public AnalyticsEventWrapper setSrcValue(EnumEventSourceNDestination value) {
		super.setSrc(value.toString());
		return this;
	}

	public AnalyticsEventWrapper setDestinationValue(EnumEventSourceNDestination value) {
		super.setDestination(value.toString());
		return this;
	}

	public AnalyticsEventWrapper setEventNameValue(EnumEventName value) {
		super.setEventName(value.toString());
		return this;
	}

	public AnalyticsEventWrapper setEventTypeValue(EnumEventType value) {
		super.setEventType(value.toString());
		return this;
	}

	public AnalyticsEventWrapper setTimestampValue(String value) {
		super.setTimestamp(value);
		return this;
	}

	public AnalyticsEventWrapper setStatusValue(EnumEventCurrentStatus value) {
		super.setStatus(value.toString());
		return this;
	}

	public AnalyticsEventWrapper setFinalStatusValue(EnumEventFinalStatus value) {
		super.setFinalStatus(value.toString());
		return this;
	}

	public AnalyticsEventWrapper setIdsValue(Id value) {
		super.setIds(value);
		return this;
	}

	public AnalyticsEventWrapper setAdditionalPropertyValue(String name, Object value) {
		super.setAdditionalProperty(name, value);
		return this;
	}

	public AnalyticsEventWrapper add(String name, Object value) {
		super.setAdditionalProperty(name, value);
		return this;
	}

	
	public AnalyticsEventWrapper clearAdd() {
		super.getAdditionalProperties().clear();
		return this;
	}
	public static AnalyticsEventWrapper getNewInstance() {
		return new AnalyticsEventWrapper().setTimestampValue(new Timestamp(System.currentTimeMillis()).toString());
	}

	/**
	 * 
	 * @return
	 */
	public AnalyticsEventWrapper curentTime()
	{
		this.setTimestampValue (new Timestamp(System.currentTimeMillis()).toString());
		return this;
	}

	public AnalyticsEventWrapper processing(EnumEventCurrentStatus curent) {
		;
		this.setStatusValue(curent).processing().curentTime();
		return this;
	}

	public AnalyticsEventWrapper success(EnumEventCurrentStatus curent) {
		return this.setStatusValue(curent).success().curentTime();
	}

	public AnalyticsEventWrapper error(EnumEventCurrentStatus curent) {
		return this.setStatusValue(curent).error().curentTime();
	}

	public AnalyticsEventWrapper error(EnumEventCurrentStatus curent, String message) {
		return this.setStatusValue(curent).error().curentTime().add("Error", message);
	}

	public AnalyticsEventWrapper processing() {
		return this.setFinalStatusValue(EnumEventFinalStatus.PROCESSING).curentTime();
	}

	public AnalyticsEventWrapper success() {
		this.setFinalStatusValue(EnumEventFinalStatus.SUCCESS).curentTime();
		return this;
	}

	public AnalyticsEventWrapper error() {
		return this.setFinalStatusValue(EnumEventFinalStatus.ERROR).curentTime();
	}
	public AnalyticsEventWrapper error(String message) {
		return this.setFinalStatusValue(EnumEventFinalStatus.ERROR).curentTime().add("Error", message);
	}
	

}
