package com.integration.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "sf_org_emx_off_map")

public class SfOrgEmxOffMap {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank
	@Column(nullable = false, name = "emx_office")
	private String emxOffice;
	
	@NotBlank
	@Column(nullable = false, name = "org_id")
	private String orgId;
	
	@NotBlank
	@Column(nullable = false, name = "is_active")
	private String isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmxOffice() {
		return emxOffice;
	}

	public void setEmxOffice(String emxOffice) {
		this.emxOffice = emxOffice;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}
