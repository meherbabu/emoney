package com.integration.bean.emx;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.integration.bean.sf.RmqMessage;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "taskId",
        "sfTaskId",
        "orgId",
        "clientId",
        "firstName",
        "lastName",
        "subject",
        "message",
        "assignedTo",
        "status",
        "isVisibleToClient",
        "isAssignedToClient",
        "dueDate",
        "reminderDate",
        "completed",
        "links"
})
public class EmxTaskResponse implements Serializable,RmqMessage {

    @JsonProperty("taskId")
    private String taskId;
    @JsonProperty("sfTaskId")
    private String sfTaskId;
    @JsonProperty("clientId")
    private String clientId;

    @JsonProperty("orgId")
    private String orgId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("message")
    private String message;
    @JsonProperty("assignedTo")
    private String assignedTo;
    @JsonProperty("status")
    private String status;
    @JsonProperty("isVisibleToClient")
    private Boolean isVisibleToClient;
    @JsonProperty("isAssignedToClient")
    private Boolean isAssignedToClient;
    @JsonProperty("dueDate")
    private String dueDate;
    @JsonProperty("reminderDate")
    private String reminderDate;
    @JsonProperty("completed")
    private Boolean completed;
    @JsonProperty("links")
    @Valid
    private List<Link> links = null;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 3050298567421470081L;

    @JsonProperty("taskId")
    public String getTaskId() {
        return taskId;
    }

    @JsonProperty("taskId")
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    @JsonProperty("clientId")
    public String getClientId() {
        return clientId;
    }

    @JsonProperty("clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    public String getSfTaskId() {
        return sfTaskId;
    }

    public void setSfTaskId(String sfTaskId) {
        this.sfTaskId = sfTaskId;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("subject")
    public String getSubject() {
        return subject;
    }

    @JsonProperty("subject")
    public void setSubject(String subject) {
        this.subject = subject;
    }

    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    @JsonProperty("assignedTo")
    public String getAssignedTo() {
        return assignedTo;
    }

    @JsonProperty("assignedTo")
    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("isVisibleToClient")
    public Boolean getIsVisibleToClient() {
        return isVisibleToClient;
    }

    @JsonProperty("isVisibleToClient")
    public void setIsVisibleToClient(Boolean isVisibleToClient) {
        this.isVisibleToClient = isVisibleToClient;
    }

    @JsonProperty("isAssignedToClient")
    public Boolean getIsAssignedToClient() {
        return isAssignedToClient;
    }

    @JsonProperty("isAssignedToClient")
    public void setIsAssignedToClient(Boolean isAssignedToClient) {
        this.isAssignedToClient = isAssignedToClient;
    }

    @JsonProperty("dueDate")
    public String getDueDate() {
        return dueDate;
    }

    @JsonProperty("dueDate")
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    @JsonProperty("reminderDate")
    public String getReminderDate() {
        return reminderDate;
    }

    @JsonProperty("orgId")
    public String getOrgId() {
        return orgId;
    }

    @JsonProperty("orgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }


    @JsonProperty("reminderDate")
    public void setReminderDate(String reminderDate) {
        this.reminderDate = reminderDate;
    }

    @JsonProperty("completed")
    public Boolean getCompleted() {
        return completed;
    }

    @JsonProperty("completed")
    public void setCompleted(Boolean completed) {
        this.completed = completed;
    }

    @JsonProperty("links")
    public List<Link> getLinks() {
        return links;
    }

    @JsonProperty("links")
    public void setLinks(List<Link> links) {
        this.links = links;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "EMoneyTaskResponse{" +
                "taskId='" + taskId + '\'' +
                ", sfTaskId='" + sfTaskId + '\'' +
                ", clientId='" + clientId + '\'' +
                ", orgId='" + orgId + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", subject='" + subject + '\'' +
                ", message='" + message + '\'' +
                ", assignedTo='" + assignedTo + '\'' +
                ", status='" + status + '\'' +
                ", isVisibleToClient=" + isVisibleToClient +
                ", isAssignedToClient=" + isAssignedToClient +
                ", dueDate='" + dueDate + '\'' +
                ", reminderDate='" + reminderDate + '\'' +
                ", completed=" + completed +
                ", links=" + links +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}