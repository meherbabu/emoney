package com.integration.exception;

public class AnalyticsUtilException extends Exception {
	public AnalyticsUtilException() {
		// TODO Auto-generated constructor stub
	}

	public AnalyticsUtilException(String message) {

		super(message);
	}

	public AnalyticsUtilException(String message, Throwable e) {

		super(message, e);
	}

}
