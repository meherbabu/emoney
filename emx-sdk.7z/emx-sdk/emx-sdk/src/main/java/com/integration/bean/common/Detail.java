package com.integration.bean.common;

import java.io.Serializable;
import java.util.Arrays;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Details Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
@JsonSerialize
@Valid
public class Detail implements Serializable{
		
	private static final long serialVersionUID = -1974181183951603298L;

	@JsonProperty("property")
	private String property;	
	@JsonProperty("messages")
	private String[] messages;

	public String getProperty() {
		return property;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public String[] getMessages() {
		return messages;
	}
	public void setMessages(String[] messages) {
		this.messages = messages;
	}	
	@Override
	public String toString() {
		return "Detail [property=" + property + ", messages=" + Arrays.toString(messages) + "]";
	}

}
