package com.integration.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "sf_emx_mapping")
public class SfEmxMapping {

	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@JsonIgnore
	@Column(nullable = false, name = "sem_id")
	private Long semId;

	@JsonIgnore
	@NotBlank
	@Column(nullable = false, name = "sf_org")
	private String sfOrg;
	
	@JsonIgnore
	@NotBlank
	@Column(nullable = false, name = "entity")
	private String entity;

	@JsonProperty("sf_name")
	@NotBlank
	@Column(nullable = false, name = "sf_name")
	private String sfName;

	@JsonProperty("sf_type")
	@NotBlank
	@Column(nullable = false, name = "sf_type")
	private String sfType;

	@JsonProperty("emx_name")
	@NotBlank
	@Column(nullable = false, name = "emx_name")
	private String emxName;

	@JsonProperty("emx_type")
	@NotBlank
	@Column(nullable = false, name = "emx_type")
	private String emxType;
	
	

	public SfEmxMapping(Long id, Long semId, String sfOrg, String emxId, String sfName, String sfType, String emxName,
			String emxType) {
		super();
		this.id = id;
		this.semId = semId;
		this.sfOrg = sfOrg;
		this.entity = emxId;
		this.sfName = sfName;
		this.sfType = sfType;
		this.emxName = emxName;
		this.emxType = emxType;
	}

	public SfEmxMapping() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSemId() {
		return semId;
	}

	public void setSemId(Long semId) {
		this.semId = semId;
	}

	public String getSfOrg() {
		return sfOrg;
	}

	public void setSfOrg(String sfOrg) {
		this.sfOrg = sfOrg;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	@JsonProperty("sf_name")
	public String getSfName() {
		return sfName;
	}

	public void setSfName(String sfName) {
		this.sfName = sfName;
	}

	@JsonProperty("sf_type")
	public String getSfType() {
		return sfType;
	}

	public void setSfType(String sfType) {
		this.sfType = sfType;
	}

	@JsonProperty("emx_name")
	public String getEmxName() {
		return emxName;
	}

	public void setEmxName(String emxName) {
		this.emxName = emxName;
	}

	@JsonProperty("emx_type")
	public String getEmxType() {
		return emxType;
	}

	public void setEmxType(String emxType) {
		this.emxType = emxType;
	}

}
