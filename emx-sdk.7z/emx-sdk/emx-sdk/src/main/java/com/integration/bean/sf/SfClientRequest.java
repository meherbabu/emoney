package com.integration.bean.sf;

import java.io.Serializable;

import javax.validation.Valid;


/*import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.NotBlank;*/

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModel;

@JsonSerialize
@ApiModel(description = "Sample SFClientRequest Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
public class SfClientRequest implements Serializable,RmqMessage{
	
	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -7476751075356736688L;
	
	@JsonProperty("trackingID")
	private String trackingID;
	
	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@JsonProperty("clients")
	private SfClientData[] clients;

	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}
	
	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@Valid
	public SfClientData[] getClients() {
		return clients;
	}

	public void setClients(SfClientData[] clients) {
		this.clients = clients;
	}

	@Override
	public String toString() {
		return "SFClientRequest [trackingID=" + trackingID + ", sourceSystem=" + sourceSystem + ", clients=" + clients
				+ "]";
	}
	
	
	
}
