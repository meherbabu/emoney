package com.integration.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.integration.bean.common.SourceSystem;
import com.integration.exception.SendToExchangeException;

@Service
public class HttpExchangeServiceImpl implements HttpExchangeService {

	Log logger = LoggerUtil.getLog(this);

	private HandlingExceptionMessages handlingExceptionMessages;
	
	@Value("${emoney.appDevId}")
	private String appDevId;

	/**
	 * 
	 *
	 */
	@Autowired
	public HttpExchangeServiceImpl(HandlingExceptionMessages handlingExceptionMessages) {
		this.handlingExceptionMessages = handlingExceptionMessages;
	}

	@Override
	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headersMap, String message,
			Map<String, Object> requestParamsValues) throws SendToExchangeException {
		removeContentTypeHeaderForGet(method, headersMap);
		headersMap.put("Accept-Charset", "UTF-8");
		logger.info("Start HttpExchangeServiceImpl.sendToExchange");

		logger.info("Url " + url);
		logger.info("method " + method);
		logger.info("headersMap " + headersMap);
		logger.info("message " + message);
		logger.info("requestParamsValues " + requestParamsValues);

		ResponseEntity<?> response = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headersMap.forEach((k, v) -> {
				headers.add(k, v);
			});
			HttpEntity<?> entity = new HttpEntity<>(message, headers);
			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			
			removeAdditionalCharsets(restTemplate);
			

			if (requestParamsValues == null)
				response = restTemplate.exchange(url, method, entity, String.class);
			else
				response = restTemplate.exchange(url, method, entity, String.class, requestParamsValues);

			logger.info("Status code  " + response.getStatusCode());
			if (response != null) {
				logger.info("Response body" + response.getBody() + "");
			}

		} catch (Exception exception) {
			logger.error(exception);
			throw new SendToExchangeException(exception);
		} finally {
			logger.info("End sendMessageToSf.sendMessageToSf");
		}

		return response.getBody();
	}

	private void removeAdditionalCharsets(RestTemplate restTemplate) {
		List<HttpMessageConverter<?>> converters = new ArrayList<>();
		StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
		stringConverter.setWriteAcceptCharset(false);
		converters.add(stringConverter);
		restTemplate.setMessageConverters(converters);
	}


	@Override
	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headersMap,Object object,
								 Map<String, Object> requestParamsValues) throws SendToExchangeException {

		logger.info("Start HttpExchangeServiceImpl.sendToExchange");
		removeContentTypeHeaderForGet(method, headersMap);

		logger.info("Url " + url);
		logger.info("method " + method);
		logger.info("headersMap " + headersMap);
		logger.info("object " + object);
		logger.info("requestParamsValues " + requestParamsValues);

		ResponseEntity<?> response = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headersMap.forEach((k, v) -> {
				headers.add(k, v);
			});
			HttpEntity<?> entity = new HttpEntity<>(object, headers);
			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
			RestTemplate restTemplate = new RestTemplate(requestFactory);

			if (requestParamsValues == null)
				response = restTemplate.exchange(url, method, entity, Object.class);
			else
				response = restTemplate.exchange(url, method, entity, String.class, requestParamsValues);

			logger.info("Status code  " + response.getStatusCode());
			if (response != null) {
				logger.info("Response body " + response.getBody() + "");
			}

		} catch (Exception exception) {
			throw new SendToExchangeException(exception);
		} finally {
			logger.info("End sendMessageToSf.sendMessageToSf");
		}

		return response.getBody();
	}
	@Override
	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headersMap, String message)
			throws SendToExchangeException {
		return sendToExchange(url, method, headersMap, message, null);
	}

	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headersMap, Object object)
			throws SendToExchangeException {
		return sendToExchange(url, method, headersMap, object, null);
	}

	@Override
	public Object sendToExchange(SourceSystem desti, String source, String url, HttpMethod method,
			Map<String, String> headersMap, String message, Map<String, Object> requestParamsValues)
			throws SendToExchangeException {

		try {
			addSourceHeader(desti, headersMap);
			addAppDevIdHeader(desti, headersMap);
			return sendToExchange(url, method, headersMap, message, requestParamsValues);
		} catch (SendToExchangeException exc) {
			handlingExceptionMessages.processException(desti, exc, source, url, method, headersMap, message, requestParamsValues);
			throw exc;
		}
	}
	
	private void removeContentTypeHeaderForGet(HttpMethod method, Map<String, String> headersMap) {
				if ( method == HttpMethod.GET) {
					headersMap.remove("Content-Type");
				}
	}

	private void addSourceHeader(SourceSystem source, Map<String, String> headersMap) {
		if ("salesforce".equalsIgnoreCase(source.toString())) {
			headersMap.put("SourceSystem", "Salesforce");
		}
		
	}
	
	private void addAppDevIdHeader(SourceSystem source, Map<String, String> headersMap) {
		if ("salesforce".equalsIgnoreCase(source.toString())) {
			headersMap.put("apiKey", appDevId);	
		}
	}

	@Override
	public Object sendToExchange(SourceSystem desti, String source, String url, HttpMethod method,
			Map<String, String> headersMap, String message) throws SendToExchangeException {
		return sendToExchange(desti, source, url, method, headersMap, message, null);
	}

}
