package com.integration.service.validation.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

@XmlRootElement(name = "validatorConfiguration")
@XmlAccessorType(XmlAccessType.FIELD)
public class ValidatorConfigurationBean {
	
	@XmlAttribute
	private  String id;
	@JacksonXmlElementWrapper(localName = "templates")
	List<TemplateBean> templateBeanList = new ArrayList<TemplateBean>();

	@JacksonXmlElementWrapper(localName = "vars")
	List<VarBean> varBeanList = new ArrayList<VarBean>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<TemplateBean> getTemplateBeanList() {
		return templateBeanList;
	}

	public void setTemplateBeanList(List<TemplateBean> templateBeanList) {
		this.templateBeanList = templateBeanList;
	}

	public List<VarBean> getVarBeanList() {
		return varBeanList;
	}

	public void setVarBeanList(List<VarBean> varBeanList) {
		this.varBeanList = varBeanList;
	}


}
