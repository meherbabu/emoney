package com.integration.exception;

import java.util.List;

import com.integration.bean.common.IntegrationError;

/**
 * For HTTP 404 errros
 */
public class ResourceNotFoundException  extends AbstractIntegrationException {

    public ResourceNotFoundException(String s) {
        super(s);
    }

    public ResourceNotFoundException(List<IntegrationError> integrationErrors) {
        super(integrationErrors);
    }

    public ResourceNotFoundException(IntegrationError integrationError) {
        super(integrationError);
    }
}
