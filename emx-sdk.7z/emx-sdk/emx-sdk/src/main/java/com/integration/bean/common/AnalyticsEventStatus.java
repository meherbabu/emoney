package com.integration.bean.common;

public enum AnalyticsEventStatus {

    RECEIVED_FROM_SF,
    RECEIVED_FROM_EMX,
    STAGED_FOR_PROCESSING,
    PROCESSING,
    SYNC_PROCESSING_ERROR,
    SYNCED_TO_EMX,
    SYNCED_TO_SF
}
