package com.integration.bean.emx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.sf.RmqMessage;

import java.io.Serializable;

public class EmxNoteResponse implements RmqMessage,Serializable {
    @JsonProperty("clientId")
    private  String clientId;
    @JsonProperty("noteId")
     private  String noteId ;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }

    @Override
    public String toString() {
        return "EMoneyNoteResponse{" +
                "clientId='" + clientId + '\'' +
                ", noteId='" + noteId + '\'' +
                '}';
    }
}
