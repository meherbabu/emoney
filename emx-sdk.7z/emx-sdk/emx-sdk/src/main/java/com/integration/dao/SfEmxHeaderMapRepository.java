package com.integration.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.SfEmxHeaderMap;

@Repository
@Transactional
public interface SfEmxHeaderMapRepository extends JpaRepository<SfEmxHeaderMap, Long> {

	@Query("SELECT p.sfEntity FROM SfEmxHeaderMap p WHERE p.sfOrg = :sfOrg and p.emxEntity = :emxEntity")
	public String findSfEntity(@Param("sfOrg") String sf_org, @Param("emxEntity") String emxEntity);

	@Query("SELECT p FROM SfEmxHeaderMap p WHERE p.sfOrg = :sfOrg and p.emxEntity = :emxEntity")
	public SfEmxHeaderMap findSfEntityObject(@Param("sfOrg") String sfOrg, @Param("emxEntity") String emxEntity);

}
