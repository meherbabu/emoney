package com.integration.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;

@Entity
@Table(name = "credential_keys")
@XmlRootElement(name = "credentialkeys")
@XmlAccessorType(XmlAccessType.FIELD)

public class CredentialKeys {
	
	@XmlTransient
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@XmlElement(name = "name")
	@Column(nullable = false, name = "name")
	private String name;

	@JacksonXmlCData
	@XmlElement(name = "privateKey")
	@Column(nullable = false, name = "private_key")
	private String privateKey;

	@JacksonXmlCData
	@XmlElement(name = "publicKey")
	@Column(nullable = true, name = "public_key")
	private String publicKey;

	@JacksonXmlCData
	@XmlElement(name = "certificate")
	@Column(nullable = true, name = "certificate")
	private String certificate;
	
	public CredentialKeys() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}


}
