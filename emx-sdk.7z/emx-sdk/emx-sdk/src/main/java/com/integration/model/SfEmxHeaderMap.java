package com.integration.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "sf_emx_header_map")
public class SfEmxHeaderMap {

	@Id
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, name = "id")
	private Long id;

	@JsonProperty("org")
	@NotBlank
	@Column(nullable = false, name = "sf_org")
	private String sfOrg;

	@JsonProperty("sf_entity")
	@NotBlank
	@Column(nullable = false, name = "sf_entity")
	private String sfEntity;

	@JsonProperty("emx_entity")
	@NotBlank
	@Column(nullable = false, name = "emx_entity")
	private String emxEntity;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("sf_record_type")
	@Column(nullable = true, name = "sf_record_type")
	private String sfRecordType;

	@JsonProperty("active")
	@Column(name = "active")
	private int active =1;
	
	
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@JsonProperty("org")
	public String getSfOrg() {
		return sfOrg;
	}

	public void setSf_org(String sfOrg) {
		this.sfOrg = sfOrg;
	}

	@JsonProperty("sf_entity")
	public String getSfEntity() {
		return sfEntity;
	}

	public void setSfEntity(String sfEntity) {
		this.sfEntity = sfEntity;
	}

	@JsonProperty("emx_entity")
	public String getEmxEntity() {
		return emxEntity;
	}

	public void setEmxEntity(String emx_entity) {
		this.emxEntity = emx_entity;
	}

	@JsonProperty("sf_record_type")
	public String getSfRecordType() {
		return sfRecordType;
	}

	public void setSfRecordType(String sf_record_type) {
		this.sfRecordType = sf_record_type;
	}

	@JsonProperty("active")
	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "SF2EmxHeaderMapper{" + "Id='" + id + '\'' + ", sf_org='" + sfOrg + '\'' + ", sfEntity='" + sfEntity
				+ '\'' + ", emx_entity='" + emxEntity + '\'' + ", sf_record_type='" + sfRecordType + '\'' + '}';
	}
}
