package com.integration.bean.sf;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "eMoneyId",
        "taskId",
        "eMoneytaskId",
        "subject",
        "message",
        "assignedTo",
        "isVisibleToClient",
        "isAssignedToClient",
        "dueDate",
        "reminderDate",
        "completed"
})
@JsonSerialize
public class SfTask implements Serializable
{

    @NotNull
    @Size(min=1)
    @JsonProperty("eMoneyId")
    private String eMoneyId;
    @Size(min=1)
    @JsonProperty("taskId")
    @NotNull(message = "taskID can't be null")
    private String taskId;
    @JsonProperty(value = "eMoneyTaskId",required = false)
    private String eMoneyTaskId;
    @NotNull
    @JsonProperty("subject")
    @Size(min = 1,max = 100)
    private String subject;
    @JsonProperty("message")
    private String message;
    @NotNull(message = "assignedTo can't be null")
    @JsonProperty("assignedTo")
    private String assignedTo;
    @JsonProperty("isVisibleToClient")
    private Boolean isVisibleToClient;
    @JsonProperty("isAssignedToClient")
    private Boolean isAssignedToClient;
    @NotNull
   @JsonFormat(pattern = "yyyy-mm-dd")
    private String dueDate;
    @JsonProperty("reminderDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String reminderDate;
    @JsonProperty("completed")
    private String completed;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -7609819312805123571L;

    @JsonProperty("eMoneyId")
    public String getEMoneyId() {
        return eMoneyId;
    }

    @JsonProperty("eMoneyId")
    public void setEMoneyId(String eMoneyId) {
        this.eMoneyId = eMoneyId;
    }

    @JsonProperty("taskId")
    public String getTaskId() {
        return taskId;
    }

    @JsonProperty("taskId")
    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    @JsonProperty("subject")
    public String getSubject() {
        return subject;
    }
    @JsonProperty(value = "eMoneyTaskId" ,required = false)
    public String geteMoneyTaskId() {
        return eMoneyTaskId;
    }
    @JsonProperty(value = "eMoneyTaskId", required =false)
    public void seteMoneyTaskId(String eMoneyTaskId) {
        this.eMoneyTaskId = eMoneyTaskId;
    }

    @JsonProperty("subject")
    public void setSubject(String subject) {
        this.subject = subject;
    }

    @JsonProperty("message")
    public String getMessage() {

        return message;
    }

    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    @JsonProperty("assignedTo")
    public String getAssignedTo() {
        return assignedTo;
    }

    @JsonProperty("assignedTo")
    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    @JsonProperty("isVisibleToClient")
    public Boolean getIsVisibleToClient() {
        return isVisibleToClient;
    }

    @JsonProperty("isVisibleToClient")
    public void setIsVisibleToClient(Boolean isVisibleToClient) {
        this.isVisibleToClient = isVisibleToClient;
    }

    @JsonProperty("isAssignedToClient")
    public Boolean getIsAssignedToClient() {
        return isAssignedToClient;
    }

    @JsonProperty("isAssignedToClient")
    public void setIsAssignedToClient(Boolean isAssignedToClient) {
        this.isAssignedToClient = isAssignedToClient;
    }

    @JsonProperty("dueDate")
//    @Pattern(regexp = "yyyy-mm-dd")
    public String getDueDate() {
        return dueDate;
    }

    @JsonProperty("dueDate")
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    @JsonProperty("reminderDate")
    public String getReminderDate() {
        return reminderDate;
    }

    @JsonProperty("reminderDate")
    public void setReminderDate(String reminderDate) {
        this.reminderDate = reminderDate;
    }

    @JsonProperty("completed")
    public Boolean getCompleted() {
        return Boolean.valueOf(completed);
    }

    @JsonProperty("completed")
    public void setCompleted(String completed) {
        this.completed = completed;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "SFTask{" +
                "eMoneyId='" + eMoneyId + '\'' +
                ", taskId='" + taskId + '\'' +
                ", eMoneyTaskId='" + eMoneyTaskId + '\'' +
                ", subject='" + subject + '\'' +
                ", message='" + message + '\'' +
                ", assignedTo='" + assignedTo + '\'' +
                ", isVisibleToClient=" + isVisibleToClient +
                ", isAssignedToClient=" + isAssignedToClient +
                ", dueDate='" + dueDate + '\'' +
                ", reminderDate='" + reminderDate + '\'' +
                ", completed='" + completed + '\'' +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}