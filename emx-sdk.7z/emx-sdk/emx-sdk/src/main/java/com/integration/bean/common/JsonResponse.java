package com.integration.bean.common;



/**
 * POJO Class for JsonResponse of all the Services
 */

public class JsonResponse {

	/** The success. */
	private boolean success = false;

	/** The status. */
	private String status;

	
	/** The result. */
	private Object result;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}
	
	
}
