package com.integration.service;

import org.apache.commons.logging.Log;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.integration.configuration.MessageBrokerConfiguration;

@Component
public class AnalyticsEventPublisherImpl implements AnalyticsEventPublisher {

	Log logger = LoggerUtil.getLog(this);

	private JsonUtility jsonUtility;

	@Value("${analytics.events.enable:false}")
	boolean enabled = false;

	private MessageSender messageSender;
	
	@Value("${analytics.events.exchange:analyticsEventExchange}")
	private String exchange = "analyticsEventExchange";

	@Value("${analytics.events.routingkey:com.integration.analytics.#}")
	private String routingkey = "com.integration.analytics.#" ;
	
	@Value("${analytics.events.persistence:false}")
	private boolean isPersistent;

	@Autowired
	public AnalyticsEventPublisherImpl(RabbitTemplate rabbitTemplate,
			MessageBrokerConfiguration messageBrokerConfiguration, JsonUtility jsonUtility,
			MessageSender messageSender) {
		this.jsonUtility = jsonUtility;
		this.messageSender = messageSender;
	}

	@Override
	public void publish(Object object) {
		if ( !enabled ) return;
		this.logger.debug("connecting to rabbit MQ");
		String message = "";
		try {
			if (object instanceof String)
				message = (String) object;
			else {
				message = jsonUtility.getJsonStringFromObject(object);
			}
			logger.info("*** Analytics EVENT Publish:: " + message);
			messageSender.send(exchange, routingkey, isPersistent, message);
			this.logger.debug("sucessfully published to rabbit MQ ");
		} catch (JsonProcessingException var4) {
			this.logger.error("*** Unable to Publish EVENT: " + String.valueOf(object));
		} catch (Exception var4) {
			this.logger.error("*** Unable to Publish EVENT: " + object.toString());
		}

	}
}
