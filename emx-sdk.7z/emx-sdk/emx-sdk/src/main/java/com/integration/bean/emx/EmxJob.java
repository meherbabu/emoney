package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class EmxJob implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6932140987408561267L;
	
	
	@Size(max = 100)
	@JsonProperty("companyName")
	private String companyName;
	
	
	@NotNull(message="address cannot be Null")
	@Valid
	@JsonProperty("address")
	private EmxAddress address;
	
	
	@Size(max = 100)
	@JsonProperty("jobTitle")
	private String jobTitle;
	
	@JsonProperty("businessEmail")
	@Pattern(regexp = "^[A-Za-z0-9._%-]{1,2}+@[A-Za-z0-9.-]{1,2}+\\\\.[a-zA-Z]{1,2}$", message = "businessEmail must 2characters@2characters.2characters - ab@cd.ef is acceptable\n" + "@ is necessary")
	private String businessEmail;
	
	@JsonProperty("businessPhone")
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "businessPhone must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	private String businessPhone;
	
	
	@JsonProperty("businessFax")
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "businessFax must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	private String businessFax;
	
	@JsonProperty("yearsEmployed")
	private String yearsEmployed;
	
	@JsonProperty("previousEmployerName")
	private String previousEmployerName;
	
	@JsonProperty("previousJobTitle")
	private String previousJobTitle;
	
	@JsonProperty("previousYearsEmployed")
	private String previousYearsEmployed;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public EmxAddress getAddress() {
		return address;
	}

	public void setAddress(EmxAddress address) {
		this.address = address;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getBusinessEmail() {
		return businessEmail;
	}

	public void setBusinessEmail(String businessEmail) {
		this.businessEmail = businessEmail;
	}

	public String getBusinessPhone() {
		return businessPhone;
	}

	public void setBusinessPhone(String businessPhone) {
		this.businessPhone = businessPhone;
	}

	public String getBusinessFax() {
		return businessFax;
	}

	public void setBusinessFax(String businessFax) {
		this.businessFax = businessFax;
	}

	public String getYearsEmployed() {
		return yearsEmployed;
	}

	public void setYearsEmployed(String yearsEmployed) {
		this.yearsEmployed = yearsEmployed;
	}

	public String getPreviousEmployerName() {
		return previousEmployerName;
	}

	public void setPreviousEmployerName(String previousEmployerName) {
		this.previousEmployerName = previousEmployerName;
	}

	public String getPreviousJobTitle() {
		return previousJobTitle;
	}

	public void setPreviousJobTitle(String previousJobTitle) {
		this.previousJobTitle = previousJobTitle;
	}

	public String getPreviousYearsEmployed() {
		return previousYearsEmployed;
	}

	public void setPreviousYearsEmployed(String previousYearsEmployed) {
		this.previousYearsEmployed = previousYearsEmployed;
	}

	@Override
	public String toString() {
		return "EMoneyJob [companyName=" + companyName + ", address=" + address + ", jobTitle=" + jobTitle
				+ ", businessEmail=" + businessEmail + ", businessPhone=" + businessPhone + ", businessFax="
				+ businessFax + ", yearsEmployed=" + yearsEmployed + ", previousEmployerName=" + previousEmployerName
				+ ", previousJobTitle=" + previousJobTitle + ", previousYearsEmployed=" + previousYearsEmployed + "]";
	}

}
