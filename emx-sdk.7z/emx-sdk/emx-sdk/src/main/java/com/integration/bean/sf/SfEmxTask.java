package com.integration.bean.sf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;

@JsonSerialize
public class SfEmxTask  implements Serializable {


    @JsonProperty("trackingID")
    private String trackingID;
    @JsonProperty("sourceSystem")
    private String sourceSystem;
    @JsonProperty("tasks")
    private SfTaskWrapper wrapper;

    public String getTrackingID() {
        return trackingID;
    }


    public void setTrackingID(String trackingID) {
        this.trackingID = trackingID;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public SfTaskWrapper getSfTask() {
        return wrapper;
    }

    public void setSfTask(SfTaskWrapper sfTask) {
        this.wrapper = sfTask;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }


    @Override
    public String toString() {
        return "EMXTask{" +
                "trackingID='" + trackingID + '\'' +
                ", sourceSystem='" + sourceSystem + '\'' +
                ", sfTask=" + wrapper +
                '}';
    }
}
