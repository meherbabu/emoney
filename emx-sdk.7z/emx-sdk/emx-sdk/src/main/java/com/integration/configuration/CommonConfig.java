package com.integration.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.integration.bean.common.ExchangeExceptionMessageBean;

@Configuration
public class CommonConfig {
	
	@Bean
	public ExchangeExceptionMessageBean exceptionMsgBean()
	{
	       return new ExchangeExceptionMessageBean();
	}

}
