package com.integration.transformation.modal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.integration.bean.emx.EmxTask;
import com.integration.bean.sf.SfTask;
import com.integration.service.SfToEmxCommonUtil;

@Component
public class SFToEMoneyTaskRequest {
	
	@Autowired
	private SfToEmxCommonUtil sfToEmxCommonUtil;

    public EmxTask transformSFTaskToEMoneyTask(SfTask sfTask){
       if(sfTask!=null) {
           EmxTask eMoneyTask = new EmxTask();
           eMoneyTask.setClientId(sfTask.getEMoneyId());
           eMoneyTask.setSubject(sfTask.getSubject());
           eMoneyTask.setMessage(sfToEmxCommonUtil.formatMessageForEMX(sfTask.getMessage()));
           eMoneyTask.setAssignedTo(sfTask.getAssignedTo());
           eMoneyTask.setIsVisibleToClient(sfTask.getIsVisibleToClient());
           eMoneyTask.setIsAssignedToClient(sfTask.getIsAssignedToClient());
           eMoneyTask.setDueDate(sfTask.getDueDate());
           eMoneyTask.setReminderDate(sfTask.getReminderDate());
           eMoneyTask.setCompleted(sfTask.getCompleted());
           return eMoneyTask;
       }
       else
           return null;
    }
}
