package com.integration.transformation.modal;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.integration.bean.emx.EmxClientNoteRequest;
import com.integration.bean.emx.EmxNote;
import com.integration.bean.sf.SfNote;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.service.SfToEmxCommonUtil;

@Component
public class SFToEMoneyNotesRequest {
	
	@Autowired
	private SfToEmxCommonUtil sfToEmxCommonUtil;

    /**
     * Transforming SF notes request to EMX notes req
     * @param message
     * @return
     * @throws DataProcessingException
     * @throws DataPublishingException
     * @throws IOException
     */
    public EmxNote transformSFToEMXNotes(SfNote message) throws DataProcessingException, DataPublishingException, IOException {
        if (message != null) {
            EmxNote eMoneyNote =new EmxNote();
            eMoneyNote.setClientId(message.geteMoneyId());
            eMoneyNote.setText(sfToEmxCommonUtil.formatMessageForEMX(message.getText()));
            return eMoneyNote;

        } else
            return null;
    }
    
	public EmxClientNoteRequest transformNoteSFtoEMX(SfNote note) {
		EmxClientNoteRequest eMoneyClientNoteRequest = null;
		if (note != null) {
			eMoneyClientNoteRequest = new EmxClientNoteRequest();
			StringBuilder url = new StringBuilder();
			url.append("/api/clients/");
			if (note.geteMoneyId() != null && note.getNoteId() != null) {
				url.append(note.geteMoneyId());
				url.append("/notes/");
				url.append(note.getNoteId());
			}

			eMoneyClientNoteRequest.setUriString(url.toString());
			eMoneyClientNoteRequest.setText(note.getText());
		}
		return eMoneyClientNoteRequest;
	}
}