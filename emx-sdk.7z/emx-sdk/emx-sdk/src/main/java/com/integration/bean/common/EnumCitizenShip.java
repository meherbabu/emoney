package com.integration.bean.common;

public enum EnumCitizenShip {
	USCITIZEN, RESIDENTALIEN, NONRESIDENTALIEN, EMPTY, NULL
	
}
