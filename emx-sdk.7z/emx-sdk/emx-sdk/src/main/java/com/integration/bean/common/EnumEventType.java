package com.integration.bean.common;

public enum EnumEventType {
	CREATE,UPDATE,DELETE,RESPONSE;
}
