package com.integration.bean.sf;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.PiiDataLog;
@Component
public class SfEmxNotesPiiDataImpl implements PiiDataLog {

	@JsonProperty("clientId")
	private String clientId;
	
	@JsonProperty("eMoneyNoteId")              //Change or correction
	private String  eMoneyNoteId;
	
	@JsonProperty("noteId")
	private String noteId;
	
	public void setPiiData(String clientId,String eMoneyNoteId, String noteId) //Change  or correction 
	{
	    this.setnoteId(noteId);
		this.seteMoneyNotes(eMoneyNoteId);  //Change or correction
		this.setclientId(clientId);
	}
	
	 public String getclientId() {
         return clientId;
    }


    public void setclientId(String clientId) {
        this.clientId = clientId;
    }
	
    public String geteMoneyNotes() {
    	return eMoneyNoteId;        //change or correction 
    }
	
    public void seteMoneyNotes(String eMoneyNoteId) {
    	this.eMoneyNoteId = eMoneyNoteId ;
    }
	
    public String getnoteId() {
    	return noteId;
    }

    public void setnoteId(String noteId) {
    	this.noteId = noteId;
    }
    
	@Override
	public String logPiiData() {
	
    return "EMXNote{" +
           "clientId='" + clientId + '\'' +
          ", eMoneyNoteId='" + eMoneyNoteId + '\'' +           //Change or correction 
          ", noteId='" + noteId + '\'' + 
          '}';

   }
}
