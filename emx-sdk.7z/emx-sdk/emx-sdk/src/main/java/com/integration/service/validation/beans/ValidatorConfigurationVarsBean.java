package com.integration.service.validation.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

@XmlRootElement(name = "validatorConfiguration")
@XmlAccessorType(XmlAccessType.FIELD)
public class ValidatorConfigurationVarsBean {
	
	@JacksonXmlElementWrapper(localName = "vars")
	List<VarBean> varBeanList = new ArrayList<VarBean>();


	public List<VarBean> getVarBeanList() {
		return varBeanList;
	}

	public void setVarBeanList(List<VarBean> varBeanList) {
		this.varBeanList = varBeanList;
	}


}
