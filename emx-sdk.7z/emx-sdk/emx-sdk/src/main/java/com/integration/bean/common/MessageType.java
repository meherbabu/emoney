package com.integration.bean.common;

public enum MessageType {
	UPDATE, CREATE, DELETE, RESPONSE,GET

}
