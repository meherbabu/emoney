package com.integration.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Read and Write JSON
 */
@Component
public class JsonUtility {

	/**
	 * 
	 * @param object
	 * @return
	 * @throws JsonProcessingException
	 */
	public String getJsonStringFromObject(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		return mapper.writeValueAsString(object);
	}

	/**
	 * 
	 * @param str
	 * @param classType
	 * @return
	 * @throws IOException
	 */
	public Object getObjectFromJsonString(String str, Class<?> classType) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		return mapper.readValue(str, classType);
	}

	/**
	 * 
	 * @param message
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public Map<String, Object> getMapFromJsonString(String message)
			throws JsonParseException, JsonMappingException, IOException {


		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		return mapper.readValue(message, new TypeReference<HashMap<String, Object>>() {
		});
	}
	/**
	 * 
	 * @param message
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public List<Map<String, Object>> getListMapFromJsonString(String message)
			throws JsonParseException, JsonMappingException, IOException {


		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			return mapper.readValue(message, new TypeReference<ArrayList<HashMap<String, Object>>>() {
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return null;
		}
	}

}
