package com.integration.exception;

public class AnalyticsEventPublisherException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnalyticsEventPublisherException(String message) {
		super(message);
	}

	public AnalyticsEventPublisherException(String message, Throwable cause) {
		super(message, cause);
	}

}
