package com.integration.bean.emx;

import java.io.Serializable;
import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.common.Detail;
import com.integration.bean.sf.RmqMessage;

@JsonSerialize
public class EmxClientErrorResponse implements Serializable, RmqMessage{


	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -3415008222229383479L;
	
	@JsonProperty("code")
	private String code;
	@JsonProperty("target")
	private String target;
	@JsonProperty("message")
	private String message;
	@JsonProperty("details")
	private Detail[] details;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Detail[] getDetails() {
		return details;
	}
	public void setDetails(Detail[] details) {
		this.details = details;
	}	
	@Override
	public String toString() {
		return "EMoneyClientDeleteResponse [code=" + code + ", target=" + target + ", message=" + message + ", details="
				+ Arrays.toString(details) + "]";
	}
	
}
