package com.integration.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.SfEmxIdLog;

@Repository
@Transactional
public interface SfEmxIdLogRepository extends JpaRepository<SfEmxIdLog, Long> {

	
	@Query("UPDATE SfEmxIdLog c SET c.sfId = :sfId WHERE c.emxId = :emxId and c.sfofficeId = :sfofficeId")
	@Modifying
	@Transactional
	int updateOrgId(@Param("sfId") String sfId, @Param("emxId") String emxId,
			@Param("sfofficeId") String sfofficeId);
	
	
	//@Query("SELECT p FROM SfEmxMapping p WHERE p.semId = :semId")
	@Query("SELECT sfids FROM SfEmxIdLog sfids WHERE sfids.sfId = :sfId")
	public List<SfEmxIdLog> findBySFID(@Param("sfId") String sfId);
	
	@Query("SELECT emxids FROM SfEmxIdLog emxids WHERE emxids.emxId = :emxId")
	public List<SfEmxIdLog> findByEMXID(@Param("emxId") String emxId);
	

}
