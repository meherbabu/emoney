package com.integration.bean.common;

public interface PiiDataLog {

	
	String  logPiiData();
	
}
