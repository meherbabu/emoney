package com.integration.bean.emx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.Detail;
import com.integration.bean.sf.RmqMessage;

import java.io.Serializable;

public class EmxErrorResponse implements Serializable,RmqMessage {

    @JsonProperty("code")
    private String code;
    @JsonProperty("target")
    private String target;
    @JsonProperty("message")
    private String message;
    @JsonProperty("details")
    private Detail[] details;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Detail[] getDetails() {
        return details;
    }

    public void setDetails(Detail[] details) {
        this.details = details;
    }

}
