package com.integration.bean.common;

public enum EnumEventName {
	CLIENT,
	NOTE,
	TASK,
	ALERT;
}
