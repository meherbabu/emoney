package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.sf.RmqMessage;

import io.swagger.annotations.ApiModel;

@JsonSerialize
@ApiModel(description = "Sample EMXClientDeleteRequest Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
public class EmxClientDeleteRequestV2 implements Serializable, RmqMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5337605073353851703L;
	
	@NotNull (message="tracking id NULL not allowed")	
	@JsonProperty("trackingID")
	private String trackingID;

	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}

	@Override
	public String toString() {
		return "EMoneyClientDeleteRequestV2 [trackingID=" + trackingID + "]";
	}

}
