package com.integration.model;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.sql.Date;
import java.util.List;

//@Entity (name= "sf_organization")
public class SfOrganization {

    @OneToMany (mappedBy = "sfOrganization")
    List<EMoneyOffice> eMoneyOffices;
//	private String alg;
//	private String iss;
//	private String sub;
//	private String aud;
//	private int expiredTimeInMinutes;
//	private String privateKeyString;

    
    @Id
    String orgName ;
    @Column (name= "org_app_id")
    String orgAppId ;
    @Column (name = "org_app_pwd")
    String orgAppPwd;
    @Column (name = "org_status")
    String OrgStatus ;

    @Column (name = "date_created")
    Date dateCreated ;
    @Column (name = "date_updated")
    Date dateUpdated ;

    public List<EMoneyOffice> geteMoneyOffices() {
        return eMoneyOffices;
    }

    public void seteMoneyOffices(List<EMoneyOffice> eMoneyOffices) {
        this.eMoneyOffices = eMoneyOffices;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getOrgAppId() {
        return orgAppId;
    }

    public void setOrgAppId(String orgAppId) {
        this.orgAppId = orgAppId;
    }

    public String getOrgAppPwd() {
        return orgAppPwd;
    }

    public void setOrgAppPwd(String orgAppPwd) {
        this.orgAppPwd = orgAppPwd;
    }

    public String getOrgStatus() {
        return OrgStatus;
    }

    public void setOrgStatus(String orgStatus) {
        OrgStatus = orgStatus;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }
}
