package com.integration.bean.common;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.integration.bean.common.ErrorData;
import com.integration.bean.common.IntegrationError;
import com.integration.service.validation.beans.ErrorBean;

public class ConvertErrorBean {
	
	List<IntegrationError> integrateList = new ArrayList<IntegrationError>();
	
	public ConvertErrorBean(List<ErrorBean> errors) {

		if ( !CollectionUtils.isEmpty(errors))
		{
			for (ErrorBean errorBean : errors) {
				integrateList.add(new ErrorData(errorBean.getName(),errorBean.getMessage()));
				
			}
		}
	}

	public List<IntegrationError> getErrors () 
	{
		return integrateList;
	}

}
