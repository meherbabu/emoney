package com.integration.transformation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.integration.bean.emx.EmxClientDataV2;
import com.integration.bean.emx.EmxClientRequestV2;
import com.integration.bean.sf.SfClientData;
import com.integration.bean.sf.SfClientRequest;


@Service
public class EMoneyToSFRequest {
	
	public SfClientRequest transformRequest(EmxClientRequestV2 clientRequestV2) {
		
		SfClientRequest sfRequest = new SfClientRequest();
	
		List<SfClientData> sfClientdatas = new ArrayList<SfClientData>();
		
		SfClientData sfClientdata = null;
		
		if(clientRequestV2.getSourceSystem() != null && clientRequestV2.getTrackingID() != null) {
			sfRequest.setSourceSystem(clientRequestV2.getSourceSystem());
			sfRequest.setTrackingID(clientRequestV2.getTrackingID());
		}
		
	for(EmxClientDataV2 clientDataV2:clientRequestV2.getClients()) {
		sfClientdata = new SfClientData();
		sfClientdata.setMetadata(clientDataV2.getMetadata());
		sfClientdata.setMessageID(clientDataV2.getMessageID());
		sfClientdata.seteMoneyId(clientDataV2.geteMoneyId());
		sfClientdata.setAddress1(clientDataV2.getAddress1());
		//sfClientdata.setAddress2(clientDataV2.getAddress2());
		sfClientdata.setPostalCode(clientDataV2.getPostalCode());
		sfClientdata.setCity(clientDataV2.getCity());
		sfClientdata.setState(clientDataV2.getState());
		sfClientdata.setBasePlanId(clientDataV2.getBasePlanId());
		sfClientdata.setHomePhone(clientDataV2.getHomePhone());
		sfClientdata.setFax(clientDataV2.getFax());
		sfClientdata.setMaritalStatus(clientDataV2.getMaritalStatus());
		sfClientdata.setClient(clientDataV2.getClient());
		sfClientdata.setSpouse(clientDataV2.getSpouse());
		sfClientdatas.add(sfClientdata);
		
	}
	sfRequest.setClients(sfClientdatas.stream().toArray(SfClientData[]::new));
	
		
		return sfRequest;
	}

}
