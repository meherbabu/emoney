package com.integration.bean.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class MockClient implements Serializable{
	
	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -465803773152689670L;
	
	@JsonProperty("firstName")
	private String firstName;
	
	@JsonProperty("lastName")
	private String lastName;
	
	@JsonProperty("dateOfBirth")
	private String dateOfBirth;
	
	@JsonProperty("gender")
	private String gender;
	
	@JsonProperty("specialNeeds")
	private boolean specialNeeds;
	
	@JsonProperty("inGoodHealth")
	private boolean inGoodHealth;
	
	@JsonProperty("previousMarriages")
	private boolean previousMarriages;
	
	@JsonProperty("citizenship")
	private String citizenship;
	
	@JsonProperty("email")
	private String email;
	
	@JsonProperty("cellPhone")
	private String cellPhone;
	
	@JsonProperty("jobTitle")
	private String jobTitle;
	
	@JsonProperty("job.address1")
	private String jobAddress1;
	
	@JsonProperty("job.address2")
	private String jobAddress2;
	
	@JsonProperty("job.city")
	private String jobCity;
	
	@JsonProperty("job.state")
	private String jobState;
	
	@JsonProperty("job.postalCode")
	private String jobPostalCode;
	
	
	@JsonProperty("job")
	private Job job;
	
	@JsonProperty("businessEmail")
	private String businessEmail;
	
	@JsonProperty("businessFax")
	private String businessFax;
	
	@JsonProperty("businessPhone")
	private String businessPhone;
	
	@JsonProperty("companyName")
	private String companyName;
	
	@JsonProperty("previousEmployerName")
	private String previousEmployerName;
	
	@JsonProperty("previousJobTitle")
	private String previousJobTitle;
	
	@JsonProperty("previousYearsEmployed")
	private String previousYearsEmployed;
	
	@JsonProperty("yearsEmployed")
	private String yearsEmployed;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isSpecialNeeds() {
		return specialNeeds;
	}

	public void setSpecialNeeds(boolean specialNeeds) {
		this.specialNeeds = specialNeeds;
	}

	public boolean isInGoodHealth() {
		return inGoodHealth;
	}

	public void setInGoodHealth(boolean inGoodHealth) {
		this.inGoodHealth = inGoodHealth;
	}

	public boolean isPreviousMarriages() {
		return previousMarriages;
	}

	public void setPreviousMarriages(boolean previousMarriages) {
		this.previousMarriages = previousMarriages;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobAddress1() {
		return jobAddress1;
	}

	public void setJobAddress1(String jobAddress1) {
		this.jobAddress1 = jobAddress1;
	}

	public String getJobAddress2() {
		return jobAddress2;
	}

	public void setJobAddress2(String jobAddress2) {
		this.jobAddress2 = jobAddress2;
	}

	public String getJobCity() {
		return jobCity;
	}

	public void setJobcity(String jobCity) {
		this.jobCity = jobCity;
	}

	public String getJobState() {
		return jobState;
	}

	public void setJobState(String jobState) {
		this.jobState = jobState;
	}

	public String getJobPostalCode() {
		return jobPostalCode;
	}

	public void setJobPostalCode(String jobPostalCode) {
		this.jobPostalCode = jobPostalCode;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public String getBusinessEmail() {
		return businessEmail;
	}

	public void setBusinessEmail(String businessEmail) {
		this.businessEmail = businessEmail;
	}

	public String getBusinessFax() {
		return businessFax;
	}

	public void setBusinessFax(String businessFax) {
		this.businessFax = businessFax;
	}

	public String getBusinessPhone() {
		return businessPhone;
	}

	public void setBusinessPhone(String businessPhone) {
		this.businessPhone = businessPhone;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getPreviousEmployerName() {
		return previousEmployerName;
	}

	public void setPreviousEmployerName(String previousEmployerName) {
		this.previousEmployerName = previousEmployerName;
	}

	public String getPreviousJobTitle() {
		return previousJobTitle;
	}

	public void setPreviousJobTitle(String previousJobTitle) {
		this.previousJobTitle = previousJobTitle;
	}

	public String getPreviousYearsEmployed() {
		return previousYearsEmployed;
	}

	public void setPreviousYearsEmployed(String previousYearsEmployed) {
		this.previousYearsEmployed = previousYearsEmployed;
	}

	public String getYearsEmployed() {
		return yearsEmployed;
	}

	public void setYearsEmployed(String yearsEmployed) {
		this.yearsEmployed = yearsEmployed;
	}

	@Override
	public String toString() {
		return "Client [firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth
				+ ", gender=" + gender + ", specialNeeds=" + specialNeeds + ", inGoodHealth=" + inGoodHealth
				+ ", previousMarriages=" + previousMarriages + ", citizenship=" + citizenship + ", email=" + email
				+ ", cellPhone=" + cellPhone + ", jobTitle=" + jobTitle + ", businessEmail="
				+ businessEmail + ", businessFax=" + businessFax + ", businessPhone=" + businessPhone + ", companyName="
				+ companyName + ", previousEmployerName=" + previousEmployerName + ", previousJobTitle="
				+ previousJobTitle + ", previousYearsEmployed=" + previousYearsEmployed + ", yearsEmployed="
				+ yearsEmployed + "]";
	}

	
}
