package com.integration.bean.sf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
@JsonSerialize
public class Acknowledgement implements Serializable, RmqMessage {
	
	/*
	 * @JsonProperty("eMoney_Id__c") private String eMoney_Id__c;
	 * 
	 * @JsonProperty("eMoney_Id__c") public String geteMoney_Id__c() { return
	 * eMoney_Id__c; }
	 * 
	 * @JsonProperty("eMoney_Id__c") public void seteMoney_Id__c(String
	 * eMoney_Id__c) { this.eMoney_Id__c = eMoney_Id__c; }
	 * 
	 * @Override public String toString() { return "Acknowledgement{" +
	 * "eMoney_Id__c='" + eMoney_Id__c + '\'' + '}'; }
	 */

    @JsonProperty("eMoneyAdv__eMoney_Id__c")
	private String eMoney_Id__c;

	@JsonProperty("eMoneyAdv__eMoney_Id__c")
	public String geteMoney_Id__c() {
		return eMoney_Id__c;
	}

	@JsonProperty("eMoneyAdv__eMoney_Id__c")
	public void seteMoney_Id__c(String eMoney_Id__c) {
		this.eMoney_Id__c = eMoney_Id__c;
	}

	@Override
	public String toString() {
		return "Acknowledgement{" + "eMoney_Id__c='" + eMoney_Id__c + '\'' + '}';
	}
	
	
	
}
