package com.integration.service;

import java.util.Map;

import org.springframework.http.HttpMethod;

import com.integration.bean.common.SourceSystem;
import com.integration.exception.SendToExchangeException;

public interface HandlingExceptionMessages {
	/**
	 *
	 * @param sourceSystem
	 * @param exc
	 * @param source
	 * @param url
	 * @param method
	 * @param headersMap
	 * @param message
	 * @param requestParamsValues
	 */
	public void processException(
			SourceSystem sourceSystem,
			SendToExchangeException exc, 
			String source, String url, 
			HttpMethod method,
			Map<String, String> headersMap, 
			String message, 
			Map<String, Object> requestParamsValues);


	/**
	 *
	 * @param sourceSystem
	 * @param exc
	 * @param source
	 * @param message
	 */
	public void processException(
			SourceSystem sourceSystem,
			SendToExchangeException exc, 
			String source, 
			String message);

	/**
	 * 
	 * @param sourceSystem
	 * @param url
	 * @param method
	 * @param errorCode
	 * @param errorMessage
	 * @param source
	 * @param messagePayload
	 */
	public void processException(
			SourceSystem sourceSystem,
			String url, 
			HttpMethod method,
			String errorCode, 
			String errorMessage, 
			String source, 
			String messagePayload) ;

}
