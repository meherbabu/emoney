package com.integration.bean.emx;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.sf.RmqMessage;

public class EmxNoteRequest implements Serializable,RmqMessage{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 212691292370301703L;

	@NotNull(message="tracking id NULL not allowed")
	 @JsonProperty("trackingID")
	 @Size(min = 3, max = 25,message = "TrackingId min size is 3")
	 private String trackingID;
	 
	 @NotNull(message="sourceSystem null not allowed")
	 @JsonProperty("sourceSystem")
	 @Size(min = 1)
	 private String sourceSystem;
	 
	 @JsonProperty("Notes")
	 @Valid
	 @NotNull(message = "Notes can't be Null")
	 private List<EmxNotesWrapper> notes = null;



	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public List<EmxNotesWrapper> getNotes() {
		return notes;
	}

	public void setNotes(List<EmxNotesWrapper> notes) {
		this.notes = notes;
	}



}
