package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EmxNotesWrapper implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8441252778733654150L;

	@JsonProperty("metadata")
    @NotNull
    private EmxNoteMetadata metadata;

    @JsonProperty("Note")
    private EmxNoteWithNoteId eMoneyNote;

	public EmxNoteMetadata getMetadata() {
		return metadata;
	}

	public void setMetadata(EmxNoteMetadata metadata) {
		this.metadata = metadata;
	}

	public EmxNoteWithNoteId geteMoneyNote() {
		return eMoneyNote;
	}

	public void seteMoneyNote(EmxNoteWithNoteId eMoneyNote) {
		this.eMoneyNote = eMoneyNote;
	}

	@Override
	public String toString() {
		return "EMoneyNotesWrapper [metadata=" + metadata + ", eMoneyNote=" + eMoneyNote + "]";
	}
    
}
