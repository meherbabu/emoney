package com.integration.service.validation.beans;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "var")
public class VarBean {
	@XmlAttribute
	private String name;
	
	@XmlAttribute
	private String value;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	// Only interested in equals name
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if ( obj == null)
			return false;
		
		return String.valueOf(obj).equals(getName());
	}
}
