package com.integration.bean.emx;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.PiiDataLog;

@Component
public class EmxSfClientPiiDataImpl  implements PiiDataLog {

	    @JsonProperty("id")
		private String id;
		
	    @JsonProperty("messageId")
		private String messageId;
		
	    @JsonProperty("emoneyId")
		private String emoneyId ; 

	    public void setPiiData(String trackingId, String emoneyId, String messageId) {			
			this.setId(trackingId);
			this.setemoneyId(emoneyId);
			this.setmessageId(messageId);	
		}
	   
	    public String getId()
	    {
	    	return id ; 
	    }
	    
	  
	    public void setId(String id ) {
	    	this.id = id ;
	    }
	    
	   
	    public String getmessageId() {
	         return messageId;
	    }

      
	    public void setmessageId(String messageId) {
	        this.messageId = messageId;
	    }
	    
       
	    public String getemoneyId()
	    {
	    	return emoneyId;
	    }
	    
	    
	    public void  setemoneyId(String emoneyId)
	    {
	    	this.emoneyId = emoneyId;
	    }
	 
		@Override
		public String logPiiData() {
		   return "SFClientData{" +
	       "id='" + id + '\'' +
	       ", messageId='" + messageId+ '\'' +
	       ", emoneyId=" + emoneyId +
	       '}';
		}
}
