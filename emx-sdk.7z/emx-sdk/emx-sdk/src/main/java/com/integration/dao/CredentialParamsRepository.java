package com.integration.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.CredentialParams;

@Transactional
@Repository
public interface CredentialParamsRepository extends JpaRepository<CredentialParams, Long> {

    /**
     *
     * @param credId
     * @return
     */
    @Query("SELECT p FROM CredentialParams p WHERE LOWER(p.credId) = :cred_id")
    public List<CredentialParams> find(@Param("cred_id") Long credId);
    
    public List<CredentialParams> findAllByCredIdOrderById (Long credId) ;
    
    public Long deleteByCredId (Long credId);

    @Query("SELECT p.paramValue FROM CredentialParams p WHERE  p.paramName = :paramName")
    public String  findByParamName(@Param("paramName") String  paramName);


}
