package com.integration.service;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.exception.AnalyticsEventPublisherException;

@Component
public class AnalyticsEventUtil {

	private AnalyticsProperties analyticsProperties;

	@Autowired
	public AnalyticsEventUtil(AnalyticsProperties analyticsProperties) {
		this.analyticsProperties = analyticsProperties;
	}

	/**
	 * src_destination_eventName_eventType_status_final_finalStatus;
	 */

	/**
	 * 
	 * @param eventName
	 * @return
	 * @throws Exception
	 */
	public AnalyticsEventWrapper getEvent(String eventName) throws AnalyticsEventPublisherException {

		if (!analyticsProperties.getEvents().containsKey(eventName)) {
			throw new AnalyticsEventPublisherException("Event [" + eventName + "] does not exist");
		}

		AnalyticsEventWrapper wrapper = newWrapperInstance();
		List<String> eventPair = analyticsProperties.getEvents().get(eventName);
		try {

			for (String string : eventPair) {
				String[] propertyValue = string.split(":");
				BeanUtils.setProperty(wrapper, propertyValue[0], propertyValue[1]);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AnalyticsEventPublisherException(" Exception occurs in Event [" + eventName + "]", e);
		}

		return wrapper;
	}
	/**
	 * 
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */
	public AnalyticsEventWrapper getEvent() throws AnalyticsEventPublisherException {
		return newWrapperInstance();
	}
	
	@Bean
	private AnalyticsEventWrapper newWrapperInstance ()
	{
		return new AnalyticsEventWrapper().curentTime();
	}

}
