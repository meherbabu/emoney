
package com.integration.bean.emx;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"clientId",
	"eMoneyId",	
	"timeStamp",
	"subject",
	"description",
	"displayName",
	"dismissed"
	})
public class EmxAlert implements Serializable
{
		@JsonProperty("clientId")
		private String clientId;
		@JsonProperty("eMoneyId")
		private String eMoneyId;	
		@JsonProperty("timeStamp")
		private String timeStamp;
		@JsonProperty("subject")
		private String subject;
		@JsonProperty("description")
		private String description;
		@JsonProperty("displayName")
		private String displayName;
		@JsonProperty("dismissed")
		private boolean dismissed;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();
		private final static long serialVersionUID = 6761409200516658202L;
		
		@JsonProperty("clientId")
		public String getClientId() {
			return clientId;
		}
		@JsonProperty("clientId")
		public void setClientId(String clientId) {
			this.clientId = clientId;
		}
		@JsonProperty("eMoneyId")
		public String geteMoneyId() {
			return eMoneyId;
		}
		@JsonProperty("eMoneyId")
		public void seteMoneyId(String eMoneyId) {
			this.eMoneyId = eMoneyId;
		}
		@JsonProperty("dismissed")
		public boolean getDismissed() {
			return dismissed;
		}
		@JsonProperty("dismissed")
		public void setDismissed(boolean dismissed) {
			this.dismissed = dismissed;
		}
		
		@JsonProperty("timeStamp")
		public String getTimeStamp() {
		return timeStamp;
		}
		
		@JsonProperty("timeStamp")
		public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
		}
		
		@JsonProperty("subject")
		public String getSubject() {
		return subject;
		}
		
		@JsonProperty("subject")
		public void setSubject(String subject) {
		this.subject = subject;
		}
		
		@JsonProperty("description")
		public String getDescription() {
		return description;
		}
		
		@JsonProperty("description")
		public void setDescription(String description) {
		this.description = description;
		}
		
		@JsonProperty("displayName")
		public String getDisplayName() {
		return displayName;
		}
		
		@JsonProperty("displayName")
		public void setDisplayName(String displayName) {
		this.displayName = displayName;
		}		
		
		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
		}
		
		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
		}

}