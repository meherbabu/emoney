package com.integration.exception;

import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

public class SendToExchangeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SendToExchangeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SendToExchangeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SendToExchangeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SendToExchangeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SendToExchangeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 * @return
	 */
	public int getStatusCode ()
	{
		if ( this.getCause() != null && this.getCause() instanceof HttpClientErrorException)
		{
			return ((HttpClientErrorException) this.getCause()).getStatusCode().value() ;
		}
		if ( this.getCause() != null && this.getCause() instanceof HttpServerErrorException)
		{
			return ((HttpServerErrorException) this.getCause()).getStatusCode().value() ;
		}
		return 9999;
	}
	
	@Override
	public String getMessage() {
		if ( this.getCause() != null && this.getCause() instanceof HttpClientErrorException)
		{
			return ((HttpClientErrorException) this.getCause()).getResponseBodyAsString();
		}
		if ( this.getCause() != null && this.getCause() instanceof HttpServerErrorException)
		{
			return ((HttpServerErrorException) this.getCause()).getResponseBodyAsString();
		}
		return this.getCause().getMessage();
	}

	/**
	 * 
	 * @return
	 */
	public String getErrorMessage ()
	{
		if ( this.getCause() != null)
		{
			this.getCause().getMessage();
		}
		return this.getMessage();
	}
	
	


}
