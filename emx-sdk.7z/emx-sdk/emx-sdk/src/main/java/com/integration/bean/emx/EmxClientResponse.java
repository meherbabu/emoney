package com.integration.bean.emx;

import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.sf.RmqMessage;

@JsonSerialize
public class EmxClientResponse implements Serializable, RmqMessage{

	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -3415008222229383479L;
	
	//Added
	
	@JsonProperty("id")
	private String id;

	@JsonProperty("client")
	private EmxClient client;
	
	@JsonProperty("spouse")
	private EmxClient spouse;
	
	@JsonProperty("address")
	private EmxAddress address;
	
	@JsonProperty("homePhone")
	private String homePhone;
	
	@JsonProperty("fax")
	private String fax;
	
	@JsonProperty("maritalStatus")
	private String maritalStatus;
	
	@JsonProperty("basePlanId")
	private String basePlanId;
    @JsonProperty("ownerId")
	private  String ownerId;
    @JsonProperty("designation")
	private String designation;

    @JsonProperty("sfClientId")
    private String sfClientId;
    @JsonProperty("orgId")
    private String orgId;

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getSfClientId() {
		return sfClientId;
	}

	public void setSfClientId(String sfClientId) {
		this.sfClientId = sfClientId;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EmxClient getClient() {
		return client;
	}

	public void setClient(EmxClient client) {
		this.client = client;
	}

	public EmxClient getSpouse() {
		return spouse;
	}

	public void setSpouse(EmxClient spouse) {
		this.spouse = spouse;
	}

	public EmxAddress getAddress() {
		return address;
	}

	public void setAddress(EmxAddress address) {
		this.address = address;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getBasePlanId() {
		return basePlanId;
	}

	public void setBasePlanId(String basePlanId) {
		this.basePlanId = basePlanId;
	}

	@Override
	public String toString() {
		return "EMoneyClientResponse{" +
				"id='" + id + '\'' +
				", client=" + client +
				", spouse=" + spouse +
				", address=" + address +
				", homePhone='" + homePhone + '\'' +
				", fax='" + fax + '\'' +
				", maritalStatus='" + maritalStatus + '\'' +
				", basePlanId='" + basePlanId + '\'' +
				", ownerId='" + ownerId + '\'' +
				", designation='" + designation + '\'' +
				", sfClientId='" + sfClientId + '\'' +
				", orgId='" + orgId + '\'' +
				'}';
	}
}
