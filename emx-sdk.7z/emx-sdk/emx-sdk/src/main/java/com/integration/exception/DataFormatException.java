package com.integration.exception;

import java.util.List;

import com.integration.bean.common.IntegrationError;

/**
 * for HTTP BAD_REQUEST errors
 * This is thrown when we a schema validation fails or a format is bad ex date is not in a DDMMYYYY or Tel # is invalid
 */
public final class DataFormatException  extends AbstractIntegrationException  {

    public DataFormatException(String s) {
        super(s);
    }

    public DataFormatException(List<IntegrationError> integrationErrors) {
        super(integrationErrors);
    }

    public DataFormatException(IntegrationError integrationError) {
        super(integrationError);
    }


}