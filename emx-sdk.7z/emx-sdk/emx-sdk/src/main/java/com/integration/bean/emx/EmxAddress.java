package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class EmxAddress implements Serializable{
	

	private static final long serialVersionUID = -164944591594629685L;

	@Size(max = 100)
	@JsonProperty("address1")
	private String address1;
	
	@Size(max = 100)
	@JsonProperty("address2")
	private String address2;
	
	@Size(max = 50)
	@JsonProperty("city")
	private String city;
	
	@JsonProperty("state")
	private String state;
	
	@Size(max = 5)
	@Pattern(regexp = "^[0-9]{5}$", message="postalCode must be number only and 5 digits")
	@JsonProperty("postalCode")
	private String postalCode;

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	@Override
	public String toString() {
		return "JobAddress [address1=" + address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state
				+ ", postalCode=" + postalCode + "]";
	}
	
}
