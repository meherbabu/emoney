package com.integration.bean.sf;

public class SfClientErrorResponse {
	
	/**
	 * Added to handle VO request
	 */
	
	private ErrorData errors;

	public ErrorData getErrors() {
		return errors;
	}

	public void setErrors(ErrorData errors) {
		this.errors = errors;
	}
	
	
	
}
