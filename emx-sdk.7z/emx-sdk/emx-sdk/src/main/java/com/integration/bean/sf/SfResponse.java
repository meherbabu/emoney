package com.integration.bean.sf;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.io.Serializable;

@JsonSerialize
public class SfResponse implements Serializable,RmqMessage {

    @JsonProperty("success")
    private Boolean success;
    @JsonProperty("id")
    private String id;
    @JsonProperty("errorStatusCode")
    private String errorStatusCode;
    @JsonProperty("errorMessage")
    private String errorMessage;
    @JsonProperty("eMoneyId")
    private String eMoneyId;


    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getErrorStatusCode() {
        return errorStatusCode;
    }

    public void setErrorStatusCode(String errorStatusCode) {
        this.errorStatusCode = errorStatusCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String geteMoneyId() {
        return eMoneyId;
    }

    public void seteMoneyId(String eMoneyId) {
        this.eMoneyId = eMoneyId;
    }

    @Override
    public String toString() {
        return "SFResponse{" +
                "success=" + success +
                ", id='" + id + '\'' +
                ", errorStatusCode='" + errorStatusCode + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                ", eMoneyId='" + eMoneyId + '\'' +
                '}';
    }
}
