package com.integration.exception;

import java.util.List;

import com.integration.bean.common.IntegrationError;

/**
 * for HTTP BAD_RESYUQ errors
 */
public class DataMappingException extends AbstractIntegrationException {

    public DataMappingException(String s) {
        super(s);
    }

    public DataMappingException(List<IntegrationError> integrationErrors) {
        super(integrationErrors);
    }

    public DataMappingException(IntegrationError integrationError) {
        super(integrationError);
    }
}