package com.integration.bean.sf;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SfNoteRequest implements Serializable,RmqMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1997993415437591771L;
	
	 @NotNull(message="tracking id NULL not allowed")
	 @JsonProperty("trackingID")
	 @Size(min = 3, max = 25,message = "TrackingId min size is 3")
	 private String trackingID;
	 
	 @NotNull(message="sourceSystem null not allowed")
	 @JsonProperty("sourceSystem")
	 @Size(min = 1)
	 private String sourceSystem;
	 
	 @JsonProperty("Notes")
	 @Valid
	 @NotNull(message = "Notes can't be Null")
	 private List<SfNotesWrapper> notes = null;



	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public List<SfNotesWrapper> getNotes() {
		return notes;
	}

	public void setNotes(List<SfNotesWrapper> notes) {
		this.notes = notes;
	}


}
