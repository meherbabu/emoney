package com.integration.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoggerUtil {

    public static Log getLog (Object c) {
        Log logger = LogFactory.getLog(c.getClass());
        return logger;
    }

}
