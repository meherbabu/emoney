package com.integration.bean.sf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.Metadata;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

public class SfNotesWrapper implements Serializable {

    @JsonProperty("metadata")
    @NotNull
    private Metadata metadata;

    @JsonProperty("note")
    private SfNote sfNote;

    public Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public SfNote getSfNote() {
        return sfNote;
    }

    public void setSfNote(SfNote sfNote) {
        this.sfNote = sfNote;
    }

    @Override
    public String toString() {
        return "SFNotesWrapper{" +
                "metadata=" + metadata +
                ", sfNote=" + sfNote +
                '}';
    }
}
