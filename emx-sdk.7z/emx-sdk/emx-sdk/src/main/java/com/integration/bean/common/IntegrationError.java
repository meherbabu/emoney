package com.integration.bean.common;

public interface IntegrationError {

    String getErrorCode();
    String getErrorDesc();



}
