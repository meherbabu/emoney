package com.integration.service;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.integration.bean.common.MessageType;
import com.integration.exception.DataProcessingException;

@Component
public class SfToEmxCommonUtil {
	Log logger = LoggerUtil.getLog(this);
	
	/**
	 * @param message
	 * @return this array contain String[trackingID, office,"clientId","noteId"]
	 * @throws Exception 
	 */
	public String[] getSfNoteInfoFromMessageQueue(String message, MessageType operation) throws DataProcessingException {
		logger.info("Start CommonUtils.getSfNoteInfoFromMessageQueue");
		// trackingID, orgId, office,clientId, noteId, eMoneyId
		String[] data = new String[6];// data mapping like this {data[0] = trackingID,data[1] = office,data[2] = clientId,data[3] = noteId }
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			data[0] = rootNode.get("trackingID").textValue();
			
			JsonNode noteNodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode noteNode : noteNodes) {
				listNode.add(noteNode);
			}
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				data[1]  = jsonNode2.get("metadata").get("orgId").asText();
				data[2]  = jsonNode2.get("metadata").get("office").asText();
				data[3]  = StringUtils.isEmpty(jsonNode2.get("note").get("eMoneyId"))?"": jsonNode2.get("note").get("eMoneyId").asText();
				data[4]  = StringUtils.isEmpty(jsonNode2.get("note").get("noteId"))?"": jsonNode2.get("note").get("noteId").asText();
				if(operation == MessageType.UPDATE) {
					data[5]  = StringUtils.isEmpty(jsonNode2.get("note").get("eMoneyNoteId"))?"": jsonNode2.get("note").get("eMoneyNoteId").asText(); 
				}
			}

		} catch (Exception e) {

			logger.error("Exception in getSfNoteInfoFromMessageQueue", e);
			throw new DataProcessingException("Exception  in getSfNoteInfoFromMessageQueue");
		} finally {
			logger.info("End CommonUtils.getSfNoteInfoFromMessageQueue");

		}
		return data;
	}

	/**
	 * 
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> transformNoteUpdateMessage(String message) throws Exception {
		logger.info("Start SalesforceToEmxCommonUtils.transformNoteUpdateMessage");
		// this array contain Object["orgId","office","clientId","noteId","Slit message by Note"]
		List<Object[]> data = new ArrayList<Object[]>();
		try {
			
			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();
			
			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			// Remove All node here
			for (JsonNode jsonNode2 : listNode) {
				//ArrayNode arrayNode = ((ArrayNode)rootNode).removeAll();	
				// get officeName 
				String orgId = jsonNode2.get("metadata").get ("orgId").asText();
				String officeName = jsonNode2.get("metadata").get ("office").asText();
				String clientId = jsonNode2.get("note").get("eMoneyId").asText();
				String sfNoteId = jsonNode2.get("note").get("noteId").asText();
				String noteId = jsonNode2.get("note").get("eMoneyNoteId").asText();
				String noteText = jsonNode2.get("note").get("text").asText();
				((ObjectNode) jsonNode2).remove("metadata");
				((ObjectNode) jsonNode2).remove("note");
				ObjectNode textNode = objectMapper.createObjectNode();
				textNode.put("text", formatMessageForEMX(noteText));
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(textNode));
				data.add(new Object[] {orgId, officeName, clientId, noteId,sfNoteId, buffer});
				
			}
			

		} catch (Exception e) {
			
			logger.error("Exception in transformClientUpdateMessage",e);
			throw e;
		}
		finally
		{
			logger.info("End ProcessEmxMessageImpl.transformClientUpdateMessage");

		}
		return data;
	}

	
	public String formatMessageForEMX(String commentsTxt) {
		if (StringUtils.isEmpty(commentsTxt)) {
			return "";
		}

		if (commentsTxt.contains("\\r\\n")) {
			return commentsTxt.replaceAll("\\\\r\\\\n", "<br/>");
		} else if (commentsTxt.contains("\\n")) {
			return commentsTxt.replaceAll("\\\\n", "<br/>");
		}

		return commentsTxt;
	}		
	
}
