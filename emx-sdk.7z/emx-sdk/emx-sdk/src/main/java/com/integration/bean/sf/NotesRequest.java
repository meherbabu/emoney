package com.integration.bean.sf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@JsonSerialize
public class NotesRequest implements RmqMessage,Serializable {

    @JsonProperty("trackingID")
    @NotNull
    private String trackingID;
    @JsonProperty("sourceSystem")
    @NotNull
    private String sourceSystem;
    @JsonProperty("notes")
    @Valid
    private SfNotesWrapper notes ;

    public String getTrackingID() {
        return trackingID;
    }

    public void setTrackingID(String trackingID) {
        this.trackingID = trackingID;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public SfNotesWrapper getNotes() {
        return notes;
    }

    public void setNotes(SfNotesWrapper notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "NotesRequest{" +
                "trackingID='" + trackingID + '\'' +
                ", sourceSystem='" + sourceSystem + '\'' +
                ", notes=" + notes +
                '}';
    }
}
