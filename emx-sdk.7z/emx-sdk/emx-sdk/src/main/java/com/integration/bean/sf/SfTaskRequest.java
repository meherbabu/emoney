package com.integration.bean.sf;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "trackingID",
        "sourceSystem",
        "tasks"
})
@JsonSerialize
public class SfTaskRequest implements Serializable,RmqMessage
{

    @NotNull(message="tracking id NULL not allowed")
   @JsonProperty("trackingID")
   @Size(min = 3, max = 25,message = "TrackingId min size is 3")
    private String trackingID;
    @NotNull(message="sourceSystem null not allowed")
    @JsonProperty("sourceSystem")
    @Size(min = 1)
    private String sourceSystem;
    @JsonProperty("tasks")
    @Valid
    @NotNull(message = "tasks can't be Null")
    private List<SfTaskWrapper> tasks = null;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -2183851211482032454L;

    @JsonProperty("trackingID")
    public String getTrackingID() {
        return trackingID;
    }

    @JsonProperty("trackingID")
    public void setTrackingID(String trackingID) {
        this.trackingID = trackingID;
    }

    @JsonProperty("sourceSystem")
    public String getSourceSystem() {
        return sourceSystem;
    }

    @JsonProperty("sourceSystem")
    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    @JsonProperty("tasks")
    public List<SfTaskWrapper> getTasks() {
        return tasks;
    }

    @JsonProperty("tasks")
    public void setTasks(List<SfTaskWrapper> tasks) {
        this.tasks = tasks;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "SFTaskRequest{" +
                "trackingID='" + trackingID + '\'' +
                ", sourceSystem='" + sourceSystem + '\'' +
                ", tasks=" + tasks +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}