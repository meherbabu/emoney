package com.integration.exception;

import java.util.List;

import com.integration.bean.common.IntegrationError;

/**
 * for HTTP BAD_RESYUQ errors
 */
public class DataProcessingException extends AbstractIntegrationException {

    public DataProcessingException(String s) {
        super(s);
    }

    public DataProcessingException(List<IntegrationError> integrationErrors) {
        super(integrationErrors);
    }

    public DataProcessingException(IntegrationError integrationError) {
        super(integrationError);
    }
}