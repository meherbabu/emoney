package com.integration.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.SfEmxMapping;

@Repository
@Transactional
public interface SfEmxMappingRepository extends JpaRepository<SfEmxMapping, Long> {

	@Query("SELECT p FROM SfEmxMapping p WHERE p.semId = :semId")
	public List<SfEmxMapping> findAllByHeaderMapId(@Param("semId") Long semId);

	@Query("delete from SfEmxMapping p WHERE p.semId = :semId")
	@Modifying
	@Transactional
	public int deleteAllByHeaderMapId(@Param("semId") Long semId);

}
