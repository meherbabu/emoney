
package com.integration.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MessageSenderImpl implements MessageSender {

	private static final Logger logger = LoggerFactory.getLogger(MessageSenderImpl.class);

	private final RabbitTemplate rabbitTemplate;

	/**
	 * 
	 * @param rabbitTemplate
	 */
	@Autowired
	public MessageSenderImpl(final RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
	}

	@Override
	public void send(String exchange, String routingkey, boolean isPersistent, String message) {
		send(exchange, routingkey, isPersistent, message, "application/json");
	}

	@Override
	public void send(String exchange, String routingkey, boolean isPersistent, String message, String contextType) {

		logger.info("***Start MessageSenderImpl --> send ***");

		Message contextMessage = MessageBuilder.withBody(message.getBytes()).andProperties(MessagePropertiesBuilder
				.newInstance().setContentType(contextType).setDeliveryMode(getDeliveryMode(isPersistent)).build())
				.build();

		logger.info("***exchange::" + exchange + " # routingkey::" + routingkey);
		logger.debug("***" + contextType + "::" + contextMessage);
		rabbitTemplate.convertAndSend(exchange, routingkey, contextMessage);
		logger.info("***Start MessageSenderImpl --> send ***");
	}

	private MessageDeliveryMode getDeliveryMode(boolean isPersistent) {
		MessageDeliveryMode deliveryMode;
		if (isPersistent) {
			deliveryMode = MessageDeliveryMode.PERSISTENT;
		} else {
			deliveryMode = MessageDeliveryMode.NON_PERSISTENT;
		}
		return deliveryMode;
	}

}
