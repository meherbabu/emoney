package com.integration.service.validation.beans;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlRootElement(name = "property")
public class PropertyBean {

	@XmlAttribute
	private String name;

	@XmlAttribute
	private String template;

	@XmlAttribute
	private String isList;

	@XmlAttribute
	private String empty;

	@XmlAttribute
	private String notEmpty_;

	@XmlAttribute
	private String required_;

	@XmlElement(name = "notEmpty")
	private ValidatorBean notEmpty;

	@XmlElement(name = "size")
	private ValidatorBean size;

	@XmlElement(name = "min")
	private ValidatorBean min;

	@XmlElement(name = "max")
	private ValidatorBean max;

	@XmlElement(name = "matchPattern")
	private ValidatorBean matchPattern;

	@XmlElement(name = "isDate")
	private ValidatorBean isDate;

	@XmlElement(name = "required")
	private ValidatorBean required;

	@XmlElement(name = "isContain")
	private ValidatorBean isContain;

	@XmlElement(name = "isValid")
	private ValidatorBean isValid;

	public ValidatorBean getIsDate() {
		return isDate;
	}

	public void setIsDate(ValidatorBean isDate) {
		this.isDate = isDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ValidatorBean getSize() {
		return size;
	}

	public void setSize(ValidatorBean size) {
		this.size = size;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public String getIsList() {
		return isList;
	}

	public void setIsList(String isList) {
		this.isList = isList;
	}

	public ValidatorBean getMin() {
		return min;
	}

	public void setMin(ValidatorBean min) {
		this.min = min;
	}

	public ValidatorBean getMax() {
		return max;
	}

	public void setMax(ValidatorBean max) {
		this.max = max;
	}

	public ValidatorBean getMatchPattern() {
		return matchPattern;
	}

	public void setMatchPattern(ValidatorBean matchPattern) {
		this.matchPattern = matchPattern;
	}

	public String getEmpty() {
		return empty;
	}

	public void setEmpty(String empty) {
		this.empty = empty;
	}

	public ValidatorBean getIsContain() {
		return isContain;
	}

	public void setIsContain(ValidatorBean isContain) {
		this.isContain = isContain;
	}

	public String getNotEmpty_() {
		return notEmpty_;
	}

	public void setNotEmpty_(String notEmpty_) {
		this.notEmpty_ = notEmpty_;
	}

	public String getRequired_() {
		return required_;
	}

	public void setRequired_(String required_) {
		this.required_ = required_;
	}

	public ValidatorBean getNotEmpty() {
		return notEmpty;
	}

	public void setNotEmpty(ValidatorBean notEmpty) {
		this.notEmpty = notEmpty;
	}

	public ValidatorBean getRequired() {
		return required;
	}

	public void setRequired(ValidatorBean required) {
		this.required = required;
	}

	public ValidatorBean getIsValid() {
		return isValid;
	}

	public void setIsValid(ValidatorBean isValid) {
		this.isValid = isValid;
	}

}
