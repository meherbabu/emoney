package com.integration.bean.sf;

import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class SfClientResponse implements Serializable, RmqMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8966313896860713247L;
	
	@JsonProperty("trackingID")
	private String trackingID;
	
	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@JsonProperty("clients")
	private SfClientData[] clients;

	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}


	public SfClientData[] getClients() {
		return clients;
	}

	public void setClients(SfClientData[] clients) {
		this.clients = clients;
	}

	@Override
	public String toString() {
		return "SFClientRequest [trackingID=" + trackingID + ", sourceSystem=" + sourceSystem + ", clients=" + clients
				+ "]";
	}
	
	

}
