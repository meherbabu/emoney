package com.integration.service;

import java.util.ArrayList;
import java.util.Map;

public interface AnalyticsProperties {

	public Map<String, ArrayList<String>> getEvents();

}
