package com.integration.exception;

import java.util.List;

import com.integration.bean.common.IntegrationError;

/**
 * for HTTP BAD_RESYUQ errors
 */
public class DataPublishingException extends AbstractIntegrationException {

    public DataPublishingException(String s) {
        super(s);
    }

    public DataPublishingException(List<IntegrationError> integrationErrors) {
        super(integrationErrors);
    }

    public DataPublishingException(IntegrationError integrationError) {
        super(integrationError);
    }

	public DataPublishingException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
    
    
}