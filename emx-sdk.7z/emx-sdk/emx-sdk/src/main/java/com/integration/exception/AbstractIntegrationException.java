package com.integration.exception;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.integration.bean.common.ErrorData;
import com.integration.bean.common.IntegrationError;
import com.integration.service.JsonUtility;

/**
 * for HTTP 4XX errors
 */
public abstract class AbstractIntegrationException extends Exception {

	
/*	@Autowired
	JsonUtility jsonUtility;*/
	
    public AbstractIntegrationException (String s) {
        super();
        IntegrationError error = new ErrorData("", s);
        this.integrationErrors.add(error) ;
    }

    List<IntegrationError> integrationErrors = new ArrayList<IntegrationError>();

    public AbstractIntegrationException(List<IntegrationError> integrationErrors) {
        super();
        this.integrationErrors = integrationErrors ;
    }

    public AbstractIntegrationException(IntegrationError integrationError) {
        super();
        this.integrationErrors.add(integrationError) ;
    }



    public AbstractIntegrationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
    public String getMessage() {
        try {
        	JsonUtility jstemp = new JsonUtility();
            return  jstemp.getJsonStringFromObject(integrationErrors);
        } catch (JsonProcessingException e) {
            return super.getMessage();
        }
    }
}