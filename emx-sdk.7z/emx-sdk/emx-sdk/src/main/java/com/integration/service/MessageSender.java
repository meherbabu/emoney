
package com.integration.service;

public interface MessageSender {

	/**
	 *
	 * @param exchange
	 * @param routingkey
	 * @param message
	 */
	void send(String exchange, String routingkey, boolean isPersistent, String message);
	/**
	 * 
	 * @param exchange
	 * @param routingkey
	 * @param message
	 * @param contextType
	 */
	void send(String exchange, String routingkey, boolean isPersistent, String message, String contextType);

}
