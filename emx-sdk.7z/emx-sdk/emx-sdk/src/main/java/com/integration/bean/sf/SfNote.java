
package com.integration.bean.sf;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({
        "eMoneyId",
        "noteId",
        "text",

})

public class SfNote
        implements Serializable {

	@NotNull(message="clientId NULL not allowed")
	@JsonProperty("eMoneyId")
    private String eMoneyId;

	@NotNull(message="noteId NULL not allowed")
	@JsonProperty("noteId")
    private String noteId;
    
    @JsonProperty("text")
    private String text;
    
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -4176803928294684542L;

    @JsonProperty("eMoneyId")
    public String geteMoneyId() {
        return eMoneyId;
    }
    @JsonProperty("eMoneyId")
    public void seteMoneyId(String eMoneyId) {
        this.eMoneyId = eMoneyId;
    }

    @JsonProperty("text")
    public String getText() {
        return text;
    }

    @JsonProperty("text")
    public void setText(String text) {
        this.text = text;
    }

    public SfNote withText(String text) {
        this.text = text;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SfNote withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return "SFNote{" +
                "clientId='" + eMoneyId + '\'' +
                ", noteId='" + noteId + '\'' +
                ", text='" + text + '\'' +
                ", additionalProperties=" + additionalProperties +
                '}';
    }

    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }
}