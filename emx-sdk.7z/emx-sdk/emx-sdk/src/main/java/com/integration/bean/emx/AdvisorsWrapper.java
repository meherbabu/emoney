package com.integration.bean.emx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;

@JsonSerialize
public class AdvisorsWrapper implements Serializable {
    @JsonProperty("trackingId")
    private String trackingId ;
    @JsonProperty("orgId")
    private String orgId ;
    @JsonProperty("sfOffice")
    private String sfOffice ;
    @JsonProperty("advisors")
    private Advisors advisors;


    @JsonProperty("trackingId")
    public String getTrackingId() {
        return trackingId;
    }
    @JsonProperty("trackingId")
    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }
    @JsonProperty("orgId")
    public String getOrgId() {
        return orgId;
    }
    @JsonProperty("orgId")
    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }
    @JsonProperty("sfOffice")
    public String getSfOffice() {
        return sfOffice;
    }
    @JsonProperty("sfOffice")
    public void setSfOffice(String sfOffice) {
        this.sfOffice = sfOffice;
    }
    @JsonProperty("advisors")
    public Advisors getAdvisors() {
        return advisors;
    }
    @JsonProperty("advisors")
    public void setAdvisors(Advisors advisors) {
        this.advisors = advisors;
    }

    @Override
    public String toString() {
        return "AdvisorsWrapper{" +
                "trackingId='" + trackingId + '\'' +
                ", orgId='" + orgId + '\'' +
                ", sfOffice='" + sfOffice + '\'' +
                ", advisors=" + advisors +
                '}';
    }
}
