package com.integration.service.token;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class JWTTokenParams {

	@JsonProperty("alg")
	private String alg;

	@JsonProperty("iss")
	private String iss;

	@JsonProperty("sub")
	private String sub;

	@JsonProperty("aud")
	private String aud;

	@JsonProperty("expiredTimeInMinutes")
	private int expiredTimeInMinutes;

	@JsonIgnore
	private String privateKeyString;

	@JsonProperty("accessToken")
	private String accessToken;

	@JsonProperty("url")
	private String url;

	@JsonProperty("adminToken")
	private String adminToken;

	@JsonProperty("privateKey")
	private String privateKey;

	@JsonProperty("publicKey")
	private String publicKey;

	public void setAdminToken(String adminToken) {
		this.adminToken = adminToken;
	}

	public String getAdminToken() {
		return adminToken;
	}

	public JWTTokenParams() {
	}

	public String getAlg() {
		return alg;
	}

	public void setAlg(String alg) {
		this.alg = alg;
	}

	public String getIss() {
		return iss;
	}

	public void setIss(String iss) {
		this.iss = iss;
	}

	public String getSub() {
		return sub;
	}

	public void setSub(String sub) {
		this.sub = sub;
	}

	public String getAud() {
		return aud;
	}

	public void setAud(String aud) {
		this.aud = aud;
	}

	public int getExpiredTimeInMinutes() {
		return expiredTimeInMinutes;
	}

	public void setExpiredTimeInMinutes(int expiredTimeInMinutes) {
		this.expiredTimeInMinutes = expiredTimeInMinutes;
	}

	public String getPrivateKeyString() {
		return privateKeyString;
	}

	public void setPrivateKeyString(String privateKeyString) {
		this.privateKeyString = privateKeyString;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("alg [").append(this.alg).append("]");
		buffer.append("iss [").append(this.iss).append("]");
		buffer.append("sub [").append(this.sub).append("]");
		buffer.append("aud [").append(this.aud).append("]");
		buffer.append("expiredTimeInMinutes [").append(this.expiredTimeInMinutes).append("]");
		buffer.append("privateKeyString [").append("*****Hidden*****").append("]");
		buffer.append("accessToken [").append(this.accessToken).append("]");
		buffer.append("adminToken [").append(this.adminToken).append("]");
		buffer.append("url [").append(this.url).append("]");
		return buffer.toString();
	}

}
