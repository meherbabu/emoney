package com.integration.bean.common;

public enum EnumEventCurrentStatus {	
	RECEIVED,
	VALIDATING,
	SPLITTING,
	TRANSFORMING,
	PUSHED_RMQ,	
	CALLTOEMX,
	CALLTOSF,
	STAGED,
	PROCESSED,
	SENDING_FOR_ACK;	
}
