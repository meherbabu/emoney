package com.integration.service.validation.beans;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

@XmlRootElement(name = "template")
public class TemplateBean {

	@XmlAttribute
	private String name;
	
	@JacksonXmlElementWrapper(localName = "properties")
	List<PropertyBean> propertyList = new ArrayList<PropertyBean>();

	public List<PropertyBean> getPropertyList() {
		return propertyList;
	}

	public void setPropertyList(List<PropertyBean> propertyList) {
		this.propertyList = propertyList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

}
