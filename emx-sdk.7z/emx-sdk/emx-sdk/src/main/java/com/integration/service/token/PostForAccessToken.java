package com.integration.service.token;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.integration.service.JsonUtility;
@Component
public class PostForAccessToken {
	Log logger = LogFactory.getLog(PostForAccessToken.class);

	private JsonUtility jsonUtil;
	
	
	@Autowired
	public PostForAccessToken(JsonUtility jsonUtil) {
		this.jsonUtil = jsonUtil;
	}

	/**
	 * 
	 * @param url
	 * @param requestParamsValues
	 * @return
	 */
	private Map<String, Object> getAccessToken(String url, Map<String, String> headersMap, Map<String, String> paramsMap) throws Exception
	{
		logger.info("Start AccessToken.getAccessToken");
		ResponseEntity<String> response;
		try {

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headersMap.forEach((k, v) -> {
				headers.add(k, v);
			});

			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			paramsMap.forEach((k, v) -> {
				map.add(k, v);
			});

			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map,
					headers);
			logger.info("URL "+ url);
			logger.info("Request for access token "+ request);
			response = restTemplate.postForEntity(url, request, String.class);

			if (response == null || StringUtils.isEmpty(response.getBody())) {
				throw new Exception("AccessToken response is blank ");
			}

			return jsonUtil.getMapFromJsonString(response.getBody());

		} catch (HttpClientErrorException e) {
			logger.error("httpClientErrorException occurs in AccessToken.getAccessToken ", e);
			throw e;
		} catch (Exception e) {
			logger.error("Exception occurs in AccessToken.getAccessToken ", e);
			throw e;
		} finally {
			logger.info("End AccessToken.getAccessToken");
		}
	}

	/**
	 * 
	 * @param url
	 * @param requestParamsValues
	 * @return
	 */
	public Map<String, Object> getSaleforceAccessToken(String url, Map<String, String> headersMap, Map<String, String> paramsMap)
			throws Exception {
		logger.info("Start AccessToken.getAccessToken");
		return getAccessToken( url,  headersMap, paramsMap);
	}
	/**
	 * 
	 * @param url
	 * @param requestParamsValues
	 * @return
	 */
	public Map<String, Object> getEmoneyAccessToken(String url, Map<String, String> headersMap, Map<String, String> paramsMap)
			throws Exception {
		logger.info("Start AccessToken.getAccessToken");
		return getSaleforceAccessToken(url, headersMap, paramsMap);

	}

}
