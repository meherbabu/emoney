package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.common.Client;
import com.integration.bean.common.Metadata;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonSerialize
@ApiModel(description = "Sample EMXClientRequest Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
public class EmxClientDataV2 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1581945807582990347L;
	
	@NotNull(message="Metadata cannotbe null")
	@Valid
	@JsonProperty("metadata")
	private Metadata metadata;
	
	@NotNull(message="MessageID cannotbe null")
	@JsonProperty("messageID")
	private String messageID;
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("eMoneyId")
	private String eMoneyId;
	
	@Size(max = 100)
	@JsonProperty("address1")
	private String address1;
	
	@Size( max = 100)
	@JsonProperty("address2")
	private String address2;
	
	@Size(max = 50)
	@JsonProperty("city")
	private String city;
	
	@Size(max = 5)
	@Pattern(regexp = "^[0-9]{5}$", message="postalCode must be number only and 5 digits")
	@JsonProperty("postalCode")
	private String postalCode;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("basePlanId")
	private String basePlanId;
	
	@Size(max = 19)
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "homePhone must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	@JsonProperty("homePhone")
	private String homePhone;
	
	@Size(max = 19)
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "fax must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	@JsonProperty("fax")
	private String fax;
	
	@JsonProperty("maritalStatus")
	private String maritalStatus;
	
	@NotNull(message="Client cannotbe null")
	@Valid
	@JsonProperty("client")
	private Client client;
	
	@NotNull(message="spouse cannotbe null")
	@Valid
	@JsonProperty("spouse")
	private Client spouse;

	@Valid
	@ApiModelProperty(required = true, value = "The request message must contain Metadata.It cannot be null and empty")
	public Metadata getMetadata() {
	return metadata;
	}

	public void setMetadata(Metadata metadata) {
	this.metadata = metadata;
	}
	
	@ApiModelProperty(required = true, value = "The request message must contain MessageID.It cannot be null and empty")
	public String getMessageID() {
	return messageID;
	}
	
	public void setMessageID(String messageID) {
	this.messageID = messageID;
	}

	public String getId() {
	return id;
	}

	public void setId(String id) {
	this.id = id;
	}

	public String geteMoneyId() {
		return eMoneyId;
	}

	public void seteMoneyId(String eMoneyId) {
		this.eMoneyId = eMoneyId;
	}
	
	public String getAddress1() {
	return address1;
	}

	public void setAddress1(String address1) {
	this.address1 = address1;
	}

	public String getAddress2() {
	return address2;
	}

	public void setAddress2(String address2) {
	this.address2 = address2;
	}

	public String getCity() {
	return city;
	}

	public void setCity(String city) {
	this.city = city;
	}

	public String getPostalCode() {
	return postalCode;
	}

	public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
	}

	public String getState() {
	return state;
	}

	public void setState(String state) {
	this.state = state;
	}

	public String getBasePlanId() {
	return basePlanId;
	}

	public void setBasePlanId(String basePlanId) {
	this.basePlanId = basePlanId;
	}

	public String getHomePhone() {
	return homePhone;
	}

	public void setHomePhone(String homePhone) {
	this.homePhone = homePhone;
	}

	public String getFax() {
	return fax;
	}

	public void setFax(String fax) {
	this.fax = fax;
	}

	public String getMaritalStatus() {
	return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
	this.maritalStatus = maritalStatus;
	}

	@Valid
	@ApiModelProperty(required = true, value = "The request message must contain Client. It cannot be null and empty")
	public Client getClient() {
	return client;
	}

	public void setClient(Client client) {
	this.client = client;
	}

	@Valid
	@ApiModelProperty(required = true, value = "The request message must contain Client. It cannot be null and empty")
	public Client getSpouse() {
	return spouse;
	}

	public void setSpouse(Client spouse) {
	this.spouse = spouse;
	}

	@Override
	public String toString() {
	return "ClientData [metadata=" + metadata + ", messageID=" + messageID + ", id=" + id + ", address1=" + address1
	+ ", address2=" + address2 + ", city=" + city + ", postalCode=" + postalCode + ", state=" + state
	+ ", basePlanId=" + basePlanId + ", homePhone=" + homePhone + ", fax=" + fax + ", maritalStatus="
	+ maritalStatus + ", client=" + client + ", spouse=" + spouse + "]";
	}
	
	

}
