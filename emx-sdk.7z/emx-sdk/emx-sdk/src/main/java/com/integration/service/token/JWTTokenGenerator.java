package com.integration.service.token;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.MessageFormat;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.integration.service.LoggerUtil;
@Component
public class JWTTokenGenerator {

	Log logger = LoggerUtil.getLog(this);

	private static String[] removeString = { 
			"\\\n", 
			"\r", 
			"-----BEGIN PRIVATE KEY-----", 
			"-----END PRIVATE KEY-----",
			"-----BEGIN RSA PRIVATE KEY-----", 
			"-----END RSA PRIVATE KEY-----" };

	private static String CHAR_SET = "UTF-8";
	private static String ALGORITHM = "SHA256withRSA";

	/**
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public String getSFJwtToken(JWTTokenParams params) throws Exception {
		logger.info("Token Params [" + params + "]");
		return salesforceJwtGenerator(params);
	}

	
	public String getEMXJwtToken() {

		return "";

	}

	/**
	 *
	 * @param params
	 * @return
	 * @throws Exception
	 */
	protected String salesforceJwtGenerator(JWTTokenParams params) throws Exception {
		logger.info("Begin JWTUtils.salesforceJwtGenerator");
		String header = "{\"alg\":\"" + params.getAlg() + "\"}";
		String claimTemplate = "'{'\"iss\": \"{0}\", \"sub\": \"{1}\", \"aud\": \"{2}\", \"exp\": {3} '}'";
		params.setExpiredTimeInMinutes ( (params.getExpiredTimeInMinutes() < 5) ? 5 : params.getExpiredTimeInMinutes());

		try {
			StringBuffer token = new StringBuffer();

			// Encode the JWT Header and add it to our string to sign
			token.append(Base64.encodeBase64URLSafeString(header.getBytes(CHAR_SET)));

			// Separate with a period
			token.append(".");

			// Create the JWT Claims Object
			String[] claimArray = new String[4];
			claimArray[0] = params.getIss();
			claimArray[1] = params.getSub();
			claimArray[2] = params.getAud();
			claimArray[3] = Long.toString((System.currentTimeMillis() / 1000) + (60 * params.getExpiredTimeInMinutes())); // in
																												// seconds
			MessageFormat claims;
			claims = new MessageFormat(claimTemplate);
			String payload = claims.format(claimArray);

			// Add the encoded claims object
			token.append(Base64.encodeBase64URLSafeString(payload.getBytes(CHAR_SET)));

			// Load the private key
			PrivateKey privateKey = getPrivateKey(params.getPrivateKeyString());
			// Sign the JWT Header + "." + JWT Claims Object
			Signature signature = Signature.getInstance(ALGORITHM);
			signature.initSign(privateKey);
			signature.update(token.toString().getBytes(CHAR_SET));
			String signedPayload = Base64.encodeBase64URLSafeString(signature.sign());

			// Separate with a period
			token.append(".");
			// Add the encoded signature
			token.append(signedPayload);

			logger.info("JWT Token "+ token);
			return token.toString();

		} catch (Exception e) {
			logger.error("Exception in JWTUtils.salesforceJwtGenerator ", e);
			throw e;
		} finally {
			logger.info("End JWTUtils.salesforceJwtGenerator");

		}
	}

	/**
	 *
	 * @param params
	 * @return
	 * @throws Exception
	 */
	protected String emoneyJwtGenerator(JWTTokenParams params) throws Exception {
		logger.info("Begin JWTUtils.salesforceJwtGenerator");
		String header = "{\"alg\":\"" + params.getAlg() + "\"}";
		String claimTemplate = "'{'\"iss\": \"{0}\", \"sub\": \"{1}\", \"aud\": \"{2}\", \"exp\": {3} '}'";
		params.setExpiredTimeInMinutes ( (params.getExpiredTimeInMinutes() < 5) ? 5 : params.getExpiredTimeInMinutes());

		try {
			StringBuffer token = new StringBuffer();

			// Encode the JWT Header and add it to our string to sign
			token.append(Base64.encodeBase64URLSafeString(header.getBytes(CHAR_SET)));

			// Separate with a period
			token.append(".");

			// Create the JWT Claims Object
			String[] claimArray = new String[4];
			claimArray[0] = params.getIss();
			claimArray[1] = params.getSub();
			claimArray[2] = params.getAud();
			claimArray[3] = Long.toString((System.currentTimeMillis() / 1000) + (60 * params.getExpiredTimeInMinutes())); // in
																												// seconds
			MessageFormat claims;
			claims = new MessageFormat(claimTemplate);
			String payload = claims.format(claimArray);

			// Add the encoded claims object
			token.append(Base64.encodeBase64URLSafeString(payload.getBytes(CHAR_SET)));

			// Load the private key
			PrivateKey privateKey = getPrivateKey(params.getPrivateKeyString());
			// Sign the JWT Header + "." + JWT Claims Object
			Signature signature = Signature.getInstance(ALGORITHM);
			signature.initSign(privateKey);
			signature.update(token.toString().getBytes(CHAR_SET));
			String signedPayload = Base64.encodeBase64URLSafeString(signature.sign());

			// Separate with a period
			token.append(".");
			// Add the encoded signature
			token.append(signedPayload);

			return token.toString();

		} catch (Exception e) {

			logger.error("Exception in JWTUtils.salesforceJwtGenerator ", e);
			throw e;
		} finally {
			logger.info("End JWTUtils.salesforceJwtGenerator");

		}
	}

	/**
	 * 
	 * @param privateKeyContent
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 */
	protected PrivateKey getPrivateKey(String privateKeyContent)
			throws NoSuchAlgorithmException, InvalidKeySpecException {

		if (StringUtils.isEmpty(privateKeyContent)) {
			throw new InvalidKeySpecException("Private key cannot be blank");
		}
		for (int i = 0; i < removeString.length; i++) {
			String string = removeString[i];
			privateKeyContent = privateKeyContent.replaceAll(string, "");
		}

		KeyFactory kf = KeyFactory.getInstance("RSA");

		PKCS8EncodedKeySpec keySpecPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKeyContent));

		PrivateKey privKey = kf.generatePrivate(keySpecPKCS8);

		return privKey;
	}

	/**
	 * 
	 * @return
	 */
	public String getSfToken() throws Exception 
	{
		try {
			DataInputStream in = new DataInputStream(
					new FileInputStream("C:\\Projects\\Emoney\\cert\\OAuth Certificate\\eMoneyDev\\eMoneyDev.key"));

			byte[] myBuffer = new byte[in.available()];
			in.read(myBuffer);
			in.close();
			JWTTokenParams tokenParam = new JWTTokenParams();
			tokenParam.setAlg("RS256");
			tokenParam.setIss("3MVG9CEn_O3jvv0x1tpYjteOyPXRIHDgaOXhfiIubHhs3gP4xd0O.OFLrjmnOIQeyQL8W7_n9Oog2kmn6X3Nc");
			tokenParam.setSub("integration.user@emoney.com.devpkg");
			tokenParam.setAud("https://login.salesforce.com");
			tokenParam.setExpiredTimeInMinutes(10);
			tokenParam.setPrivateKeyString(new String(myBuffer));

			JWTTokenGenerator util = new JWTTokenGenerator();
			String jwtToken = util.getSFJwtToken(tokenParam);
			System.out.println(jwtToken);
			
			return jwtToken;

		} catch (Exception e) {
			throw e;
		}
		
	}
	/**
	 * 
	 * @return
	 */
	public String getEmoneyToken() throws Exception 
	{
		try {
			DataInputStream in = new DataInputStream(
					new FileInputStream("C:\\Projects\\Emoney\\cert\\OAuth Certificate\\eMoneyDev\\eMoneyDev.key"));

			byte[] myBuffer = new byte[in.available()];
			in.read(myBuffer);
			in.close();
			JWTTokenParams tokenParam = new JWTTokenParams();
			tokenParam.setAlg("RS256");
			tokenParam.setIss("liquidhubclient");
			tokenParam.setSub("liquidhubclient");
			//tokenParam.setSub("integration.user@emoney.com.devpkg");			
			tokenParam.setAud("https://signin-api-beta.emoneyadvisor.com/connect/token");
			
			tokenParam.setExpiredTimeInMinutes(525600);
			tokenParam.setPrivateKeyString(new String(myBuffer));

			JWTTokenGenerator util = new JWTTokenGenerator();
			String jwtToken = util.getSFJwtToken(tokenParam);
			System.out.println(jwtToken);
			
			return jwtToken;

		} catch (Exception e) {
			throw e;
		}
		
	}

}
