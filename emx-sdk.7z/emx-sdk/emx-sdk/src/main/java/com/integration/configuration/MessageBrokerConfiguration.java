package com.integration.configuration;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MessageBrokerConfiguration {

     public final String topicExchangeName = "analyticsEventExchange";

    public final String queueName = "analyticsEventQueue";

    @Bean
    public Jackson2JsonMessageConverter producerJackson2MessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    Queue analyticsQueue() {
        return new Queue(queueName, true);
    }

    @Bean
    TopicExchange analyticsExchange() {
        return new TopicExchange(topicExchangeName);
    }

    @Bean
    Binding analyticsBinding(Queue analyticsQueue, TopicExchange analyticsExchange) {
        return BindingBuilder.bind(analyticsQueue).to(analyticsExchange).with("com.integration.analytics.#");
    }
}
