package com.integration.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.emx.EmxAlert;
import com.integration.bean.emx.EmxAlertsAnalyticsEvent;
import com.integration.dao.SfEmxHeaderMapRepository;
import com.integration.dao.SfEmxMappingRepository;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataValidationException;
import com.integration.model.SfEmxHeaderMap;
import com.integration.model.SfEmxMapping;

@Component
public class EmxToSfCommonUtil {
	
	Log logger = LoggerUtil.getLog(this);
	
	//@Value("${emx.sf.alert.client.node}")
    String clientNodeValue;
	
	@Value("${emx.sf.alert.client.id}")
    String clientIdValue;
	
	
	SforgEmxoffMapRepository sforgEmxoffMapRepository;
	SfEmxHeaderMapRepository sF2EMXHeaderMappingRepository;
	SfEmxMappingRepository sfEmxMappingRepository;
	JsonUtility jsonUtility;
    
	
	@Autowired
	public EmxToSfCommonUtil(SforgEmxoffMapRepository sforgEmxoffMapRepository,
			SfEmxHeaderMapRepository sF2EMXHeaderMappingRepository, SfEmxMappingRepository sfEmxMappingRepository,
			JsonUtility jsonUtility) {
		this.sforgEmxoffMapRepository = sforgEmxoffMapRepository;
		this.sF2EMXHeaderMappingRepository = sF2EMXHeaderMappingRepository;
		this.sfEmxMappingRepository = sfEmxMappingRepository;
		this.jsonUtility = jsonUtility;
	}

	/**
	 * 
	 * @param emxAlertJsonMessage
	 * @param emoneyAlertsAnalyticsEvent
	 * @return
	 * @throws Exception
	 */
	public String transformAlertMessage(String emxAlertJsonMessage, 
			EmxAlertsAnalyticsEvent emoneyAlertsAnalyticsEvent)
			 throws Exception{
		/*		
		Tables for alert
			sf_org_emx_Off_map get org_id from office_id.
			sf_emx_header_map get id based on the org_id
			sf_emx_mapping with the help of header_id(id of sf_emx-header_map)
			get sf_name and sf_type from emx_name and emx_type 
		*/
		String sfAlertJsonMessage = null;
		String emxOfficeId = emoneyAlertsAnalyticsEvent.getAlerts().get(0).getEMoneyAlertsMetadata().getOffice();		
		SfEmxHeaderMap sf2emxHeaderMapperObj =null;
		List<SfEmxMapping>  listSfEmxMapping = null;
		//SfOrgEmxOffMap sfOrgEmxOffMapObj = sforgEmxoffMapRepository.findSfOrgEmxOffMapByemxOfficeId(emxOfficeId);	
		//TODO alert need confirmation some times it is small and some times it is caps.
		String orgID = sforgEmxoffMapRepository.findOrgId(emxOfficeId);
		if(orgID!=null){
			sf2emxHeaderMapperObj = sF2EMXHeaderMappingRepository.findSfEntityObject(orgID, "alert");
			if(sf2emxHeaderMapperObj!=null){
				listSfEmxMapping =  sfEmxMappingRepository.findAllByHeaderMapId(sf2emxHeaderMapperObj.getId());
				if(listSfEmxMapping.size()>0){
					sfAlertJsonMessage = replaceAlert(emoneyAlertsAnalyticsEvent, orgID, listSfEmxMapping);	
				}else{
					logger.error("***** Data Not Found in the sfEmxMappingRepository.findAllByHeaderMapId table : "
							+ "OrgID:"+orgID+", sf2emxHeaderMapper id:"+sf2emxHeaderMapperObj.getId()
							+", Tracking ID: "+emoneyAlertsAnalyticsEvent.getTrackingID());			
				}	
			}else{
				logger.error("***** Data Not Found in the sF2EMXHeaderMappingRepository.findSfEntityObject : OrgID:"+orgID
						+", Tracking ID: "+emoneyAlertsAnalyticsEvent.getTrackingID());			
			}	
		}else{
			logger.error("***** Data Not Found in the sforgEmxoffMapRepository.findOrgId : emxOfficeId:"+emxOfficeId
					+", Tracking ID: "+emoneyAlertsAnalyticsEvent.getTrackingID());				
		}			
    	
		return sfAlertJsonMessage;
	}
	
	/**
	 * 
	 * @param emoneyAlertsAnalyticsEvent
	 * @param orgID
	 * @param listSfEmxMapping
	 * @return
	 * @throws Exception
	 */
	String replaceAlert(EmxAlertsAnalyticsEvent emoneyAlertsAnalyticsEvent, String orgID,
			List<SfEmxMapping> listSfEmxMapping) throws Exception {
		Map<String,String> emxsfNameMap = null;
		Map<String,String> emxsfTypeMap = null;
		Map<String,String> sfTypeSfNameMap = null;
		JsonNode emoneyRootNode = null;
		ObjectMapper mapper = null;
		String JsonStringEmoneyAlert = null;
		EmxAlert emoneyAlert = null;
		ObjectMapper sfRootmapper = null;
		sfRootmapper = new ObjectMapper();
		ObjectNode sfRootNode = null;
		
		sfRootNode = sfRootmapper.createObjectNode();			
		sfRootmapper = new ObjectMapper();
		sfRootNode = sfRootmapper.createObjectNode();		
		emxsfNameMap = new HashMap<String,String>();
		emxsfTypeMap = new HashMap<String,String>();
		sfTypeSfNameMap = new HashMap<String,String>();
		for(SfEmxMapping sfEmxMapping:listSfEmxMapping){
			emxsfNameMap.put(sfEmxMapping.getEmxName().trim(), sfEmxMapping.getSfName().trim());
			emxsfTypeMap.put(sfEmxMapping.getEmxType().trim(), sfEmxMapping.getSfType().trim());
			sfTypeSfNameMap.put(sfEmxMapping.getSfType().trim(), sfEmxMapping.getSfName().trim());
		}	
		emoneyAlert = emoneyAlertsAnalyticsEvent.getAlerts().get(0).getAlert().get(0);
		JsonStringEmoneyAlert = jsonUtility.getJsonStringFromObject(emoneyAlert);
		mapper = new ObjectMapper();		
		emoneyRootNode = mapper.readTree(JsonStringEmoneyAlert);		
		Iterator<Map.Entry<String, JsonNode>> fields = emoneyRootNode.fields();
		boolean isSucess=true;
		 while (fields.hasNext()) {
		    Map.Entry<String, JsonNode> entry = fields.next();
		    logger.info(entry.getKey() + ":" + entry.getValue());
		   
		   /* 
		    emxsfNameMap:
		    {
		    	timeStamp=Timestamp__c, 
		    	clientId=Emoney_Client_Id__c, 
		    	displayName=Name, 
		    	subject=Subject__c, 
		    	dismissed=Dismissed__c, 
		    	eMoneyId=eMoney_Id__c, 
		    	description=Description__c, 
		    	messageId=Id, 
		    	clientIdReference=Emoney_Client__c
		    }*/
		    
		    switch(entry.getKey()){
		    	case "clientId":
		    		clientNodeValue = sfTypeSfNameMap.get("reference");
		    		String alertIdValue= emxsfNameMap.get("clientId");
		    		if(alertIdValue!=null){
		    			ObjectNode idnode = sfRootNode.putObject(clientNodeValue);
			    		idnode.set(clientIdValue, mapper.convertValue(entry.getValue(), JsonNode.class));	
		    		}else{
		    			logger.error("***ERROR::clientId not found in DB Table sfEmxMapping table");
		    			isSucess=false;
		    		}		    		
		    		break;
		    	case "eMoneyId":
		    		/*String eMoneyId = emxsfNameMap.get("eMoneyId");
		    		if(eMoneyId!=null){
		    			sfRootNode.set(emxsfNameMap.get("eMoneyId"), mapper.convertValue(entry.getValue(), JsonNode.class));	
		    		}else{
		    			logger.error("***ERROR::eMoneyId not found in DB Table sfEmxMapping table");
		    			isSucess=false;
		    		}*/
		    		//sfRootNode.set(emxsfNameMap.get("alertId"), mapper.convertValue(entry.getValue(), JsonNode.class));
		    		break;
		    	case "timeStamp":
		    		String timeStampValue = emxsfNameMap.get("timeStamp");
		    		if(timeStampValue!=null){
		    			sfRootNode.set(emxsfNameMap.get("timeStamp"), mapper.convertValue(entry.getValue(), JsonNode.class));	
		    		}else{
		    			logger.debug("***INFO::timeStamp not found in DB Table sfEmxMapping table");		    			
		    		}		    		
		    		break;
		    	case "subject":
		    		String subjectValue = emxsfNameMap.get("subject");
		    		if(subjectValue!=null){
		    			sfRootNode.set(emxsfNameMap.get("subject"), mapper.convertValue(entry.getValue(), JsonNode.class));	
		    		}else{
		    			logger.debug("***INFO::subject not found in DB Table sfEmxMapping table");		    			
		    		}			    		
		    		break;
		    	case "description":
		    		String descriptionValue = emxsfNameMap.get("description");
		    		if(descriptionValue!=null){
		    			sfRootNode.set(emxsfNameMap.get("description"), mapper.convertValue(entry.getValue(), JsonNode.class));
		    		}else{
		    			logger.error("***ERROR::description not found in DB Table sfEmxMapping table");
		    			isSucess=false;
		    		}		    		
		    		break;
		    	case "displayName":
		    		String displayNameValue = emxsfNameMap.get("displayName");
		    		if(displayNameValue!=null){
		    			sfRootNode.set(emxsfNameMap.get("displayName"), mapper.convertValue(entry.getValue(), JsonNode.class));
		    		}else{
		    			logger.debug("***INFO::displayName not found in DB Table sfEmxMapping table");		    			
		    		}		    		
		    		break;
		    	case "dismissed":
		    		String dismissedValue = emxsfNameMap.get("dismissed");
		    		if(dismissedValue!=null){
		    			sfRootNode.set(emxsfNameMap.get("dismissed"), mapper.convertValue(entry.getValue(), JsonNode.class));
		    		}else{
		    			logger.error("***ERROR::displayName not found in DB Table sfEmxMapping table");
		    			isSucess=false;
		    		}		    		
		    		break;
		    }		    
		 }
		 String msg = null;
		 if(sfRootNode!=null){
			 if(isSucess==true){
				 msg = sfRootNode.toString();	
			 }			
		 }			
		 return msg;
	}

	/**
	 * this array contain Object["EmxOfficeId","Slit message by Client"]
	 * @param message
	 * @return this array contain Object["EmxOfficeId","Slit message by Client"]
	 * @throws Exception
	 */
	public List<Object[]> transformEmxClientMessage(String message) throws Exception {
		logger.info("Start CommonUtils.transformEmxClientMessage");
		// this array contain Object["EmxOfficeId","Slit message by Client"]
		List<Object[]> data = new ArrayList<Object[]>();
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode nodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				String address = node.get("address1").textValue() + "\n" + node.get("address2").textValue();

				((ObjectNode) node).put("address1", address);

				((ObjectNode) node).put("address1", address);
				((ObjectNode) node).remove("address2");
				listNode.add(node);

			}
			// Remove All node here
			ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				String officeName = jsonNode2.get("metadata").get("office").asText();
				// ((ObjectNode) jsonNode2).remove("metadata");
				arrayNode.add(jsonNode2);
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(rootNode).replace("address1", "address1"));
				data.add(new Object[] { officeName, buffer });

			}

		} catch (Exception e) {

			logger.error("Exception in transformEmxClientMessage", e);
			throw e;
		} finally {
			logger.info("End CommonUtils.transformEmxClientMessage");

		}
		return data;
	}

	
	public String getMessageIdEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getMessageIdEmxClient");
		String msgid = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			JsonNode noteNodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode noteNode : noteNodes) {
				listNode.add(noteNode);
			}

			for (JsonNode jsonNode2 : listNode) {
				msgid = jsonNode2.get("messageID").asText();
			}
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return msgid;
	}
	/**
	 * 
	 * @param message
	 * @return
	 * @throws DataValidationException
	 */
	public String getTrackingIdEmxTask(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getTrackingIdEmxTask");
		String trackingId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			trackingId =  rootNode.get("trackingID").textValue();
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return trackingId;
	}
	
	
	public String getMessageIDEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getMessageIDEmxClient");
		String messageID = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				messageID  = jsonNode2.get("messageID").asText();				
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return messageID;
	}
	public String getEMoneyIDEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getemoneyIdEmxClient");
		String emoneyId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				emoneyId  = jsonNode2.get("eMoneyId").asText();				
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return emoneyId;
	}
	
	public String getNoteEmoneyNoteIDEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getemoneyNoteIdEmxClient");
		String emoneyNoteId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {
				if (jsonNode2.get("note").get("eMoneyNoteId") != null) {
					emoneyNoteId  = jsonNode2.get("note").get("eMoneyNoteId").asText();
					
				}
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return emoneyNoteId;
	}
	
	public String getNoteEmoneyIDEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getemoneyNoteIdEmxClient");
		String emoneyId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {
				if (jsonNode2.get("note").get("eMoneyId").asText() != null) {
					emoneyId  = jsonNode2.get("note").get("eMoneyId").asText();
					
				}
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return emoneyId;
	}
	
	
	 
	//String assignedTo
	public String getEmoneyTaskMessageIdEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.geteMoneyTaskIdEmxClient");
		String messageId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				messageId = StringUtils.isEmpty(jsonNode2.get("task").get("messageId"))?"": jsonNode2.get("task").get("messageId").asText();						
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}	

		return messageId;
	}
	
	public String getEmoneyTaskeMoneyTaskIdEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.geteMoneyTaskIdEmxClient");
		String eMoneyTaskId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {
				eMoneyTaskId = jsonNode2.get("task").get("eMoneyTaskId").asText();							
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return eMoneyTaskId;
	}
	
	public String getEmoneyTaskassignedToEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getEmoneyTaskassignedToEmxClient");
		String assignedTo = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				assignedTo  = jsonNode2.get("task").get("assignedTo").asText();				
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return assignedTo;
	}
	
	public String getEmoneyTaskmessageIdEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getEmoneyTaskmessageIdEmxClient");
		String messageId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				messageId  =jsonNode2.get("task").get("message").asText();				
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return messageId;
	}
	
	public String getEmoneyTaskeMoneyIdEmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getEmoneyTaskeMoneyIdEmxClient");
		String eMoneyId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				eMoneyId  = jsonNode2.get("task").get("eMoneyId").asText();				
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return eMoneyId;
	}
	
	public String getEmoneyTasktaskIdmxClient(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getEmoneyTasktaskIdEmxClient");
		String taskId = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {				
				taskId  = jsonNode2.get("task").get("taskId").asText();				
			}		
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return taskId;
	}
	
	
	/**
	 * 
	 * @param message
	 * @return
	 * @throws DataValidationException
	 */
	public String getIdForAlert(String message) throws DataValidationException {
		logger.info("Start CommonUtils.getIdForAlert");
		String trackingId = "";
		
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			trackingId =  rootNode.get("Id").textValue();
		} catch (JsonProcessingException e) {
			throw new DataValidationException("JsonProcessingException " + e.getMessage());
		} catch (IOException e) {
			throw new DataValidationException("IOException " + e.getMessage());
		}

		return trackingId;
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 * @throws DataValidationException
	 */
	public String getTrackingIdEmxClient(String message) throws DataValidationException {
		return getTrackingIdEmxTask( message);
	}
	
	/**
	 * @param message
	 * @return this array contain Object["clientId","Slit message by task"]
	 * @throws Exception
	 */
	public List<Object[]> splitEmxTaskMessage(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.splitEmxTaskMessage");
		List<Object[]> data = new ArrayList<Object[]>();
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			// Remove All node here
			//ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
				String clientId = jsonNode2.get("task").get("eMoneyId").asText();
				String eMoneyTaskId = jsonNode2.get("task").get("eMoneyTaskId").asText();
				String subjectTxt = jsonNode2.get("task").get("subject").asText();
				String messageTXT = jsonNode2.get("task").get("message").asText();
				String assignedTo = jsonNode2.get("task").get("assignedTo").asText();
				String taskId = null;
				// ((ObjectNode) jsonNode2).remove("metadata");
				arrayNode.add(jsonNode2);
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(rootNode));
				data.add(new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer });

			}
		} catch (Exception e) {
			logger.error("Exception in splitEmxTaskMessage", e);
			throw new DataProcessingException("Exception  in splitEmxTaskMessage");
		} finally {
			logger.info("End CommonUtils.splitEmxTaskMessage");
		}
		return data;
	}

	/**
	 * this array contain Object[messageId,emoneyId,,"Slit message by Client"]
	 * @param message
	 * @return this array contain Object[messageId,emoneyId,"Slit message by Client"]
	 * @throws Exception
	 */
	public List<Object[]> splitEmxClientMessage(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.splitEmxClientMessage");
		List<Object[]> data = new ArrayList<Object[]>();
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode nodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			// Remove All node here
			//ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
				String messageId = StringUtils.isEmpty( jsonNode2.get("messageID"))?"": jsonNode2.get("messageID").asText();
				String emoneyId = StringUtils.isEmpty( jsonNode2.get("eMoneyId"))?"": jsonNode2.get("eMoneyId").asText();
				// ((ObjectNode) jsonNode2).remove("metadata");
				arrayNode.add(jsonNode2);
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(rootNode));
				data.add(new Object[] {messageId,emoneyId, buffer });

			}

		} catch (Exception e) {

			logger.error("Exception in splitEmxClientMessage", e);
			throw new DataProcessingException("Exception  in splitEmxClientMessage");
		} finally {
			logger.info("End CommonUtils.splitEmxClientMessage");

		}
		return data;
	}
	
	/**
	 * this array contain Object[clientId,noteId,,"Split message by Note"]
	 * @param message
	 * @return this array contain Object[clientId,noteId,"Split message by Note"]
	 * @throws Exception
	 */
	public List<Object[]> splitEmxNoteMessage(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.splitEmxClientMessage");
		List<Object[]> data = new ArrayList<Object[]>();
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode noteNodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode noteNode : noteNodes) {
				listNode.add(noteNode);
			}
			// Remove All node here
			//ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
			for (JsonNode jsonNode2 : listNode) {
				// get clientId,noteId,eMoneyId
				ArrayNode arrayNoteNode = ((ArrayNode) noteNodes).removeAll();
				String clientId = StringUtils.isEmpty(jsonNode2.get("note").get("eMoneyId").asText())?"": jsonNode2.get("note").get("eMoneyId").asText();
				String noteId = StringUtils.isEmpty(jsonNode2.get("note").get("eMoneyNoteId").asText())?"": jsonNode2.get("note").get("eMoneyNoteId").asText();
				//String noteSFId = StringUtils.isEmpty(jsonNode2.get("note").get("eMoneyNoteId"))?"": jsonNode2.get("note").get("eMoneyNoteId").asText();
				// ((ObjectNode) jsonNode2).remove("metadata");
				arrayNoteNode.add(jsonNode2);
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(rootNode));
				data.add(new Object[] {clientId,noteId, buffer });

			}

		} catch (Exception e) {

			logger.error("Exception in splitEmxClientMessage", e);
			throw new DataProcessingException("Exception  in splitEmxNoteMessage");
		} finally {
			logger.info("End CommonUtils.splitEmxNoteMessage");

		}
		return data;
	}
	
	/**
	 * this array contain Object[clientId,noteId,,"Split message by Note"]
	 * @param message
	 * @return this array contain Object[clientId,noteId,"Split message by Note"]
	 * @throws Exception
	 */
	public List<Object[]> splitNoteMessage(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.splitEmxClientMessage");
		List<Object[]> data = new ArrayList<Object[]>();
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode noteNodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode noteNode : noteNodes) {
				listNode.add(noteNode);
			}
			// Remove All node here
			//ArrayNode arrayNode = ((ArrayNode) nodes).removeAll();
			for (JsonNode jsonNode2 : listNode) {
				// get clientId,noteId,eMoneyId
				ArrayNode arrayNoteNode = ((ArrayNode) noteNodes).removeAll();
				String clientId = StringUtils.isEmpty(jsonNode2.get("note").get("clientId"))?"": jsonNode2.get("note").get("clientId").asText();
				String noteId = StringUtils.isEmpty(jsonNode2.get("note").get("noteId"))?"": jsonNode2.get("note").get("noteId").asText();
				// ((ObjectNode) jsonNode2).remove("metadata");
				arrayNoteNode.add(jsonNode2);
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(rootNode));
				data.add(new Object[] {clientId,noteId, buffer });

			}

		} catch (Exception e) {

			logger.error("Exception in splitEmxClientMessage", e);
			throw new DataProcessingException("Exception  in splitEmxNoteMessage");
		} finally {
			logger.info("End CommonUtils.splitEmxNoteMessage");

		}
		return data;
	}
		
	/**
	 * @param message
	 * @return this array contain String[trackingID, office,clientId]
	 * @throws Exception
	 */
	public String[] getEmxTaskInfoFromMessageQueue(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.getEmxTaskInfoFromMessageQueue");
		// trackingID, office,clientId
		String[] data = new String[5];
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			data[0] = rootNode.get("trackingID").textValue();
			
			JsonNode nodes = rootNode.withArray("tasks");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				data[1]  = jsonNode2.get("metadata").get("office").asText();
				data[2]  = jsonNode2.get("task").get("eMoneyId").asText();
			}

		} catch (Exception e) {

			logger.error("Exception in getEmxTaskInfoFromMessageQueue", e);
			throw new DataProcessingException("Exception  in getEmxTaskInfoFromMessageQueue" );
		} finally {
			logger.info("End CommonUtils.getEmxTaskInfoFromMessageQueue");

		}
		return data;
	}


	/**
	 * @param message
	 * @return this array contain String[trackingID, office,"messageID","id","eMoneyId"]
	 * @throws Exception
	 */
	public String[] getEmxClientInfoFromMessageQueue(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.getEmxClientInfoFromMessageQueue");
		// trackingID, office,clientId
		String[] data = new String[5];
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			data[0] = rootNode.get("trackingID").textValue();
			
			JsonNode nodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				data[1]  = jsonNode2.get("metadata").get("office").asText();
				data[2]  = StringUtils.isEmpty( jsonNode2.get("messageID"))?"": jsonNode2.get("messageID").asText();
				data[3]  = StringUtils.isEmpty( jsonNode2.get("id"))?"": jsonNode2.get("id").asText(); //jsonNode2.get("id").asText();
				data[4]  = jsonNode2.get("eMoneyId").asText();
			}

		} catch (Exception e) {

			logger.error("Exception in getEmxClientInfoFromMessageQueue", e);
			throw new DataProcessingException("Exception  in getEmxClientInfoFromMessageQueue");
		} finally {
			logger.info("End CommonUtils.getEmxClientInfoFromMessageQueue");

		}
		return data;
	}
	
	
	/**
	 * @param message
	 * @return this array contain String[trackingID, office,"clientId","noteId"]
	 * @throws Exception
	 */
	public String[] getEmxNoteInfoFromMessageQueue(String message) throws DataProcessingException {
		logger.info("Start CommonUtils.getEmxNoteInfoFromMessageQueue");
		// trackingID, office,clientId
		String[] data = new String[4];// data mapping like this {data[0] = trackingID,data[1] = office,data[2] = clientId,data[3] = noteId }
		try {

			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);
			
			data[0] = rootNode.get("trackingID").textValue();
			
			JsonNode noteNodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();

			for (JsonNode noteNode : noteNodes) {
				listNode.add(noteNode);
			}
			for (JsonNode jsonNode2 : listNode) {
				// get officeName
				data[1]  = jsonNode2.get("metadata").get("office").asText();
				data[2]  = StringUtils.isEmpty(jsonNode2.get("note").get("clientId"))?"": jsonNode2.get("note").get("clientId").asText();
				data[3]  = StringUtils.isEmpty(jsonNode2.get("note").get("noteId"))?"": jsonNode2.get("note").get("noteId").asText(); 
			}

		} catch (Exception e) {

			logger.error("Exception in getEmxNoteInfoFromMessageQueue", e);
			throw new DataProcessingException("Exception  in getEmxNoteInfoFromMessageQueue");
		} finally {
			logger.info("End CommonUtils.getEmxNoteInfoFromMessageQueue");

		}
		return data;
	}

	

	/**
	 * 
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> transformClientUpdateMessage(String message) throws Exception {
		logger.info("Start ProcessEmxMessageImpl.transformClientUpdateMessage");
		// this array contain Object["EmxOfficeId","Slit message by Client"]
		List<Object[]> data = new ArrayList<Object[]>();
		try {
			
			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode nodes = rootNode.withArray("clients");
			List<JsonNode> listNode = new ArrayList<JsonNode>();
			
			for (JsonNode node : nodes) {
				String address = "";
				String jobAddress = "";
				
				//INTP 972 Fix - to handle the scenario of address1=null and address2 != null
				//if (  !isNodeEmpty("address1",node)) 
				//{
					address = getNodeValue ("address1", node);
					if(!isNodeEmpty("address2",node)){
						address += "\n" + getNodeValue ("address2",node);// (!node.get("address2").isNull()? "\n" + node.get("address2").textValue():"");
					}					
				//}
				((ObjectNode) node).put("address1", address);
				((ObjectNode) node).remove("address2");
				listNode.add(node);
				
						

				//INTP 958 Fix
				// append job.address2 to job.address1 of client
				if (!isNodeEmpty("client", node)) {
					JsonNode clientNode = node.get("client");
						jobAddress = getNodeValue("job.address1", clientNode);						
						if (!isNodeEmpty("job.address2", clientNode)) {
							jobAddress += "\n" + getNodeValue("job.address2", clientNode);
						}
					if (clientNode instanceof ObjectNode) {
						((ObjectNode) clientNode).put("job.address1", jobAddress);
						((ObjectNode) clientNode).remove("job.address2");
					}
					listNode.add(node);
				}
				
				// append job.address2 to job.address1 of spouse
				if (!isNodeEmpty("spouse", node)) {
					JsonNode clientNode = node.get("spouse");
						jobAddress = getNodeValue("job.address1", clientNode);
						if (!isNodeEmpty("job.address2", clientNode)) {
							jobAddress += "\n" + getNodeValue("job.address2", clientNode);
						}
					if (clientNode instanceof ObjectNode) {
						((ObjectNode) clientNode).put("job.address1", jobAddress);
						((ObjectNode) clientNode).remove("job.address2");
					}
					listNode.add(node);
				}
				
				// Remove All node here
				for (JsonNode jsonNode2 : listNode) {
					ArrayNode arrayNode = ((ArrayNode)nodes).removeAll();	
					// get officeName 
					String officeName = jsonNode2.get("metadata").get ("office").asText();
					//((ObjectNode) jsonNode2).remove("metadata");
					arrayNode.add(jsonNode2);
					StringBuffer buffer = new StringBuffer();
					buffer.append(objectMapper.writeValueAsString(rootNode).replace("address1", "address1"));
					data.add(new Object[] {officeName, buffer});
				}
				
				
			}
				
		} catch (Exception e) {
			
			logger.error("Exception in transformClientUpdateMessage",e);
			throw e;
		}
		finally
		{
			logger.info("End ProcessEmxMessageImpl.transformClientUpdateMessage");

		}
		return data;
	}
	
	
	
	/**
	 * 
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> transformNoteUpdateMessage(String message) throws Exception {
		logger.info("Start ProcessEmxMessageImpl.transformClientUpdateMessage");
		// this array contain Object["EmxOfficeId","Slit message by Client"]
		List<Object[]> data = new ArrayList<Object[]>();
		try {
			
			// combine address changes.
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(message);

			JsonNode nodes = rootNode.withArray("notes");
			List<JsonNode> listNode = new ArrayList<JsonNode>();
			
			for (JsonNode node : nodes) {
				listNode.add(node);
			}
			// Remove All node here
			for (JsonNode jsonNode2 : listNode) {
				ArrayNode arrayNode = ((ArrayNode)nodes).removeAll();	
				// get officeName 
				String officeName = jsonNode2.get("metadata").get ("office").asText();
				((ObjectNode) jsonNode2).remove("metadata");
				arrayNode.add(jsonNode2);
				StringBuffer buffer = new StringBuffer();
				buffer.append(objectMapper.writeValueAsString(rootNode));
				data.add(new Object[] {officeName, buffer});
				
			}
			

		} catch (Exception e) {
			
			logger.error("Exception in transformClientUpdateMessage",e);
			throw e;
		}
		finally
		{
			logger.info("End ProcessEmxMessageImpl.transformClientUpdateMessage");

		}
		return data;
	}
	
	
	

	/**
	 * 
	 * @param name
	 * @param node
	 * @return
	 */
	private boolean isNodeEmpty (String name, JsonNode node)
	{
		if ( StringUtils.isEmpty( node.get(name)) || node.get(name).isNull())
		{
			return true;
		}
		return false;
		
	}
	/**
	 * 
	 * @param name
	 * @param node
	 * @return
	 */
	private String getNodeValue(String name, JsonNode node)
	{
		if (isNodeEmpty(name, node))
		{
			return "";
		}
		return node.get(name).textValue();
		
	}
}
