
package com.integration.bean.emx;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"metadata",
"alert"
})
public class EmxAlertwithMetadata implements Serializable
{
	@JsonProperty("metadata")
	private EmxAlertsMetadata metadata;
	
	@JsonProperty("alert")
	private List<EmxAlert> alert = null;
	
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	
	private final static long serialVersionUID = -5265582167639242199L;
	
	@JsonProperty("metadata")
	public EmxAlertsMetadata getEMoneyAlertsMetadata() {
	return metadata;
	}
	
	@JsonProperty("metadata")
	public void setEMoneyAlertsMetadata(EmxAlertsMetadata metadata) {
	this.metadata = metadata;
	}
	
	@JsonProperty("alert")
	public List<EmxAlert> getAlert() {
	return alert;
	}
	
	@JsonProperty("alert")
	public void setAlert(List<EmxAlert> alert) {
	this.alert = alert;
	}
	
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}
	
	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}

}