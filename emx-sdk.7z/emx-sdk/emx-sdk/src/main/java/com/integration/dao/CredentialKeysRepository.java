package com.integration.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.CredentialKeys;

@Transactional
@Repository
public interface CredentialKeysRepository extends JpaRepository<CredentialKeys, Long> {
	
    /**
     * Finds a person by using the last name as a search criteria.
     * @param lastName
     * @return  A list of persons whose last name is an exact match with the given last name.
     *          If no persons is found, this method returns an empty list.
     */
    @Query("SELECT p FROM CredentialKeys p WHERE p.id = :id")
    public List<CredentialKeys> find(@Param("id") Long id);
    /**
     * 
     * @return
     */
    public CredentialKeys findFirstByOrderByName();

    
    public CredentialKeys findFirstByName(String name);



}
