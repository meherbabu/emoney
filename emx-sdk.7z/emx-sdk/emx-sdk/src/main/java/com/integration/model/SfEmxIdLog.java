package com.integration.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "SF_EMX_ID_LOG")
public class SfEmxIdLog {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
    @Column(nullable = true, name="IS_ID" )
    private String messageId;

//    @NotBlank
    @Column(nullable = true, name="SF_ID")
    private String sfId;

//    @NotBlank
    @Column(nullable = true, name="EMX_ID")
    private String emxId;

//    @NotBlank
    @Column(nullable = true, name="SF_ORG")
    private String sforgId;

//    @NotBlank
    @Column(nullable = true, name="SF_OFFICE")
    private String sfofficeId;

//    @NotBlank
    @Column(nullable = true, name="ENTITY_TYPE")
    private String entityType;
    
    public SfEmxIdLog(){
    	super();
    }

    public SfEmxIdLog(String messageId, String sfId, String emxId, String sforgId, String sfofficeId,
			String entityType) {
		super();		
		this.messageId = messageId;
		this.sfId = sfId;
		this.emxId = emxId;
		this.sforgId = sforgId;
		this.sfofficeId = sfofficeId;
		this.entityType = entityType;
	}
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getSfId() {
		return sfId;
	}

	public void setSfId(String sfId) {
		this.sfId = sfId;
	}

	public String getEmxId() {
		return emxId;
	}

	public void setEmxId(String emxId) {
		this.emxId = emxId;
	}

	public String getSforgId() {
		return sforgId;
	}

	public void setSforgId(String sforgId) {
		this.sforgId = sforgId;
	}

	public String getSfofficeId() {
		return sfofficeId;
	}

	public void setSfofficeId(String sfofficeId) {
		this.sfofficeId = sfofficeId;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	} 
    


}
