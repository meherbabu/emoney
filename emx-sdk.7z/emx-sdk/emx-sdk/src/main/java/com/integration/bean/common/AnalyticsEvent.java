package com.integration.bean.common;


import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"tracking_id",
		"clientId" , 
		"noteId" ,
		"alertId" ,
        "message_id",
        "ids",
        "src",
        "destination",
        "event_name",
        "event_type",
        "timestamp",
        "status",
        "final_status"
})
public class AnalyticsEvent {

	@JsonProperty("tracking_id")
    private String trackingId;
	@JsonProperty("clientId")
	private String clientId;
	@JsonProperty("noteId")
	private String noteId;
	@JsonProperty("alertId")
	private String alertId;
	@JsonProperty("message_id")
    private String messageId;
    @JsonProperty("ids")
    private Id ids = null;
    @JsonProperty("src")
    private String src;
    @JsonProperty("destination")
    private String destination;
    @JsonProperty("event_name")
    private String eventName;
    @JsonProperty("event_type")
    private String eventType;
    @JsonProperty("timestamp")
    private String timestamp;
    @JsonProperty("status")
    private String status;
    @JsonProperty("final_status")
    private String finalStatus;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    
    public AnalyticsEvent(){
    	super();
    }

    public AnalyticsEvent(String clientId, Id ids, String src, String destination, String eventName, String eventType, String timestamp, String status, String finalStatus, Map<String, Object> additionalProperties) {
        this.clientId = clientId;
        this.ids = ids;
        this.src = src;
        this.destination = destination;
        this.eventName = eventName;
        this.eventType = eventType;
        this.timestamp = timestamp;
        this.status = status;
        this.finalStatus = finalStatus;
        this.additionalProperties = additionalProperties;
    }

    public AnalyticsEvent(String trackingId, String messageId, Id ids, String src, String destination, String eventName,
                          String eventType, String timestamp, String status, String finalStatus,
                          Map<String, Object> additionalProperties) {
		super();
		this.trackingId = trackingId;
		this.messageId = messageId;
		this.ids = ids;
		this.src = src;
		this.destination = destination;
		this.eventName = eventName;
		this.eventType = eventType;
		this.timestamp = timestamp;
		this.status = status;
		this.finalStatus = finalStatus;
		this.additionalProperties = additionalProperties;
	}
    
	public String getAlertId() {
		return alertId;
	}

	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	@JsonProperty("clientId")
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@JsonProperty("noteId")
	public String getNoteId() {
		return noteId;
	}

	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	
	@JsonProperty("message_id")
    public String getMessageId() {
        return messageId;
    }

    @JsonProperty("message_id")
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    @JsonProperty("ids")
    public Id getIds() {
    return ids;
    }

    @JsonProperty("ids")
    public void setIds(Id ids) {
    this.ids = ids;
    }

    @JsonProperty("src")
    public String getSrc() {
        return src;
    }

    @JsonProperty("src")
    public void setSrc(String src) {
        this.src = src;
    }

    @JsonProperty("destination")
    public String getDestination() {
        return destination;
    }

    @JsonProperty("destination")
    public void setDestination(String destination) {
        this.destination = destination;
    }

    @JsonProperty("event_name")
    public String getEventName() {
        return eventName;
    }

    @JsonProperty("event_name")
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    @JsonProperty("event_type")
    public String getEventType() {
        return eventType;
    }

    @JsonProperty("event_type")
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @JsonProperty("timestamp")
    public String getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("final_status")
    public String getFinalStatus() {
        return finalStatus;
    }

    @JsonProperty("final_status")
    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

	@Override
	public String toString() {
		return "AnalyticsEvent [trackingId=" + trackingId + ", clientId=" + clientId + ", noteId=" + noteId
				+ ", messageId=" + messageId + ", ids=" + ids + ", src=" + src + ", destination=" + destination
				+ ", eventName=" + eventName + ", eventType=" + eventType + ", timestamp=" + timestamp + ", status="
				+ status + ", finalStatus=" + finalStatus + ", additionalProperties=" + additionalProperties + "]";
	}
}

