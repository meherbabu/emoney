package com.integration.bean.emx;

public class EmxClientNoteRequest {
	
	private String uriString;
	
	private String text;

	public String getUriString() {
		return uriString;
	}

	public void setUriString(String uriString) {
		this.uriString = uriString;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "EMoneyClientNoteRequest [uriString=" + uriString + ", text=" + text + "]";
	}
	
	
}
