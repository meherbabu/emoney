package com.integration.bean.emx;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.PiiDataLog;
@Component
public class EmxSfNotesPiiDataImpl implements PiiDataLog  {
	
	@JsonProperty("eMoneyId")
    private String eMoneyId;
					
	@JsonProperty("eMoneyNoteId")                                 //Change or correction 
    private String eMoneyNoteId;
    
	public void setPiiData(String eMoneyId,String noteId) {		
		this.setnoteId(noteId);
		this.setmessageId(eMoneyId);		
	}
		   
	
	public String geteMoneyId() {
	         return eMoneyId;
	   }


	public void setmessageId(String eMoneyId) {
	        this.eMoneyId = eMoneyId;
	   }
   
	public String getnoteId() {                            //Change or correction 
	         return eMoneyNoteId;
	  }


	public void setnoteId(String eMoneyNoteId) {          //Change or correction 
	        this.eMoneyNoteId = eMoneyNoteId;
	 }
	
	
	@Override
	public String logPiiData() {
	  return "SFNote{" +
				    "eMoneyId='" + eMoneyId+ '\'' +
				    ", eMoneyNoteId='" + eMoneyNoteId+   //Change or Correction 
				    '}';
	 }

}
