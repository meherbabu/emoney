package com.integration.service;

/**
 * //TODO JAVA DOC
 */
public interface AnalyticsEventPublisher {
	/**
	 * 
	 * @param object
	 */
	public void publish(Object object);
}
