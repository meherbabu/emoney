package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;


/*import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.NotBlank;*/

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.sf.RmqMessage;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonSerialize
@ApiModel(description = "Sample EMXClientRequest Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
public class EmxClientRequestV2 implements Serializable, RmqMessage{
	
	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -7476751075356736688L;
	
	@NotNull (message="tracking id NULL not allowed")	
	@JsonProperty("trackingID")
	private String trackingID;
	
	@NotNull(message="sourceSystem null not allowed")
	@JsonProperty("sourceSystem")
	private String sourceSystem;

	@NotNull(message="clients cannot be Null")
	@Valid
	@JsonProperty("clients")
	private EmxClientDataV2[] clients;

	@ApiModelProperty(required = true, value = "The request message must contain tracking ID. It cannot be null and empty")
	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}
	
	@ApiModelProperty(required = true, value = "The request message must contain SourceSystem.It cannot be null and empty")
	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@Valid
	public EmxClientDataV2[] getClients() {
		return clients;
	}

	public void setClients(EmxClientDataV2[] clients) {
		this.clients = clients;
	}

	@Override
	public String toString() {
		return "EMoneyClientRequest [trackingID=" + trackingID + ", sourceSystem=" + sourceSystem + ", clients=" + clients
				+ "]";
	}
	
	
	
}
