package com.integration.bean.emx;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.integration.bean.sf.RmqMessage;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



@JsonSerialize
@ApiModel(description = "Sample EMoneyFClientRequest Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
public class EmxClientRequest implements Serializable, RmqMessage{

	/**
	 * Added to handle VO request
	 */
	
	private static final long serialVersionUID = -4501593306356074234L;
	
	@NotNull (message="id NULL not allowed")
	@JsonProperty("id")
	private String id;
	
	
	@NotNull(message="client cannot be Null")
	@Valid
	@JsonProperty("client")
	private EmxClient client;
	
	@NotNull(message="spouse cannot be Null")
	@Valid
	@JsonProperty("spouse")
	private EmxClient spouse;
	
	@NotNull(message="address cannot be Null")
	@Valid
	@JsonProperty("address")
	private EmxAddress address;
	
	@Size(max = 19)
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "homePhone must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	@JsonProperty("homePhone")
	private String homePhone;
	
	@Size(max = 19)
	@Pattern(regexp = "\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*", message = "fax must be 0 to 9 numbers only and spl charecters (, - and ) are allowed , supported combination 1234567890,123-456-7890,123.456.7890,123 456 7890,(123) 456 7890,(234) 234-3223,(234) 234-3223 x3223")
	@JsonProperty("fax")
	private String fax;
	
	@JsonProperty("maritalStatus")
	@JsonInclude(Include.NON_EMPTY)	
	private String maritalStatus;
	
	@JsonProperty("basePlanId")
	private String basePlanId;
	
	
	@JsonProperty("ownerId")
	@JsonInclude(Include.NON_EMPTY)	
	private String ownerId;

	@ApiModelProperty(required = true, value = "The request message must contain ID. It cannot be null and empty")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EmxClient getClient() {
		return client;
	}

	public void setClient(EmxClient client) {
		this.client = client;
	}

	public EmxClient getSpouse() {
		return spouse;
	}

	public void setSpouse(EmxClient spouse) {
		this.spouse = spouse;
	}

	public EmxAddress getAddress() {
		return address;
	}

	public void setAddress(EmxAddress address) {
		this.address = address;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getBasePlanId() {
		return basePlanId;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public void setBasePlanId(String basePlanId) {
		this.basePlanId = basePlanId;
	}

	@Override
	public String toString() {
		return "EmxClientRequest{" +
				"id='" + id + '\'' +
				", client=" + client +
				", spouse=" + spouse +
				", address=" + address +
				", homePhone='" + homePhone + '\'' +
				", fax='" + fax + '\'' +
				", maritalStatus='" + maritalStatus + '\'' +
				", basePlanId='" + basePlanId + '\'' +
				", ownerId='" + ownerId + '\'' +
				'}';
	}
}
