package com.integration.bean.emx;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.bean.common.PiiDataLog;
@Component
public class EmxSFTaskPiiDataImpl implements PiiDataLog {

	// TODO Auto-generated method stub
     @JsonProperty("orgId")
     private String orgId;

	 @JsonProperty("assignedTo")
	 private String assignedTo;
	 
	 @JsonProperty("eMoneyId")
	 private String eMoneyId;
	 
	 @JsonProperty("eMoneyTaskId")
	 private String eMoneyTaskId;
	 
	 @JsonProperty("messageId")
	 private String messageId;
	 
	 @JsonProperty("taskId")
	 private String taskId;
	 
	public void setPiiData(String taskId, String orgId, String eMoneyId, 
			String eMoneyTaskId, String messageId,String assignedTo) {
		this.setorgId(orgId);
		this.setassignedTo(assignedTo);
		this.seteMoneyId(eMoneyId);
		this.seteMoneyTaskId(eMoneyTaskId);
		this.setmessageId(messageId);
		this.settaskId(taskId);			
	}
	 
	 public String getorgId() {
	         return orgId;
	  }
	
	 public void setorgId(String orgId) {
	        this.orgId = orgId;
	  }
	 
	 public String getassignedTo() {
	         return assignedTo;
	  }
	 
	 public void setassignedTo(String assignedTo) {
	        this.assignedTo = assignedTo;
	  }
  
	 public String geteMoneyId() {
	         return eMoneyId;
	  }

	 public void seteMoneyId(String eMoneyId) {
	        this.eMoneyId = eMoneyId;
	  }
  
	 public String geteMoneyTaskId() {
	         return eMoneyTaskId;
	  }

	 public void seteMoneyTaskId(String eMoneyTaskId) {
	        this.eMoneyTaskId = eMoneyTaskId;
	  }
	
	 public String getmessageId() {
	         return messageId;
	  }
	 
	 public void setmessageId(String messageId) {
	        this.messageId = messageId;
	  }
	 @JsonProperty("taskId")  
	  public String gettaskId() {
	         return taskId;
	  }
	 @JsonProperty("taskId")
	 public void settaskId(String taskId) {
	        this.taskId = taskId;
	  }
	 
	@Override
	public String logPiiData() {
	
		 return "SFTask{" +
	            "orgId='" + orgId + '\'' +
	            ", assignedTo='" + assignedTo+ '\'' +
	            ", eMoneyId='" + eMoneyId+ '\'' +
	            ", eMoneyTaskId='" + eMoneyTaskId+ '\'' +
	            ", messageId='" + messageId+ '\'' +
	            ", taskId='" + taskId+ '\'' +
	            '}';

	 }	
	
}
