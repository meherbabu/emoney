package com.integration.bean.common;

public enum EnumEventSourceNDestination {
	SF,
	RMQ,
	EMX;
}
