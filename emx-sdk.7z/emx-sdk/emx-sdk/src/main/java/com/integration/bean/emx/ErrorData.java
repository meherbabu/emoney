package com.integration.bean.emx;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author dkapa
 * 
 * POJO Class for ErrorData
 * 
 */
@JsonSerialize
public class ErrorData {

	private String errorCode;

	private String errorDesc;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}


}
