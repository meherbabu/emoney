package com.integration.service;

import java.util.Map;

import org.springframework.http.HttpMethod;

import com.integration.bean.common.SourceSystem;
import com.integration.exception.SendToExchangeException;

public interface HttpExchangeService {
	/**
	 * 
	 * @param url
	 * @param method
	 * @param message
	 * @return
	 */
	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headers, String message)
			throws SendToExchangeException;

	/**
	 * @param url
	 * @param method
	 * @param message
	 * @param requestParamsValues
	 * @return
	 */
	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headers, String message,
			Map<String, Object> requestParamsValues) throws SendToExchangeException;


	/**
	 * 
	 * @param url
	 * @param method
	 * @param headers
	 * @param object
	 * @param requestParamsValues
	 * @return
	 * @throws SendToExchangeException
	 */
	public Object sendToExchange(String url, HttpMethod method, Map<String, String> headers, Object object,
								 Map<String, Object> requestParamsValues) throws SendToExchangeException;
	/**
	 * 
	 * @param desti
	 * @param source
	 * @param url
	 * @param method
	 * @param headersMap
	 * @param message
	 * @param requestParamsValues
	 * @return
	 * @throws SendToExchangeException
	 */
	public Object sendToExchange(SourceSystem desti,String source, String url, HttpMethod method, Map<String, String> headersMap, String message,
			Map<String, Object> requestParamsValues) throws SendToExchangeException;
	/**
	 * 
	 * @param desti
	 * @param source
	 * @param url
	 * @param method
	 * @param headersMap
	 * @param message
	 * @return
	 * @throws SendToExchangeException
	 */
	public Object sendToExchange(SourceSystem desti, String source, String url, HttpMethod method, Map<String, String> headersMap, String message)
			throws SendToExchangeException ;
	

}
