package com.integration.dao;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.integration.model.Credential;
import com.integration.model.CredentialKeys;
import com.integration.model.CredentialParams;
import com.integration.service.token.JWTTokenParams;

@Service
public class CredentialService {

	private CredentialKeysRepository credentialKeysRepository;

	private CredentialParamsRepository credentialParamsRepository;

	private CredentialRepository credentialRepository;
	
	private SforgEmxoffMapRepository sforgEmxoffMapRepository;

	@Autowired
	public CredentialService(CredentialKeysRepository credentialKeysRepository,
			CredentialParamsRepository credentialParamsRepository, CredentialRepository credentialRepository,
			SforgEmxoffMapRepository sforgEmxoffMapRepository) {
		this.credentialKeysRepository = credentialKeysRepository;
		this.credentialParamsRepository = credentialParamsRepository;
		this.credentialRepository = credentialRepository;
		this.sforgEmxoffMapRepository = sforgEmxoffMapRepository;

		// TODO Auto-generated constructor stub
	}

	@Transactional(readOnly = true)
	public JWTTokenParams getTokenParams(String orgId) throws Exception {
		return getTokenParams(orgId, null);

	}
	
	@Transactional(readOnly = true)
	public JWTTokenParams getTokenParams(String appId, String appName) throws Exception {
		JWTTokenParams jWTTokenParams;
		try {
			jWTTokenParams = new JWTTokenParams();

			List<Credential> credList = (StringUtils.isEmpty(appName)) ? credentialRepository.find(appId)
					: credentialRepository.find(appId, appName);	   
			
			if (credList == null || credList.isEmpty()) {
				throw new Exception("Cannot find credential for appId [" + appId + "]");
			}

			List<CredentialKeys> credentialKeysList = credentialKeysRepository.find(credList.get(0).getCredKeysId());

			if (credentialKeysList == null || credentialKeysList.isEmpty()) {
				throw new Exception("Cannot find credential Keys for appId [" + appId + "]");
			}
			
			List<CredentialParams> credentialParamsList =  credentialParamsRepository.find(credList.get(0).getId());
			
			if (credentialParamsList == null || credentialParamsList.isEmpty()) {
				throw new Exception("Cannot find credential Params for appId [" + appId + "]");
			}
			
			// set credential key
			jWTTokenParams.setPrivateKeyString(credentialKeysList.get(0).getPrivateKey());
			// Set param/value to JWtToken
			for ( CredentialParams cre : credentialParamsList)
			{
				BeanUtils.setProperty(jWTTokenParams, cre.getParamName(), cre.getParamValue());
			}
		} catch (Exception e) {
			
			throw e;
		}
		return jWTTokenParams;

	}
	
	@Transactional(readOnly = true)
	public String getAppIdUsingEmxOffice(String emxOffice) throws Exception {
		return sforgEmxoffMapRepository.findOrgId(emxOffice);
	}

	@Transactional(readOnly = true)
	public String getAppIdUsingOrgId(String orgId) throws Exception {
		return sforgEmxoffMapRepository.findEmxOffice(orgId);
	}


}
