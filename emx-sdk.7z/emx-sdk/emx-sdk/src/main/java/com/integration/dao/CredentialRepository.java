package com.integration.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.integration.model.Credential;

@Transactional
@Repository
public interface CredentialRepository extends JpaRepository<Credential, Long> {
	
    @Query("SELECT p FROM Credential p WHERE LOWER(p.appId) = LOWER(:appId)")
    public List<Credential> find(@Param("appId") String orgId);

    @Query("SELECT p FROM Credential p WHERE LOWER(p.appId) = LOWER(:appId) and LOWER(p.appName) = LOWER(:appName)")
    public List<Credential> find(@Param("appId") String appId, @Param("appName")  String appName);
    
    public Credential findFirstByAppId (String appId);
    
}
