package com.integration.bean.common;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Metadata Object")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-09-23T11:17:57.830-04:00")
@JsonSerialize
@Valid
public class Metadata implements Serializable{
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = -1974181183951603298L;

	@NotNull(message="orgId cannotbe null")
	@Size(min = 1)
	@JsonProperty("orgId")
	private String orgId;
	
	@NotNull(message="orgId cannotbe null")
	@Size(min = 1)
	@JsonProperty("office")
	private String office;

	@ApiModelProperty(required = true, value = "The request message must contain orgId.It cannot be null and empty")
	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	@ApiModelProperty(required = true, value = "The request message must contain office.It cannot be null and empty")
	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	@Override
	public String toString() {
		return "Metadata [orgId=" + orgId + ", office=" + office + "]";
	}

}
