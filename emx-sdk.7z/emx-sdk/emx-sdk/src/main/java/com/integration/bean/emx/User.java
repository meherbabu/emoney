package com.integration.bean.emx;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

@JsonSerialize
public class User implements Serializable {
     @JsonProperty("id")
    private String id;
     @JsonProperty("office")
    private String office;
     @JsonProperty("roles")
    private String roles[];
     @JsonProperty("firstName")
    private String firstName;
     @JsonProperty("lastName")
    private String lastName;
     @JsonProperty("displayName")
    private String displayName;
     @JsonProperty("companyName")
    private String companyName;
     @JsonProperty("businessEmail")
    private String businessEmail;


    @JsonProperty("id")
    public String getId() {
        return id;
    }
    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }
    @JsonProperty("office")
    public String getOffice() {
        return office;
    }
    @JsonProperty("office")
    public void setOffice(String office) {
        this.office = office;
    }
    @JsonProperty("roles")
    public String[] getRoles() {
        return roles;
    }
    @JsonProperty("roles")
    public void setRoles(String[] roles) {
        this.roles = roles;
    }
    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }
    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }
    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }
    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    @JsonProperty("companyName")
    public String getCompanyName() {
        return companyName;
    }
    @JsonProperty("companyName")
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    @JsonProperty("businessEmail")
    public String getBusinessEmail() {
        return businessEmail;
    }
    @JsonProperty("businessEmail")
    public void setBusinessEmail(String businessEmail) {
        this.businessEmail = businessEmail;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", office='" + office + '\'' +
                ", roles=" + Arrays.toString(roles) +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", displayName='" + displayName + '\'' +
                ", companyName='" + companyName + '\'' +
                ", businessEmail='" + businessEmail + '\'' +
                '}';
    }
}