package com.integration.bean.common;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.http.HttpMethod;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
public class ExchangeExceptionMessageBean {

	
	
	@JsonProperty("sourceSystem")
	private String sourceSystem;
		
	@JsonProperty("headers")
	private Map<String, String> headers = new HashMap<String, String>();
	
	@JsonProperty("requestParamsValues")
	Map<String, Object> requestParamsValues = new HashMap<String, Object>();
	
	@JsonProperty("method")
	private HttpMethod method;
	
	@JsonProperty("source")
	private String source;
	
	@JsonProperty("destination")
	private String destination;
	
	@JsonProperty("payload")
	private String payload;
	
	@JsonProperty("errorCode")
	private String errorCode;
	
	@JsonProperty("errorMessage")
	private String errorMessage;

	public ExchangeExceptionMessageBean() {
		super();
	}

	public ExchangeExceptionMessageBean(String source, String destination, HttpMethod method,
			Map<String, String> headers, String payload, String errorCode) {
		super();
		this.source = source;
		this.destination = destination;
		this.method = method;
		this.headers = headers;
		this.payload = payload;
		this.errorCode = errorCode;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public HttpMethod getMethod() {
		return method;
	}

	public void setMethod(HttpMethod method) {
		this.method = method;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public Map<String, Object> getRequestParamsValues() {
		return requestParamsValues;
	}

	public void setRequestParamsValues(Map<String, Object> requestParamsValues) {
		this.requestParamsValues = requestParamsValues;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	
	
	
	
}
