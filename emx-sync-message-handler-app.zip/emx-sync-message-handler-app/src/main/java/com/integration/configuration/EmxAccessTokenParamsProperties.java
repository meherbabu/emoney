package com.integration.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "jwttoken.emoney")

public class EmxAccessTokenParamsProperties {
	private Map<String, String> paramsValues = new HashMap<String, String>();

	public Map<String, String> getParamsValues() {
		return paramsValues;
	}

	public void setParamsValues(Map<String, String> paramsValues) {
		this.paramsValues = paramsValues;
	}

}
