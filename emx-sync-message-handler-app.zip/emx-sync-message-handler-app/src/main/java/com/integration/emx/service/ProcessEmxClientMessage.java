package com.integration.emx.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxSfClientPiiDataImpl;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.dao.SfEmxIdLogRepository;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.model.SfEmxIdLog;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HandlingExceptionMessagesImpl;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;

@Service
@Qualifier ("ProcessEmxClientMessage")
public class ProcessEmxClientMessage implements ProcessMessage {

	Log logger = LoggerUtil.getLog(this);

	@Value("${saleforce.context.client.create}")
	private String clientCreateContext;

	@Value("${saleforce.context.client.update}")
	private String clientUpdateContext;

	@Value("${saleforce.context.client.delete}")
	private String clientDeleteContext;
	
	private HttpExchangeService httpExchangeService;

	private AccessTokenGenerator acccessTokenGenerator;

	private EmxToSfCommonUtil emxToSfCommonUtils;

	private AnalyticsEventUtil analyticsEventUtil;

	private AnalyticsEventPublisher eventPublisher;

	private SfEmxIdLogRepository sfEmxIdLogRepository;

	private SforgEmxoffMapRepository SforgEmxoffMapRepository;
	
	private HandlingExceptionMessages handlingExceptionMessages;

	private JsonUtility jsonUtility;	
	
	private PiiDataLog piiDataLog;

	/**
	 * 
	 * @param postMessageToSfController
	 * @param sFTokenUtil
	 */
	@Autowired
	public ProcessEmxClientMessage(HttpExchangeService postMessageToSfController, AccessTokenGenerator sFTokenUtil,
			EmxToSfCommonUtil emxToSfCommonUtils, AnalyticsEventUtil analyticsEventUtil,
			AnalyticsEventPublisher eventPublisher, SfEmxIdLogRepository sfEmxIdLogRepository, JsonUtility jsonUtility,
			SforgEmxoffMapRepository SforgEmxoffMapRepository, HandlingExceptionMessagesImpl handlingExceptionMessages,
			EmxSfClientPiiDataImpl emxSfClientPiiDataImpl) {
		this.httpExchangeService = postMessageToSfController;
		this.acccessTokenGenerator = sFTokenUtil;
		this.emxToSfCommonUtils = emxToSfCommonUtils;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.sfEmxIdLogRepository = sfEmxIdLogRepository;
		this.jsonUtility = jsonUtility;
		this.SforgEmxoffMapRepository = SforgEmxoffMapRepository;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.piiDataLog = emxSfClientPiiDataImpl; 

	}

	/**
	 * 
	 * @param message
	 * @param wrapper
	 * @throws Exception
	 */
	@Transactional
	private void createClient(String queueName, String message, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, SendToExchangeException {
		EmxSfClientPiiDataImpl emxSfClientPiiDataImpl = (EmxSfClientPiiDataImpl) piiDataLog;
		try {
			String trackingId = emxToSfCommonUtils.getTrackingIdEmxClient(message);
			String eMoneyId = emxToSfCommonUtils.getEMoneyIDEmxClient(message);
			String messageId = emxToSfCommonUtils.getMessageIDEmxClient(message);
			emxSfClientPiiDataImpl.setPiiData(null,eMoneyId,messageId); 
			  
			wrapper = getEvent("emx-client-create");
			// this array contain String[trackingID, office,"messageID","id","eMoneyId"]
			String[] data = emxToSfCommonUtils.getEmxClientInfoFromMessageQueue(message);
			// get Access Token salesforceOffice-2
			Map<String, String> headers = acccessTokenGenerator
					.getSaleforceAccessTokenHeadersUsingEmoneyOffice(data[1]);
			String url = acccessTokenGenerator.getSaleforceUrlUsingEmoney(data[1]) + clientCreateContext;

			eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).add("eMoneyId", data[4])
					.setMessageIdValue(data[2]).add("id", data[3]).add("office", data[1]));
	        eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.STAGED));

			// DB works
			String orgId = SforgEmxoffMapRepository.findOrgId(data[1]);

			SfEmxIdLog mappingDBObject = new SfEmxIdLog();
			mappingDBObject.setEmxId(data[4]);
			mappingDBObject.setSfofficeId(data[1]);
			mappingDBObject.setEntityType("EMX");
			mappingDBObject.setMessageId(emxToSfCommonUtils.getMessageIdEmxClient(message));			
			mappingDBObject.setSforgId(orgId);
			//sfEmxIdLogRepository.saveAndFlush(mappingDBObject);

			eventPublisher.publish(wrapper.success());

			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.TRANSFORMING));
			// TransformMessages
			List<Object[]> objectArray = emxToSfCommonUtils.transformClientUpdateMessage(message);
			//PII Data 
			emxSfClientPiiDataImpl.setPiiData(null, mappingDBObject.getEmxId(), mappingDBObject.getMessageId()); 
			  
			eventPublisher.publish(wrapper.success());

			for (Object[] objects : objectArray) {

				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));

				Object responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
						HttpMethod.PATCH, headers, objects[1].toString());

				if (!StringUtils.isEmpty(responseObject.toString())) {
					List<Map<String, Object>> mapResponse = jsonUtility
							.getListMapFromJsonString(String.valueOf(responseObject));
					try {
						if (mapResponse != null && !mapResponse.isEmpty()) {
							String sfId = String.valueOf(mapResponse.get(0).get("id"));
							if (!StringUtils.isEmpty(sfId)){
								mappingDBObject.setSfId(sfId);// from response fill temp value
								//sfEmxIdLogRepository.updateOrgId(sfId, mappingDBObject.getEmxId(),mappingDBObject.getSfofficeId());
							}
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						logger.info("Exception parsing data from response.  Ignore error", e);
					}
				}
				createOrUpdateSfEmxIDLog(mappingDBObject,MessageType.CREATE.toString());
				
	        	
				logger.info("Sponse from SF Create Client  " + responseObject);

				eventPublisher.publish(wrapper.success().add("Response message", responseObject));

				eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.TRANSFORMING));
			}
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}

	}
	
	void createOrUpdateSfEmxIDLog(SfEmxIdLog mappingObject, String operation) {
		List<SfEmxIdLog> emxIdList = null;
		if(operation.equals(MessageType.CREATE.toString())){
			if(mappingObject.getEmxId()!=null){
				emxIdList = this.sfEmxIdLogRepository.findByEMXID(mappingObject.getEmxId());
			}
		}else{
			if(mappingObject.getEmxId()!=null){
				emxIdList = this.sfEmxIdLogRepository.findByEMXID(mappingObject.getEmxId());
			}
		}
		
		if(emxIdList!=null && !emxIdList.isEmpty()){
			//update
			SfEmxIdLog sfemxdbObject = emxIdList.get(0);
			savetoDbSFEMXLog(mappingObject, sfemxdbObject);
		}else{
			//create
			SfEmxIdLog sfemxdbObject = new SfEmxIdLog();
			savetoDbSFEMXLog(mappingObject, sfemxdbObject);
		}
		
	}

	private void savetoDbSFEMXLog(SfEmxIdLog mappingObject, SfEmxIdLog sfemxdbObject) {
		sfemxdbObject.setEmxId(mappingObject.getEmxId());			
		sfemxdbObject.setEntityType(mappingObject.getEntityType());			
		sfemxdbObject.setMessageId(mappingObject.getMessageId());
		sfemxdbObject.setSfId(mappingObject.getSfId());
		sfemxdbObject.setSfofficeId(mappingObject.getSfofficeId());
		sfemxdbObject.setSforgId(mappingObject.getSforgId());	
		SfEmxIdLog entityMappingSaved = this.sfEmxIdLogRepository.saveAndFlush(sfemxdbObject);
		logger.info("DB Object: "+entityMappingSaved.toString());
	}

	/**
	 * 
	 * @param message
	 * @param wrapper
	 * @throws Exception
	 */
	@Transactional
	private void updateClient(String queueName, String message, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, SendToExchangeException {
		EmxSfClientPiiDataImpl emxSfClientPiiDataImpl = (EmxSfClientPiiDataImpl) piiDataLog;
		try {
			String trackingId = emxToSfCommonUtils.getTrackingIdEmxClient(message);
			String eMoneyId = emxToSfCommonUtils.getEMoneyIDEmxClient(message);
			String messageId = emxToSfCommonUtils.getMessageIDEmxClient(message);
			emxSfClientPiiDataImpl.setPiiData(null,eMoneyId,messageId); 
			
			// this array contain String[trackingID, office,"messageID","id","eMoneyId"]
			String[] data = emxToSfCommonUtils.getEmxClientInfoFromMessageQueue(message);
			// get Access Token
			Map<String, String> headers = acccessTokenGenerator
					.getSaleforceAccessTokenHeadersUsingEmoneyOffice(data[1]);
			String url = acccessTokenGenerator.getSaleforceUrlUsingEmoney(data[1]) + clientUpdateContext;

			wrapper = getEvent("emx-client-update");
			eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).add("eMoneyId", data[4])
					.setMessageIdValue(data[2]).add("id", data[3]).add("office", data[1]));

			// DB works
			String orgId = SforgEmxoffMapRepository.findOrgId(data[1]);

			SfEmxIdLog mappingDBObject = new SfEmxIdLog();
			mappingDBObject.setEmxId(data[4]);
			mappingDBObject.setSfofficeId(data[1]);
			mappingDBObject.setEntityType("EMX");
			mappingDBObject.setMessageId(emxToSfCommonUtils.getMessageIdEmxClient(message));			
			mappingDBObject.setSforgId(orgId);
			// TransformMessages
			List<Object[]> objectArray = emxToSfCommonUtils.transformClientUpdateMessage(message);
			for (Object[] objects : objectArray) {
				//emxSfClientPiiDataImpl.setPiiData(trackingId, String.valueOf(objects[1]),String.valueOf(objects[0]));  
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
			
				Object responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
						HttpMethod.PATCH, headers, objects[1].toString());

				logger.info("Sponse from SF Update Client  " + responseObject);
				if (!StringUtils.isEmpty(responseObject.toString())) {
					List<Map<String, Object>> mapResponse = jsonUtility
							.getListMapFromJsonString(String.valueOf(responseObject));
					try {
						if (mapResponse != null && !mapResponse.isEmpty()) {
							String sfId = String.valueOf(mapResponse.get(0).get("id"));
							if (!StringUtils.isEmpty(sfId)){
								mappingDBObject.setSfId(sfId);// from response fill temp value
								//sfEmxIdLogRepository.updateOrgId(sfId, mappingDBObject.getEmxId(),mappingDBObject.getSfofficeId());
							}
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						logger.info("Exception parsing data from response.  Ignore error", e);
					}
				}
				createOrUpdateSfEmxIDLog(mappingDBObject,MessageType.UPDATE.toString());
				
				eventPublisher.publish(wrapper.success());
				eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.TRANSFORMING));
			}
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}

	}

	/**
	 * 
	 * @param message
	 * @param wrapper
	 * @throws Exception
	 */
	@Transactional
	private void deleteClient(String queueName, String message, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, SendToExchangeException {
		// this array contain Map keys "clientId", "office","orgId","trackingId"
		// get Access Token
		EmxSfClientPiiDataImpl emxSfClientPiiDataImpl = (EmxSfClientPiiDataImpl) piiDataLog;
		try {
			Map<String, Object> deleteMaps = jsonUtility.getMapFromJsonString(message);

			String clientId = String.valueOf(deleteMaps.get("clientId"));
			String office = String.valueOf(deleteMaps.get("office"));
			String orgId = String.valueOf(deleteMaps.get("orgId"));
			String trackingId = String.valueOf(deleteMaps.get("trackingId"));
			emxSfClientPiiDataImpl.setPiiData(null, clientId, null); 
			 
			wrapper = getEvent("emx-client-delete");
			eventPublisher.publish(wrapper.setTrackingIdValue(trackingId).setClientIdValue(clientId)
					.add("office", office).add("orgId", orgId));

			// get Access Token
			Map<String, String> headers = acccessTokenGenerator.getSaleforceAccessTokenHeadersUsingEmoneyOffice(office);
			String url = acccessTokenGenerator.getSaleforceUrlUsingEmoney(office) + clientDeleteContext;
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));

			Object responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
					HttpMethod.DELETE, headers, null, deleteMaps);

			logger.info("Sponse from SF delete Client  " + responseObject);
			eventPublisher.publish(wrapper.success().add("Response", responseObject));
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.TRANSFORMING));
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}

	}

	/**
	 * 
	 * @param type
	 * @param message
	 * @throws Exception
	 */
	@Override
	public void processMessage(String queueName, MessageType type, String message) {

		logger.info("Start ProcessEmxClientMessage.processMessage");
		logger.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
		logger.debug(message);
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
		try {
			switch (type) {

			case CREATE:
				createClient(queueName, message, wrapper);
				break;
			case UPDATE:
				updateClient(queueName, message, wrapper);
				break;
			case DELETE:
				deleteClient(queueName, message, wrapper);
			default:
				break;
			}
		} catch (SendToExchangeException e) {
			logger.error("Exception in ProcessEmxClientMessage.processMessage" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
		} catch (Exception e) {
			logger.error("Exception in ProcessEmxClientMessage.processMessage" + piiDataLog.logPiiData(), e);
			handlingExceptionMessages.processException(
					SourceSystem.EMONEY,
					new SendToExchangeException(e), 
					queueName,						
					message
					);
			eventPublisher.publish(
					wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));		
		}
		logger.info("End ProcessEmxClientMessage.processMessage");
	}

	/**
	 * 
	 * @param name
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */

	private AnalyticsEventWrapper getEvent(String name) throws AnalyticsEventPublisherException {
		try {
			return analyticsEventUtil.getEvent(name);
		} catch (Exception e) {

			throw new AnalyticsEventPublisherException(
					"Exception in getEvent eventName[ " + name + "]" + e.getMessage());
		}

	}
	@Override
	public void processMessage(String queueName, MessageType type, Object message) {
		// TODO Auto-generated method stub
		
	}

}
