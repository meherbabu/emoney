package com.integration.emx.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxAlert;
import com.integration.bean.emx.EmxAlertsAnalyticsEvent;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.dao.SfEmxHeaderMapRepository;
import com.integration.dao.SfEmxIdLogRepository;
import com.integration.dao.SfEmxMappingRepository;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.SendToExchangeException;
import com.integration.model.SfEmxHeaderMap;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;

@Service
@Qualifier ("ProcessEmxAlertMessage")
public class ProcessEmxAlertMessage implements ProcessMessage {

	Log logger = LoggerUtil.getLog(this);
	
	@Value("${emx.sf.alert.client.id}")
    private String clientIdValue;

	@Value("${saleforce.url}")
	private String saleforceUrl;

	@Value("${saleforce.context.client.create}")
	private String clientCreateContext;
	@Value("${saleforce.context.client.update}")
	private String clientUpdateContext;
	@Value("${saleforce.context.client.delete}")
	private String clientDeleteContext;
	
	@Value("${saleforce.context.alert.create}")
	private String alertCreateContext;
	@Value("${saleforce.context.alert.update}")
	private String alertUpdateContext;
	@Value("${saleforce.context.alert.delete}")
	private String alertDeleteContext;
	
    @Value("${mq.emx.alert.response.exchange}")
    private String responseExchange;
    @Value("${mq.emx.alert.response.routingkey}")
    private String responseRoutingkey;
    
    @Value("${mq.emx.alert.response.persistence: false}")
    private boolean isPersistent;

	private HttpExchangeService httpExchangeService;
	private AccessTokenGenerator sFTokenUtil;
	private EmxToSfCommonUtil commonUtils;
	private AnalyticsEventUtil analyticsEventUtil;
	private AnalyticsEventPublisher eventPublisher;
    private SforgEmxoffMapRepository SforgEmxoffMapRepository;
    private JsonUtility jsonUtility; 
    private SfEmxHeaderMapRepository sfEmxHeaderMapRepository;
    private MessageSender emxMessageSender;	
    private SfEmxMappingRepository sfEmxMappingRepository;
    private HandlingExceptionMessages handlingExceptionMessages;

	/**
	 * 
	 * @param postMessageToSfController
	 * @param sFTokenUtil
	 */
	@Autowired
	public ProcessEmxAlertMessage(HttpExchangeService postMessageToSfController,
			AccessTokenGenerator sFTokenUtil, EmxToSfCommonUtil commonUtils,
			AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher,
			SfEmxIdLogRepository sfEmxIdLogRepository,
			JsonUtility jsonUtility,
			SforgEmxoffMapRepository SforgEmxoffMapRepository,
			SfEmxHeaderMapRepository sfEmxHeaderMapRepository,
			MessageSender messageSenderImpl, SfEmxMappingRepository sfEmxMappingRepository,
			HandlingExceptionMessages handlingExceptionMessages ) {
		this.httpExchangeService = postMessageToSfController;
		this.sFTokenUtil = sFTokenUtil;
		this.commonUtils = commonUtils;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.jsonUtility = jsonUtility;
		this.SforgEmxoffMapRepository = SforgEmxoffMapRepository;
		this.sfEmxHeaderMapRepository = sfEmxHeaderMapRepository;
		this.emxMessageSender = messageSenderImpl;
		this.sfEmxMappingRepository = sfEmxMappingRepository;
		this.handlingExceptionMessages = handlingExceptionMessages;
		
	}

	/**
	 * 
	 * @param message
	 * @param wrapper
	 * @throws Exception
	 */
	@Transactional
	private void create_Update_Alert(String queueName, String emxAlertJsonMessage, AnalyticsEventWrapper wrapper, String op) throws Exception {
		logger.info("*** Inside ProcessEmxAlertMessage->create_Update_Alert **** ");
		// this array contain String[trackingID, office,"messageID","id","eMoneyId"]
		//String[] data = commonUtils.getEmxClientInfoFromMessageQueue(message);
		// get Access Token salesforceOffice-2
		//this.jsonUtility = new JsonUtility();
		String alertCreateContextLocal = null;
		alertCreateContextLocal = this.alertCreateContext;
		String alertUpdateContextLocal = null;
		alertUpdateContextLocal = this.alertUpdateContext;
		
		EmxAlertsAnalyticsEvent emoneyAlertsAnalyticsEvent = null;
		emoneyAlertsAnalyticsEvent = 
				(EmxAlertsAnalyticsEvent)jsonUtility.getObjectFromJsonString(
						emxAlertJsonMessage, EmxAlertsAnalyticsEvent.class);
		String orgID =null;
		SfEmxHeaderMap sf2emxHeaderMapperObj =null;
		String officeIDStr = emoneyAlertsAnalyticsEvent.getAlerts().get(0).getEMoneyAlertsMetadata().getOffice();	
		if(officeIDStr!=null){
			orgID = this.SforgEmxoffMapRepository.findOrgId(officeIDStr);
		}
		if(orgID!=null){
			sf2emxHeaderMapperObj = sfEmxHeaderMapRepository.findSfEntityObject(orgID, "alert");
		}	 
		
		wrapper = getEvent("emx-alert-create").setTrackingIdValue(emoneyAlertsAnalyticsEvent.getTrackingID());
		wrapper.setAdditionalProperty("office", emoneyAlertsAnalyticsEvent.getAlerts().get(0).getEMoneyAlertsMetadata().getOffice());
		for(EmxAlert alert:emoneyAlertsAnalyticsEvent.getAlerts().get(0).getAlert()){
			wrapper.setAdditionalProperty("clientId", alert.getClientId());
			wrapper.setAdditionalProperty("eMoneyId", alert.geteMoneyId());			
			wrapper.setAdditionalProperty("timeStamp", alert.getTimeStamp());
			wrapper.setAdditionalProperty("subject", alert.getSubject());
			wrapper.setAdditionalProperty("description", alert.getDescription());
			wrapper.setAdditionalProperty("displayName", alert.getDisplayName());
			wrapper.setAdditionalProperty("dismissed", alert.getDismissed());			
		}
		//eventPublisher.publish(wrapper);
		wrapper.success(EnumEventCurrentStatus.RECEIVED);
		eventPublisher.publish(wrapper);
		
		//eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
		wrapper.processing(EnumEventCurrentStatus.TRANSFORMING);
		eventPublisher.publish(wrapper);
		
		
		//*** Begin TransformMessages
		String convertedSFMessagePayload = commonUtils.
				transformAlertMessage(emxAlertJsonMessage,emoneyAlertsAnalyticsEvent);
		//*** End TransformMessages
		
		if(convertedSFMessagePayload==null){
			eventPublisher.publish(wrapper.error());			
		}else{
			eventPublisher.publish(wrapper.success());
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
			// sfurl 
			Map<String, String> headers = sFTokenUtil.getSaleforceAccessTokenHeadersUsingEmoneyOffice(officeIDStr);
			saleforceUrl = sFTokenUtil.getSaleforceUrlUsingEmoney(officeIDStr);
			Object responseObject = null;
			List<EmxAlert> listalert = null;
			String sfentity = sf2emxHeaderMapperObj.getSfEntity();
			listalert = emoneyAlertsAnalyticsEvent.getAlerts().get(0).getAlert();
			if(sfentity!=null){
				
				if(sfentity.startsWith("FinServ")){
					alertCreateContextLocal = alertCreateContextLocal.replaceAll("\\{eMoney_ID\\}", "FinServ__SourceSystemId__c");
					alertUpdateContextLocal = alertUpdateContextLocal.replaceAll("\\{eMoney_ID\\}", "FinServ__SourceSystemId__c");
				}else{
					alertCreateContextLocal = alertCreateContextLocal.replaceAll("\\{eMoney_ID\\}", clientIdValue);
					alertUpdateContextLocal = alertUpdateContextLocal.replaceAll("\\{eMoney_ID\\}", clientIdValue);
				}				
				
				if(op.equals("CREATE")){
					alertCreateContextLocal = alertCreateContextLocal.replaceAll("\\{AlertObjectName\\}", sfentity.trim());
					alertCreateContextLocal = alertCreateContextLocal.replaceAll("\\{AlerteMoneyId\\}", listalert.get(0).geteMoneyId());
					logger.info("** alertCreateContext : "+alertCreateContextLocal);
					String url = saleforceUrl + alertCreateContextLocal;
					logger.info("** URL : "+url);
					responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
							HttpMethod.PATCH, headers, convertedSFMessagePayload);
					
//					responseObject = httpExchangeService.
//								sendToExchange(url,
//								HttpMethod.PATCH, headers, convertedSFMessagePayload);
				}else{
					alertUpdateContextLocal = alertUpdateContextLocal.replaceAll("\\{AlertObjectName\\}",  sf2emxHeaderMapperObj.getSfEntity().trim());
					alertUpdateContextLocal = alertUpdateContextLocal.replaceAll("\\{AlerteMoneyId\\}", listalert.get(0).geteMoneyId());
					logger.info("** alertUpdateContext : "+alertUpdateContextLocal);
					String url = saleforceUrl + alertUpdateContextLocal;
					logger.info("** URL : "+url);
					responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
							HttpMethod.PATCH, headers, convertedSFMessagePayload);
				
//					responseObject = httpExchangeService.
//							sendToExchange(url,
//							HttpMethod.PATCH, headers, convertedSFMessagePayload);
				}
			}else{
				logger.info("*** ERROR: sfentity from sf2emxHeaderMapper table is null  ***");	
			}			
	     	
			if ( !StringUtils.isEmpty(responseObject ))
			{
				eventPublisher.publish(wrapper.error().add("Response message", responseObject));
			}else{
				eventPublisher.publish(wrapper.success().add("Response message", responseObject));
				emxMessageSender.send(responseExchange, responseRoutingkey, isPersistent, "SUCCESS");			
			}
			
			logger.info("Response from Salesforce Create/Update Alert :  " + responseObject);	
		}

	}


	/**
	 * 
	 * @param message
	 * @param wrapper
	 * @throws Exception
	 */
	@Transactional
	private void deleteAlert(String queueName, String message, AnalyticsEventWrapper wrapper) throws Exception {
		logger.info("*** Inside ProcessEmxAlertMessage->deleteAlert **** ");
		// this array contain Map keys "clientId", "office","orgId","trackingId"
		// get Access Token
		Map<String, Object> deleteMaps = jsonUtility.getMapFromJsonString(message);
		String alertDeleteContextLocal = null;
		alertDeleteContextLocal = this.alertDeleteContext;
		
		String clientId = String.valueOf(deleteMaps.get("clientId"));
		String office = String.valueOf(deleteMaps.get("office"));
		String orgId = String.valueOf(deleteMaps.get("orgId"));
		String trackingId = String.valueOf(deleteMaps.get("trackingId"));
		logger.info("** clientId : " + clientId);
		logger.info("** office : " + office);
		logger.info("** orgId : " + orgId);
		logger.info("** trackingId : " + trackingId);
		
		SfEmxHeaderMap sf2emxHeaderMapperObj = sfEmxHeaderMapRepository.findSfEntityObject(orgId, "alert");
		if(sf2emxHeaderMapperObj!=null){
			//List<SfEmxMapping> dbListSfEmxMapping = this.sfEmxMappingRepository.findAllByHeaderMapId(sf2emxHeaderMapperObj.getId());
			
			wrapper = getEvent("emx-alert-delete");
			eventPublisher.publish(
					wrapper.setTrackingIdValue(trackingId)
					.setClientIdValue(clientId)
					.add("office", office)
					.add("orgId", orgId));

			// get Access Token
			Map<String, String> headers = sFTokenUtil.getSaleforceAccessTokenHeaders(orgId);
			saleforceUrl = sFTokenUtil.getSaleforceUrl(orgId);
			
			Object responseObject=null;		
			Object responseObject1=null;
			try {
				//alertCreateContext = alertCreateContext.replaceAll("\\{AlertObjectName\\}",
				//sf2emxHeaderMapperObj.getSfEntity().trim();//);
				//alertCreateContext = alertCreateContext.replaceAll("\\{AlerteMoneyId\\}", clientId);
				logger.info("** alertCreateContext : " + alertCreateContext);
				
				deleteMaps.put("AlertObjectName", sf2emxHeaderMapperObj.getSfEntity().trim());
				deleteMaps.put("AlerteMoneyId", clientId);
				
				String url = saleforceUrl + alertCreateContext;
				logger.info("** URL : " + url);
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
				
				responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
						HttpMethod.GET, headers, null,deleteMaps);
				logger.info("responseObject: "+responseObject);
//				responseObject = httpExchangeService.sendToExchange(url, HttpMethod.GET, headers, null);
				String str = responseObject.toString();
				String sfID = commonUtils.getIdForAlert(str);
				
//				 = null;
//			    String [] arrOfStr = str.split(",", 5);
//			    for (String idStr : arrOfStr){ 			    	
//			    	if(idStr.contains("Id=")){
//			    		idStr = idStr.replaceAll("^\\s+","");			    		
//			    		sfID=idStr.substring(3);			    		
//			    	}
//			    }
			    logger.info("sfID: "+sfID);
				//String alertDeleteContextUrl = alertDeleteContext;
				//alertDeleteContextUrl = alertDeleteContextUrl.replaceAll("\\{AlertObjectName\\}",	sf2emxHeaderMapperObj.getSfEntity().trim());
		//		alertDeleteContextUrl = alertDeleteContextUrl.replaceAll("\\{AlertSalesforceId\\}", sfID);
				logger.info("saleforceUrl+alertDeleteContextUrl : " + saleforceUrl );
				String deleteUrl = saleforceUrl + alertDeleteContextLocal;
				
				deleteMaps.put("AlertObjectName", sf2emxHeaderMapperObj.getSfEntity().trim());
				deleteMaps.put("AlertSalesforceId", sfID);

				responseObject1 = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, deleteUrl,
						HttpMethod.DELETE, headers, null, deleteMaps);
				
//				responseObject1 = httpExchangeService.sendToExchange(saleforceUrl + alertDeleteContext, HttpMethod.DELETE,
//						headers, null, deleteMaps);
				logger.info("Response from SF delete Alert  " + responseObject1);
				eventPublisher.publish(wrapper.success().add("Response", responseObject));
				eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.CALLTOSF)
						.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
			} catch (Exception e) {
				logger.info("Response from SF delete Alert  " + responseObject1);
				eventPublisher.publish(wrapper.error().add("Response", responseObject));
				eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.CALLTOSF));
			}finally{
				queueName=null;
				message=null;
				wrapper=null;
			}
		}else{
			logger.error("*****ERROR: sfEmxHeaderMapRepository OrgId not found in the table");
		}
		
	}
	@Override
	public void processMessage(String queueName, MessageType type, Object message) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * 
	 * @param type
	 * @param message
	 * @throws Exception
	 */
	@Override
	public void processMessage(String queueName, MessageType type, String message) {

		logger.info("Start ProcessEmxAlertMessage.processMessage");
		logger.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
		logger.debug(message);
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();

		try {

			switch (type) {

			case CREATE:
				create_Update_Alert(queueName, message, wrapper, "CREATE");
				break;
			case UPDATE:
				create_Update_Alert(queueName, message, wrapper, "UPDATE");
				break;
			case DELETE:
				deleteAlert(queueName, message, wrapper);
			case RESPONSE:
				 responseAlert(queueName, message, wrapper);
			default:
				break;
			}
		} catch (Exception e) {
			handlingExceptionMessages.processException(
					SourceSystem.EMONEY,
					new SendToExchangeException(e), 
					queueName,						
					message
					);
			eventPublisher.publish(
					wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));
			logger.error("Exception in ProcessEmxClientMessage.processMessage", e);
		}
		logger.info("End ProcessEmxClientMessage.processMessage");
	}
	/**
	 * 
	 * @param queueName
	 * @param message
	 * @param wrapper
	 */
	private void responseAlert(String queueName,  String message, AnalyticsEventWrapper wrapper) {
		// TODO Auto-generated method stub
		wrapper.processing(EnumEventCurrentStatus.RECEIVED);
		eventPublisher.publish(wrapper);
		logger.info("Inside Response Alert message :: "+message);
		
	}

	/**
	 * 
	 * @param name
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */

	private AnalyticsEventWrapper getEvent(String name) throws AnalyticsEventPublisherException {
		try {
			return analyticsEventUtil.getEvent(name);
		} catch (Exception e) {

			throw new AnalyticsEventPublisherException(
					"Exception in getEvent eventName[ " + name + "]" + e.getMessage());
		}

	}

}
