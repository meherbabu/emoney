package com.integration.emx.mqlistener;

import java.sql.Timestamp;

import org.apache.commons.logging.Log;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;
import com.integration.service.LoggerUtil;

@Component
public class EmxNoteMessageListener {

	Log logger = LoggerUtil.getLog(this);

	private ProcessMessage processMessage;

	Timestamp timestamp = null;


	@Autowired
	public EmxNoteMessageListener(@Qualifier("ProcessEmxNoteMessage") ProcessMessage processMessage) {
		this.processMessage = processMessage;
	}

	/**
	 * 
	 * @param message
	 */
	@RabbitListener(queues = "${mq.emx.note.create.queue}", concurrency = "${mq.emx.note.create.concurrency:1-1}")
	public void createListener(Message message){

		logger.info("Start EmxNoteMessageListener.updateListener");

		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.CREATE, new String(message.getBody()));

		logger.info("End EmxNoteMessageListener.updateListener");

	}

	/**
	 * 
	 * @param message
	 */
	@RabbitListener(queues = "${mq.emx.note.update.queue}", concurrency = "${mq.emx.note.update.concurrency:1-1}")
	public void updateListener(Message message) {

		logger.info("Start EmxNoteMessageListener.updateListener");

		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.UPDATE, new String(message.getBody()));

		logger.info("End EmxNoteMessageListener.updateListener");

	}
	
	
    @RabbitListener(queues = "${mq.emx.note.delete.queue}", concurrency = "${mq.emx.note.delete.concurrency:1-1}")
    public void deleteNote(Message message) {
 		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.DELETE, new String(message.getBody()));

    }
}
