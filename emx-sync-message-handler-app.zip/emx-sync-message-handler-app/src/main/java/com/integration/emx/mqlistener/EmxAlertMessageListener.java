/**
 * <h1>MessageListener : </h1>
 * The MessageListener program is a listener, which keeps listening to the RabbitMQ configured queue. 
 * When ever there is a message to process in the topic this service is get called by passing MemberID.


 * This class publishes the MemberID to configured Queue. -> T
 * <p>
 * Note : Logging and Exception handling is done by other components.
 * *
 *
 * @author Ldo
 * @version 1.0
 */
package com.integration.emx.mqlistener;

import org.apache.commons.logging.Log;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.service.LoggerUtil;

@Component
public class EmxAlertMessageListener {

	Log logger = LoggerUtil.getLog(this);
	

	ProcessMessage processMessage;

	@Autowired
	public EmxAlertMessageListener(@Qualifier("ProcessEmxAlertMessage") ProcessMessage processMessage) {
		this.processMessage = processMessage;
	}

	/**
	 * 
	 * @param requestObject
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	@RabbitListener(queues = "${mq.emx.alert.create.queue}", concurrency = "${mq.emx.alert.create.concurrency:1-1}")
	public void createListener(Message message) {
		logger.info("Start EmxAlertMessageListener.createListener");
		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.CREATE,
				new String(message.getBody()));
		logger.info("End EmxAlertMessageListener.createListener");
	}

	/**
	 * 
	 * @param message
	 */
	@RabbitListener(queues = "${mq.emx.alert.update.queue}", concurrency = "${mq.emx.alert.update.concurrency:1-1}")
	public void updateListener(Message message)
			throws DataProcessingException, DataPublishingException, AnalyticsEventPublisherException {
		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.UPDATE,
				new String(message.getBody()));
		logger.info("End EmxAlertMessageListener.updateListener");

	}

	@RabbitListener(queues = "${mq.emx.alert.delete.queue}", concurrency = "${mq.emx.alert.delete.concurrency:1-1}")
	public void deleteListener(Message message) {
		logger.info("Start EmxAlertMessageListener.deleteListener");
		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.DELETE,
				new String(message.getBody()));
		logger.info("End EmxAlertMessageListener.deleteListener");
	}

	@RabbitListener(queues = "${mq.emx.alert.response.queue}", concurrency = "${mq.emx.alert.response.concurrency:1-1}")
	public void responseListener(Message message) {
		logger.info("Start EmxAlertMessageListener.responseListener");

		processMessage.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.RESPONSE,
				new String(message.getBody()));
		logger.info("End EmxAlertMessageListener.responseListener");
	}

}
