package com.integration.emx.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxSFTaskPiiDataImpl;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;

@Service
@Qualifier ("ProcessEmxTaskMessage")
public class ProcessEmxTaskMessage implements ProcessMessage {



	Log logger = LogFactory.getLog(ProcessEmxTaskMessage.class);


	@Value("${saleforce.context.task.create}")
	private String taskCreateContext;

	@Value("${saleforce.context.task.update}")
	private String taskUpdateContext;

	@Value("${saleforce.context.task.delete}")
	private String taskDeleteContext;

	private HttpExchangeService httpExchangeService;

	private JsonUtility jsonUtil;

	private AccessTokenGenerator sFTokenUtil;

	private EmxToSfCommonUtil commonUtils;

	private AnalyticsEventUtil analyticsEventUtil;

	private AnalyticsEventPublisher eventPublisher;

	private HandlingExceptionMessages handlingExceptionMessages;
	
	private PiiDataLog piiDataLog; 

	/**
	 * 
	 * @param httpExchangeService
	 * @param jsonUtil
	 * @param sFTokenUtil
	 * @param commonUtils
	 * @param analyticsEventUtil
	 * @param eventPublisher
	 */
	@Autowired
	public ProcessEmxTaskMessage(HttpExchangeService httpExchangeService, JsonUtility jsonUtil,
			AccessTokenGenerator sFTokenUtil, EmxToSfCommonUtil commonUtils, AnalyticsEventUtil analyticsEventUtil,
			AnalyticsEventPublisher eventPublisher, HandlingExceptionMessages handlingExceptionMessages,
			EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl) {
		this.httpExchangeService = httpExchangeService;
		this.jsonUtil = jsonUtil;
		this.sFTokenUtil = sFTokenUtil;
		this.commonUtils = commonUtils;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.piiDataLog = emxSfTaskPiiDataImpl; 
	}

	/**
	 * 
	 * @param queueName
	 * @param message
	 * @param wrapper
	 * @throws DataPublishingException
	 * @throws SendToExchangeException
	 */
	private void createTask(String queueName, String message, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, SendToExchangeException {
		logger.info("Create Tasking Start..");
		EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl = (EmxSFTaskPiiDataImpl) piiDataLog;  
		try {
			// this array contain String[trackingID, office,clientId]
			String[] data = commonUtils.getEmxTaskInfoFromMessageQueue(message);
			// get Access Token
			Map<String, String> headers = sFTokenUtil.getSaleforceAccessTokenHeadersUsingEmoneyOffice(data[1]);
			String url = sFTokenUtil.getSaleforceUrlUsingEmoney(data[1]) + taskCreateContext;
			
			wrapper = getEvent("emx-task-create");
			// Initial event ;
			// this array contain String[trackingID, office,clientId]
			eventPublisher
					.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[2]).add("office", data[1]));
			List<Object[]> list = commonUtils.splitEmxTaskMessage(message);
		
			for (Object[] objects : list) {                            
				//new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer }
				wrapper = settingPII(message, wrapper, emxSfTaskPiiDataImpl, objects);
			 
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
				// send message to the exchange
				Object responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
						HttpMethod.PATCH, headers, message);

				logger.info("Sponse from SF Create task " + responseObject);
				eventPublisher
						.publish(wrapper.success(EnumEventCurrentStatus.CALLTOSF).add("Sponse from SF", responseObject));
				eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
				logger.info("Create Tasking End..");
			} 
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}

	}

	private AnalyticsEventWrapper settingPII(String message, AnalyticsEventWrapper wrapper,
			EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl, Object[] objects) throws DataValidationException {
		String clientId = String.valueOf(objects[0]);//eMoneyId				
		String eMoneyTaskIdTXT = String.valueOf(objects[1]);
		String assignedToTXT = String.valueOf(objects[2]);    ///Correction for variable value of assigned to 
		String taskId = String.valueOf(objects[4]);							
		String messageId = commonUtils.getEmoneyTaskMessageIdEmxClient(message);
		wrapper = wrapper.setClientIdValue(clientId);	
		wrapper = wrapper.setAdditionalPropertyValue("eMoneyTaskId",objects[1]) ;				
		wrapper = wrapper.setAdditionalPropertyValue("assignedTo", objects[2]); //Newly added
		if(messageId=="") {
			messageId=null;
		}
		emxSfTaskPiiDataImpl.setPiiData(taskId, null, clientId, eMoneyTaskIdTXT, messageId, assignedToTXT);
		return wrapper;
	}

	/**
	 * 
	 * @param queueName
	 * @param message
	 * @param wrapper
	 * @throws DataPublishingException
	 * @throws SendToExchangeException
	 */

	private void updateTask(String queueName, String message, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, SendToExchangeException {
		EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl = (EmxSFTaskPiiDataImpl) piiDataLog; //Newly added 
	
		try {
			// this array contain String[trackingID, office,clientId]
			String[] data = commonUtils.getEmxTaskInfoFromMessageQueue(message);
			// get Access Token
			Map<String, String> headers = sFTokenUtil.getSaleforceAccessTokenHeadersUsingEmoneyOffice(data[1]);
			String url = sFTokenUtil.getSaleforceUrlUsingEmoney(data[1]) + taskUpdateContext;
			wrapper = getEvent("emx-task-update");
			// Initial event ;
			eventPublisher
					.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[2]).add("office", data[1]));
			List<Object[]> list = commonUtils.splitEmxTaskMessage(message); //Newly added 
			//new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer }
			for (Object[] objects : list) {   
				wrapper = settingPII(message, wrapper, emxSfTaskPiiDataImpl, objects);
				
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
				Object responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
						HttpMethod.PATCH, headers, message);
				logger.info("Sponse from SF Update task " + responseObject);
				// write success event for queue
				eventPublisher
						.publish(wrapper.success(EnumEventCurrentStatus.CALLTOSF).add("Sponse from SF", responseObject));
				eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.TRANSFORMING));		 
			} 
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}
	}

	/**
	 * 
	 * @param queueName
	 * @param message
	 * @param wrapper
	 * @throws DataPublishingException
	 * @throws SendToExchangeException
	 */
	private void deleteTask(String queueName, String message, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, SendToExchangeException {
		EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl = (EmxSFTaskPiiDataImpl) piiDataLog;//Newly added 
		try {
			//new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer }
			wrapper = getEvent("emx-task-delete");
			Map<String, Object> mapping = jsonUtil.getMapFromJsonString(message);
			String office = String.valueOf(mapping.get("office"));
			String eMoneyTaskId = String.valueOf(mapping.get("eMoneyTaskId"));
			String trackingId = String.valueOf(mapping.get("trackingId"));
			Map<String, String> headers = sFTokenUtil.getSaleforceAccessTokenHeadersUsingEmoneyOffice(office);
			String url = sFTokenUtil.getSaleforceUrlUsingEmoney(office) + taskDeleteContext;
			//PII Data
			emxSfTaskPiiDataImpl.setPiiData(null, null, null, eMoneyTaskId, null, null);
			 
			// Initial event ;
			eventPublisher.publish(wrapper.setTrackingIdValue(trackingId).add("office", office).add("eMoneyTaskId", eMoneyTaskId));
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
			// Send message to Sale Force
			Object responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
					HttpMethod.DELETE, headers, null, mapping);
			logger.info("Sponse from SF Delete task " + responseObject);
		
			
			eventPublisher
					.publish(wrapper.success(EnumEventCurrentStatus.CALLTOSF).add("Sponse from SF", responseObject));
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.TRANSFORMING)
					.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}
	}

	/**
	 *
	 * @param type
	 * @param message
	 * @throws Exception
	 */
	@Override
	@Transactional
	public void processMessage(String queueName, MessageType type, String message)  {
		//new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer }
		
		logger.info("Start ProcessEmxMessageImpl.processMessage");
		logger.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
		logger.debug(message);
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
		try {
			switch (type) {
			case CREATE:
				createTask(queueName, message, wrapper);						
				break;
			case UPDATE:
				updateTask(queueName, message, wrapper);				
				break;
			case DELETE:
				deleteTask(queueName, message, wrapper);				
				break;
			default:
				break;
			}
		} catch (SendToExchangeException e) {
			logger.error("Exception in ProcessEmxMessageImpl.processMessage" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
		} catch (Exception e) {
			logger.error("Exception in ProcessEmxMessageImpl.processMessage" + piiDataLog.logPiiData(), e); //Moved before handling exception step
			handlingExceptionMessages.processException(SourceSystem.EMONEY, new SendToExchangeException(e),
					queueName, message);

			eventPublisher.publish(wrapper.error(EnumEventCurrentStatus.TRANSFORMING));
			
		}
		logger.info("End ProcessEmxMessageImpl.processMessage" + piiDataLog.logPiiData());
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */
	private AnalyticsEventWrapper getEvent(String name) throws AnalyticsEventPublisherException {
		try {
			return analyticsEventUtil.getEvent(name);
		} catch (Exception e) {

			throw new AnalyticsEventPublisherException(
					"Exception in getEvent eventName[ " + name + "]" + e.getMessage());
		}

	}
	
	@Override
	public void processMessage(String queueName, MessageType type, Object message) {
		// TODO Auto-generated method stub
		
	}

}
