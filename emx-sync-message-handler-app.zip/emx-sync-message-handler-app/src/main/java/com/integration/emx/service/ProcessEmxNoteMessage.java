package com.integration.emx.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxSfNotesPiiDataImpl;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;

@Service
@Qualifier ("ProcessEmxNoteMessage")
public class ProcessEmxNoteMessage implements ProcessMessage {

	Log logger = LoggerUtil.getLog(this);

	@Value("${saleforce.context.note.create}")
	private String noteCreateContext;

	@Value("${saleforce.context.note.update}")
	private String noteUpdateContext;

	@Value("${saleforce.context.note.delete}")
	private String notedeleteContext;

	private HttpExchangeService httpExchangeService;

	private AccessTokenGenerator sFTokenUtil;

	private EmxToSfCommonUtil commonUtils;

	private AnalyticsEventUtil analyticsEventUtil;

	private AnalyticsEventPublisher eventPublisher;
	
	private HandlingExceptionMessages handlingExceptionMessages;
	
	private JsonUtility jsonUtility;
	
	private PiiDataLog piiDataLog;

	/**
	 * 
	 * @param postMessageToSfController
	 * @param sFTokenUtil
	 */
	@Autowired
	public ProcessEmxNoteMessage(HttpExchangeService postMessageToSfController, AccessTokenGenerator sFTokenUtil,
			EmxToSfCommonUtil commonUtils, AnalyticsEventUtil analyticsEventUtil,
			AnalyticsEventPublisher eventPublisher,
			HandlingExceptionMessages handlingExceptionMessages,
			JsonUtility jsonUtility,EmxSfNotesPiiDataImpl emxSfNotesPiiDataImpl) {
		this.httpExchangeService = postMessageToSfController;
		this.sFTokenUtil = sFTokenUtil;
		this.commonUtils = commonUtils;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.jsonUtility = jsonUtility;
		this.piiDataLog = emxSfNotesPiiDataImpl ; 
	}

	/**
	 * 
	 * @param type
	 * @param message
	 * @throws Exception
	 */
	@Override
	public void processMessage(String queueName, MessageType type, String message) {

		logger.info("Start ProcessEmxNoteMessage.processMessage");
		logger.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
		logger.debug(message);
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();

		try {
			String url = "";
			String[] data = null;
			Map<String, String> headers = null;
			Object responseObject = null;
			List<Object[]> objectArray = null;
			EmxSfNotesPiiDataImpl emxSfNotesPiiDataImpl = (EmxSfNotesPiiDataImpl) piiDataLog;
			if (type == MessageType.CREATE || type == MessageType.UPDATE) {
				// this array contain String[trackingID, office,"clientId","noteId"]
				data = commonUtils.getEmxNoteInfoFromMessageQueue(message);
				// get Access Token
				headers = sFTokenUtil.getSaleforceAccessTokenHeadersUsingEmoneyOffice(data[1]);
			}

			switch (type) {

			case CREATE:
				url = sFTokenUtil.getSaleforceUrlUsingEmoney(data[1]) + noteCreateContext;
				wrapper = getEvent("emx-note-create");
				eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[2])
						.setNoteIdValue(data[3]).add("office", data[1]));

				// TransformMessages
				objectArray = commonUtils.transformNoteUpdateMessage(message);
				for (Object[] objects : objectArray) {
					eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
					//String emoneyid = String.valueOf(data[2]).toString();         //Newly added  //Change
					//String emoneynoteid = String.valueOf(data[3]).toString();  //Newly added 
					String emoneyid = commonUtils.getNoteEmoneyIDEmxClient(message) ;      //Newly added  //Change
					String emoneynoteid = commonUtils.getNoteEmoneyNoteIDEmxClient(message)  ; 
					emxSfNotesPiiDataImpl.setPiiData(emoneyid,emoneynoteid);             //Newly added 
				    logger.info(piiDataLog.logPiiData());  //Newly added  Call info logpiidata
					responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
							HttpMethod.PATCH, headers, objects[1].toString());
//					responseObject = httpExchangeService.sendToExchange(url, HttpMethod.PATCH, headers,
//							objects[1].toString());

					logger.info("SF Create Note  " + responseObject);
					eventPublisher.publish(wrapper.success());
					eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
				}
				break;
			case UPDATE:
				url = sFTokenUtil.getSaleforceUrlUsingEmoney(data[1]) + noteUpdateContext;

				wrapper = getEvent("emx-note-update");
				eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[2])
						.setNoteIdValue(data[3]).add("office", data[1]));

				// TransformMessages
				objectArray = commonUtils.transformNoteUpdateMessage(message);
				for (Object[] objects : objectArray) {
					eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
					String emoneyid = commonUtils.getNoteEmoneyIDEmxClient(message);          //Newly added 
					String emoneynoteid = commonUtils.getNoteEmoneyNoteIDEmxClient(message);  //Newly added 
					emxSfNotesPiiDataImpl.setPiiData(emoneyid,emoneynoteid);             //Newly added  
					
					responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
								HttpMethod.PATCH, headers, objects[1].toString());
					logger.info("SF Update Note  " + responseObject);
					eventPublisher.publish(wrapper.success());
					eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.TRANSFORMING).add("response from SF",
							responseObject));
				}
				break;
			case DELETE:				
				wrapper = getEvent("emx-note-delete");
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
			    
				Map<String, Object> map = jsonUtility.getMapFromJsonString(message);
				headers = sFTokenUtil.getSaleforceAccessTokenHeadersUsingEmoneyOffice(String.valueOf(map.get("office")));
				String officeId = String.valueOf(map.get("office"));
				String eMoneyId = String.valueOf(map.get("eMoneyId"));
				String eMoneyNoteId = String.valueOf(map.get("eMoneyNoteId"));
				//PII Data 
				emxSfNotesPiiDataImpl.setPiiData(eMoneyId,eMoneyNoteId);  
				
				url = sFTokenUtil.getSaleforceUrlUsingEmoney(officeId) + notedeleteContext;
				responseObject = httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url,
							HttpMethod.DELETE, headers, null,map);
				eventPublisher.publish(wrapper.success().add("Response Message", responseObject));
				
				break;
			default:
				break;
			}
		}  
		catch (SendToExchangeException e) {
			logger.error("Exception in ProcessEmxNoteMessage.processMessage" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
		}catch (Exception e) {
			logger.error("Exception in ProcessEmxNoteMessage.processMessage" + piiDataLog.logPiiData(), e);
			handlingExceptionMessages.processException(
					SourceSystem.EMONEY,
					new SendToExchangeException(e), 
					queueName,						
					message
					);

			eventPublisher.publish(
					wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));
		
		}
		logger.info("End ProcessEmxNoteMessage.processMessage");
	}

	/**
	 * 
	 * @param name
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */

	private AnalyticsEventWrapper getEvent(String name) throws AnalyticsEventPublisherException {
		try {
			return analyticsEventUtil.getEvent(name);
		} catch (Exception e) {

			throw new AnalyticsEventPublisherException(
					"Exception in getEvent eventName[ " + name + "]" + e.getMessage());
		}

	}
	@Override
	public void processMessage(String queueName, MessageType type, Object message) {
		// TODO Auto-generated method stub
		
	}

}
