package com.integration.sf.mqlistener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;

@Component
public class SfAlertMessageListener {

    private static final Logger logger = LoggerFactory.getLogger(SfAlertMessageListener.class);
   
	private ProcessMessage alertProcessorService;
	
	public SfAlertMessageListener(@Qualifier("SfAlertDismissServiceImpl") ProcessMessage alertProcessorService) {
		this.alertProcessorService = alertProcessorService;
	}

    @RabbitListener(queues = "${mq.sf.alert.update.queue}", concurrency = "${mq.sf.alert.update.concurrency:1-1}" )
	public void updateAlert(Message message) {
    	logger.info("****Payload received from AMQ for Dismiss Alert: "+message);
		this.alertProcessorService.processMessage(
				message.getMessageProperties().getConsumerQueue(), MessageType.UPDATE,
				new String(message.getBody()));
		 logger.info("**** End of the SfAlertMessageListener.sf.alert.update ****");
	}

}

