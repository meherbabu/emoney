package com.integration.sf.mqlistener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;

@Component
public class SfClientMessageListener  {

    private static final Logger logger = LoggerFactory.getLogger(SfClientMessageListener.class);

    private ProcessMessage eventProcessorService;
    
     
    @Autowired
    public SfClientMessageListener(@Qualifier("SFEmxClientProcessorServiceImpl") ProcessMessage eventProcessorService) {
        this.eventProcessorService = eventProcessorService;
    }

    /**
     *
     * @param message
     */
    @RabbitListener(queues = "${mq.sf.client.create.queue}" , concurrency = "${mq.sf.client.create.concurrency:1-1}" )
    public void receiveCreateClientMessage(Message message){    	
		logger.info("*********** Payload Received from CREATE QUEUE  **************");
		eventProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.CREATE,
				new String(message.getBody()));
		logger.info("********** END OF Payload CreateClient LIFE CYCLE *************");		
    }

    /**
     *
     * @param message
     */
    @RabbitListener(queues = "${mq.sf.client.update.queue}" , concurrency = "${mq.sf.client.update.concurrency:1-1}" )
    public void receiveUpdateClientMessage(Message message) {    
		eventProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.UPDATE,
				new String(message.getBody()));
        logger.info("*********** END OF Payload UpdateClient LIFE CYCLE ***************");    	
   }
    
    /***
     * @throws DataProcessingException
     * @throws DataPublishingException
     * @throws AnalyticsEventPublisherException 
     */
    @RabbitListener(queues = "${mq.sf.client.delete.queue}", concurrency = "${mq.sf.client.delete.concurrency:1-1}"  )
    public void receiveDeleteClientMessage(Message message){
		eventProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.DELETE,
				new String(message.getBody()));
       logger.info("*********** END OF Payload DELETE Client LIFE CYCLE ***************");
  
    }

    /**
     * @throws DataPublishingException
     * @throws AnalyticsEventPublisherException 
     */
    @RabbitListener(queues = "${mq.sf.client.response.queue}" , concurrency = "${mq.sf.client.response.concurrency:1-1}" )
    public void receiveResponseClientMessage(Message message){
		eventProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.RESPONSE,
				new String(message.getBody()));
        logger.info("******** END OF Payload ResponseClient LIFE CYCLE **************");
    }
}
