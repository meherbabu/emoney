package com.integration.sf.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.Advisors;
import com.integration.bean.emx.AdvisorsWrapper;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;

@Service
@Qualifier("AdvisorsService")
public class AdvisorsService implements ProcessMessage {


    Log logger = LoggerUtil.getLog(this);
    
    @Value("${mq.emx.advisors.response.exchange}")
    private String advisorExchange;
    @Value("${mq.emx.advisors.response.routingkey}")
    private String routingkey;
    @Value("${mq.emx.advisors.response.persistence : false}")
    private boolean isPersistent;
    @Value("${emoney.url}")
    private String eMoneyurl;
    @Value("${emoney.context.advisors.get}")
    private String context;

    
    private AnalyticsEventUtil analyticsEventUtil;
    
    private AnalyticsEventPublisher eventPublisher;
    
    private JsonUtility jsonUtility;
    
    private HandlingExceptionMessages handlingExceptionMessages;
    
    private AccessTokenGenerator accessTokenGenerator;
    
    private HttpExchangeService httpExchangeService;
    
    private MessageSender messageSender;
    
    private SforgEmxoffMapRepository sforgEmxoffMapRepository;

    
    
    @Autowired
    public AdvisorsService(AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher,
			JsonUtility jsonUtility, HandlingExceptionMessages handlingExceptionMessages,
			AccessTokenGenerator accessTokenGenerator, HttpExchangeService httpExchangeService,
			MessageSender messageSender, SforgEmxoffMapRepository sforgEmxoffMapRepository) {
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.jsonUtility = jsonUtility;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.accessTokenGenerator = accessTokenGenerator;
		this.httpExchangeService = httpExchangeService;
		this.messageSender = messageSender;
		this.sforgEmxoffMapRepository = sforgEmxoffMapRepository;
	}

	@Override
    @Transactional
    public void processMessage(String queueName, MessageType type, String message) {
        logger.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
        logger.debug(message);
        AnalyticsEventWrapper wrapper = null;
        try {

            switch (type) {
                case GET:
                    wrapper = analyticsEventUtil.getEvent("sf-advisor-get");
                    getAllAdvisors(queueName, message, wrapper);
                    break;
                    //posting response
                default:
                    break;
            }
        } catch (SendToExchangeException e) {
            // catch here but doing nothing. message is already logged.
        } catch (Exception e) {


                handlingExceptionMessages.processException(SourceSystem.EMONEY, new SendToExchangeException(e),
                        queueName, message);
                eventPublisher.publish(wrapper.error(EnumEventCurrentStatus.TRANSFORMING));
            logger.error("Exception in Process Advisors request to eMoney", e);
        }
        logger.info("End of the Advisors Services");
    }

    private void getAllAdvisors(String queueName, String message, AnalyticsEventWrapper wrapper)
            throws DataPublishingException, SendToExchangeException {
        try {

           Advisors advisors = new Advisors();
            Map<String, Object> mapping = jsonUtility.getMapFromJsonString(message);
            String orgId = String.valueOf(mapping.get("orgId"));
            String trackingId = String.valueOf(mapping.get("trackingId"));
            //querying db to fetch all offices associated with orgId
            List<String> offices = sforgEmxoffMapRepository.findActiveEmxOfficesByOrgId(orgId);
            for (String office : offices) {
                logger.info("*******eMoney office for sf orgId********" + office);
                //todo wiped out token with lee Token service
               String url = eMoneyurl + context;
               Map<String, String> headers  =accessTokenGenerator.getEmoneyAccessAdminTokenHeaders(office);
                logger.debug("****headers****" +headers);
                eventPublisher.publish(wrapper.setTrackingIdValue(trackingId));
                eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOEMX));
                // Send message to eMoney
               Object response =  httpExchangeService.sendToExchange(SourceSystem.SALESFORCE, queueName, url,
                        HttpMethod.GET, headers, null);


               advisors= (Advisors) jsonUtility.getObjectFromJsonString(String.valueOf((response)),
                        Advisors.class);

                logger.info("Response from eMoney Service for the Advisors" +advisors);
                AdvisorsWrapper wrapper1 = new AdvisorsWrapper();
                wrapper1.setAdvisors(advisors);
                wrapper1.setOrgId(orgId);
                wrapper1.setSfOffice(office);
                wrapper1.setTrackingId(trackingId);

                String json = new ObjectMapper().writeValueAsString(wrapper1);
                logger.debug("*** Json string  response " + json);
                eventPublisher
                        .publish(wrapper.success(EnumEventCurrentStatus.CALLTOEMX));
                eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.TRANSFORMING)
                        .setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
                messageSender.send(advisorExchange, routingkey, isPersistent, json);
            }
            } catch(SendToExchangeException e){
                throw e;
            } catch(Exception e){
                throw new DataPublishingException(e);
            }
        }


    @Override
    public void processMessage(String queueName, MessageType type, Object message) {

    }


}
