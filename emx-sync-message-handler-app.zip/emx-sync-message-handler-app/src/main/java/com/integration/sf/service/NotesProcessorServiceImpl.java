package com.integration.sf.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventSourceNDestination;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxNote;
import com.integration.bean.emx.EmxNotesResponse;
import com.integration.bean.sf.Acknowledgement;
import com.integration.bean.sf.NotesRequest;
import com.integration.bean.sf.SfEmxNotesPiiDataImpl;
import com.integration.bean.sf.SfNote;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.dao.SfEmxHeaderMapRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.SfToEmxCommonUtil;
import com.integration.transformation.modal.SFToEMoneyNotesRequest;


@Service
@Qualifier ("NotesProcessorServiceImpl")
public class NotesProcessorServiceImpl  implements ProcessMessage {
	Log log = LoggerUtil.getLog(this);

    @Value("${mq.emx.note.response.exchange}")
    private String notesExchange;
    
    @Value("${mq.emx.note.response.routingkey}")
    private String notesRoutingkey;
    
    @Value("${mq.emx.note.response.persistence}")
    private boolean isPersistent;    

    @Value("${saleforce.url}")
    private String sfServiceUrl;
    
    @Value("${saleforce.context.note.response}")
    private String sfNoteResponseContext;
    
    @Value("${saleforce.context.note.delete}")
    private String sfNoteDeleteContext;
 
    @Value("${emoney.url}")
    private String emoneyserviceurl;
    
    @Value("${emoney.context.note.create}")
    private String createNoteContext;
    
    @Value("${emoney.context.note.delete}")
    private String deleteNoteContext;
    
    
	@Value("${emoney.url}")
	private String eMoneyUrl;


	@Value("${emoney.context.note.update}")
	private String noteUpdateContext;
	
	
    private SFToEMoneyNotesRequest sfToEMoneyNotesRequest;
       
    private MessageSender messageSender;
    
    private AnalyticsEventPublisher eventPublisher;
    
    private AccessTokenGenerator accessTokenHeaderGenerator;
    
    private SfEmxHeaderMapRepository repository;
    
    private AccessTokenGenerator sFTokenUtil;
    
    private JsonUtility jsonUtility;
    
    private HandlingExceptionMessages handlingExceptionMessages;
    
    private HttpExchangeService httpExchangeService;
    
	private AnalyticsEventUtil analyticsEventUtil;

	private SfToEmxCommonUtil commonUtils;
	
	private PiiDataLog piiDataLog; 

    @Autowired    
    public NotesProcessorServiceImpl(SFToEMoneyNotesRequest sfToEMoneyNotesRequest,
			MessageSender messageSender,
			AnalyticsEventPublisher analyticsEventPublisher, AccessTokenGenerator accessTokenHeaderGenerator,
			 SfEmxHeaderMapRepository repository, AccessTokenGenerator sFTokenUtil,
			 JsonUtility jsonUtility,
			 HandlingExceptionMessages handlingExceptionMessages,
			 HttpExchangeService httpExchangeService,
			 AnalyticsEventUtil analyticsEventUtil,
			 SfToEmxCommonUtil commonUtils, SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl) {
		this.sfToEMoneyNotesRequest = sfToEMoneyNotesRequest;
		this.messageSender = messageSender;
		this.eventPublisher = analyticsEventPublisher;
		this.accessTokenHeaderGenerator = accessTokenHeaderGenerator;
		this.repository = repository;
		this.sFTokenUtil = sFTokenUtil;
		this.jsonUtility = jsonUtility;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.httpExchangeService = httpExchangeService;
		this.analyticsEventUtil = analyticsEventUtil;
		this.commonUtils = commonUtils;
		this.piiDataLog = sfEmxNotesPiiDataImpl;
	}
    
    @Override
    public void processMessage(String queueName, MessageType messageType, String message) {
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
    	try {
			if ( messageType == MessageType.CREATE)
			{
				wrapper = getEvent("sf-note-create");
				NotesRequest notesRequest = (NotesRequest)jsonUtility.getObjectFromJsonString(message, NotesRequest.class);
				create (queueName, notesRequest,messageType ,wrapper);
				//SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
	        	//sfEmxNotesPiiDataImpl.setPiiData(null,null,null); //Newly added
				return;
			}
			if ( messageType == MessageType.UPDATE)
			{
				wrapper = getEvent("sf-note-update");
				update (queueName, message,messageType ,wrapper);
				return;
			}
			if ( messageType == MessageType.DELETE)
			{
				wrapper = getEvent("sf-note-delete");
				Map<String, Object> map = jsonUtility.getMapFromJsonString(message);
				deleteNotes(queueName, map, messageType, wrapper) ;//(queueName, (NotesRequest) message,messageType ,wrapper);
				return;
			}
			if ( messageType == MessageType.RESPONSE)
			{
				wrapper = getEvent("emx-note-response-create");
				EmxNotesResponse emxNotesResponse = (EmxNotesResponse)jsonUtility.getObjectFromJsonString(message, EmxNotesResponse.class);
				notesResponse( queueName ,emxNotesResponse, wrapper);
				//deleteNotes(queueName, (Map<String, String>)message, messageType, wrapper) ;//(queueName, (NotesRequest) message,messageType ,wrapper);
				return;
			}
		} catch (SendToExchangeException e) {
			 log.error("Exception in NotesProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e);
			 eventPublisher.publish(wrapper.error().add("Error message ", e.getCause().getMessage()));		
		} catch (Exception e) {
			log.error("Exception in NotesProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e);
			try {
				handlingExceptionMessages.processException(
						SourceSystem.EMONEY,
						new SendToExchangeException(e), 
						queueName,						
						message
						);
				eventPublisher.publish(
						wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}// eof catch
    	
    }// eof of method
    
    
    
    
    @Override
    public void processMessage(String queueName, MessageType type, Object message) {
    	// TODO Auto-generated method stub
    	
    }

	/**
	 *
	 * @param queueName
	 * @param message
	 * @param operationType
	 * @param wrapper
	 * @throws DataPublishingException
	 * @throws SendToExchangeException
	 */
    private void update(String queueName , String message, MessageType operationType,AnalyticsEventWrapper wrapper) throws DataPublishingException, SendToExchangeException  {
 
    
    try {
    	
    	SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
    	String[] data = commonUtils.getSfNoteInfoFromMessageQueue(message, MessageType.UPDATE);
    	
    	sfEmxNotesPiiDataImpl.setPiiData( String.valueOf(data[3]),String.valueOf(data[4]),String.valueOf(data[5])); //Newlyadded
    	
		// get Access Token
    	Map<String, String> headers = sFTokenUtil.getEmoneyAccessTokenHeaders(data[2]);

		String url = eMoneyUrl + noteUpdateContext;
		eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[3])
				.setDestinationValue(EnumEventSourceNDestination.EMX).setNoteIdValue(data[4])
				.add("orgId", data[1]).add("SfNoteId", data[4]));

		// TransformMessages
		List<Object[]> objectArray = commonUtils.transformNoteUpdateMessage(message);
		// received as objectArray ["orgId","office","clientId","noteId",sfNoteId,"Split
		// message by Note"]
		for (Object[] objects : objectArray) {
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOEMX));

			String clientId = objects[2].toString();
			String noteId = objects[3].toString();
            String sfNoteId = objects[4].toString();
			Map<String, Object> uriParamValue = new HashMap<>();
			uriParamValue.put("eMoneyId", clientId);//changes from clientId to eMoneyId
			uriParamValue.put("noteId", noteId);
			
			sfEmxNotesPiiDataImpl.setPiiData( clientId,noteId,sfNoteId); //Newlyadded
			
			String responseObject = (String) httpExchangeService.sendToExchange(SourceSystem.SALESFORCE, queueName, url,
					HttpMethod.PUT, headers, objects[5].toString(), uriParamValue);
			eventPublisher.publish(wrapper.processing());
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.TRANSFORMING));

			if (responseObject == null) {
				throw new DataPublishingException("responseObject is empty");
			}

			log.info("EMX Update Note Response " + responseObject);
			EmxNotesResponse eMoney = new EmxNotesResponse();

			eMoney = (EmxNotesResponse) jsonUtility.getObjectFromJsonString(responseObject,
					EmxNotesResponse.class);
			eMoney.setSfNoteId(data[5]);
			eMoney.setOrgId(data[1]);
			eventPublisher.publish(wrapper.processing());
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.SENDING_FOR_ACK));

			messageSender.send(notesExchange, notesRoutingkey, isPersistent,
					jsonUtility.getJsonStringFromObject(eMoney));
			// messageSender.send(responseExchange, responseRoutingkey, eMoney);
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.SENDING_FOR_ACK));

			log.info("******sending create notes response to AMQ*****" + responseObject);

		}//eof for loop		
		} catch (SendToExchangeException e) {
				throw e;
		} catch (Exception e) {
				throw new DataPublishingException(e);
		} 
    } 	     
    /**
     * 
     * @param queueName
     * @param eMoneyNote
     * @param operationType
     * @throws DataPublishingException
     * @throws SendToExchangeException
     */
    private void create(String queueName , NotesRequest eMoneyNote, MessageType operationType,AnalyticsEventWrapper event) throws DataPublishingException, SendToExchangeException  {
        log.info("****creating notes request and splitting****");
      
		try {
			// preset to UPDATE.  Change of value is CREATE 
			SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
			event.processing(EnumEventCurrentStatus.RECEIVED);

			event.setTrackingId(eMoneyNote.getTrackingID());
			event.setClientId(eMoneyNote.getNotes().getSfNote().geteMoneyId());
			sfEmxNotesPiiDataImpl.setPiiData(
					eMoneyNote.getNotes().getSfNote().geteMoneyId(), 
					null, 
					eMoneyNote.getNotes().getSfNote().getNoteId()); //Newly Added
			eventPublisher.publish(event);

			 Map<String, String> headers = accessTokenHeaderGenerator
					.getEmoneyAccessTokenHeaders(eMoneyNote.getNotes().getMetadata().getOffice());
			headers.forEach((s, s2) -> log.info("***Key***" + s + "***Value***" + s2));

			log.info("*****splitting notes and transforming SFNote to eMoneyNote request****" + eMoneyNote);
			SfNote sfNote = eMoneyNote.getNotes().getSfNote();
			log.info("******sf object******" + sfNote);
			
			event.processing(EnumEventCurrentStatus.TRANSFORMING);
			eventPublisher.publish(event);
			EmxNote eMoneyNote1;
		
			eMoneyNote1 = transformSFToEmX(sfNote);
			event.success(EnumEventCurrentStatus.TRANSFORMING);
			eventPublisher.publish(event);
			
			if (operationType == MessageType.CREATE) {
				
				event.processing(EnumEventCurrentStatus.CALLTOEMX);
				eventPublisher.publish(event);
				
				headers = accessTokenHeaderGenerator
						.getEmoneyAccessTokenHeaders(eMoneyNote.getNotes().getMetadata().getOffice());
				headers.forEach((s, s2) -> log.info("***Key***" + s + "***Value***" + s2));
				
				String url = emoneyserviceurl+createNoteContext;				
		        Map<String, Object> params = new HashMap<>();
		        params.put("eMoneyId", sfNote.geteMoneyId());
	
		
		        Object response = httpExchangeService.sendToExchange(
										SourceSystem.SALESFORCE, 
										queueName, 
										url, 
										HttpMethod.POST, 
										headers, 
										jsonUtility.getJsonStringFromObject(eMoneyNote1),
										params);
		        
				if ( StringUtils.isEmpty(response ))
				{
					throw new DataPublishingException (" response from Emoney is empty");
				}
				
				event.success(EnumEventCurrentStatus.CALLTOEMX);

				eventPublisher.publish(event);
				
				
				EmxNotesResponse eMoney = (EmxNotesResponse) jsonUtility.getObjectFromJsonString(String.valueOf(response),
						EmxNotesResponse.class);
				eMoney.setSfNoteId(eMoneyNote.getNotes().getSfNote().getNoteId());
				eMoney.setOrgId(eMoneyNote.getNotes().getMetadata().getOrgId());

				event.success(EnumEventCurrentStatus.RECEIVED);
				eventPublisher.publish(event);

				event.processing(EnumEventCurrentStatus.PUSHED_RMQ);
				eventPublisher.publish(event);

				log.info("****Publishing Success Response to AMQ:NOtesProcessImpl.upcert**** ");
				messageSender.send(notesExchange, notesRoutingkey, isPersistent, jsonUtility.getJsonStringFromObject(eMoney));

				event.success(EnumEventCurrentStatus.PUSHED_RMQ);
				eventPublisher.publish(event);

				log.info("****succesfully sent response to AMQ****");
				log.info("******sending create notes response to AMQ*****" + response);
				
		
			}
		}
		catch (SendToExchangeException e)
		{
			throw e;
		}
		catch (Exception e) {
			throw new DataPublishingException(e);
		}
    }
	/**
	 * 
	 * @param queueName
	 * @param params
	 * @param operation
	 * @throws DataPublishingException
	 * @throws SendToExchangeException
	 */
    private void deleteNotes(String queueName ,Map<String, Object> params, MessageType operation,AnalyticsEventWrapper event) throws DataPublishingException, SendToExchangeException  {
    	try {
    		//PII DATA
    		SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 		
			String clientId  = String.valueOf(params.get("clientId"));
			String eMoneyNoteId  = String.valueOf(params.get("noteId"));
			String office  = String.valueOf(params.get("office"));
			String orgId  = String.valueOf(params.get("orgId"));
			String trackingId = String.valueOf(params.get("trackingId"));			
			sfEmxNotesPiiDataImpl.setPiiData(clientId, eMoneyNoteId, null); 
			
			String url = emoneyserviceurl + deleteNoteContext;
			Map<String, String> headers = accessTokenHeaderGenerator.getEmoneyAccessTokenHeaders(String.valueOf(params.get("office")));
			event.processing(EnumEventCurrentStatus.CALLTOEMX).setTrackingIdValue(trackingId);			
			eventPublisher.publish(event);
	          
			Object response = httpExchangeService.sendToExchange(
										SourceSystem.SALESFORCE, 
										queueName, 
										url, 
										HttpMethod.DELETE, 
										headers, 
										null,
										params);
			    
			event.success();			
	
			    
		}catch (SendToExchangeException e){
			event.error();			
			throw e;
		}catch (Exception e) {			
			event.error();			
			throw new DataPublishingException(e);
		}    
    }

    /**
     * @param queueName
     * @param emxNotesResponse
     * @throws DataPublishingException
     * @throws SendToExchangeException
     */
    private void notesResponse(String queueName ,EmxNotesResponse emxNotesResponse,AnalyticsEventWrapper event) throws DataPublishingException, SendToExchangeException {
        try {
            Map<String,Object> paramsValues = new HashMap<String,Object>();
            String id = emxNotesResponse.getSfNoteId();
            SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog;             
            sfEmxNotesPiiDataImpl.setPiiData(
					null, 
					id, 
					null);      
            
            //query db for sfEntity
            String entity = repository.findSfEntity(emxNotesResponse.getOrgId(), "note");
            paramsValues.put("entity", entity);
            paramsValues.put("id", id);

            
            //making url for acknowledgement
            Map<String, String> headers = sFTokenUtil.getSaleforceAccessTokenHeaders(emxNotesResponse.getOrgId());
            String url = sFTokenUtil.getSaleforceUrl(emxNotesResponse.getOrgId()) + sfNoteResponseContext;
            //url = url + sfNoteResponseContext ;//+ sfEntity + "/" + Id;
            
            log.info("****Url for Note Acknowledgment for SF***" + url);
            log.info("SF_entity value fetching from DB" + entity);
            
            event.processing(EnumEventCurrentStatus.CALLTOSF);           
            eventPublisher.publish(event);
            
            Acknowledgement acknowledgement = new Acknowledgement();
            acknowledgement.seteMoney_Id__c(emxNotesResponse.getId());
            log.info("****Ackowledgment PayLoad for Note****" + acknowledgement);
    
 
			Object response = httpExchangeService.sendToExchange(
					SourceSystem.EMONEY, 
					queueName, 
					url, 
					HttpMethod.PATCH, 
					headers, 
					jsonUtility.getJsonStringFromObject(acknowledgement),
					paramsValues);
           
             log.info("****** Sucessfully sent NOTE Acknowledgment to SF******* ");
            eventPublisher.publish(event.success());
        }  
        catch (SendToExchangeException e)
		{
			throw e;
		}
		catch (Exception e) {
			throw new DataPublishingException(e);
		}    
    }
    /**
     * 
     * @param sfNote
     * @return
     * @throws IOException
     * @throws DataPublishingException
     * @throws DataProcessingException
     */
    private EmxNote transformSFToEmX(SfNote sfNote) throws IOException, DataPublishingException, DataProcessingException {

       EmxNote  emxNote1 = sfToEMoneyNotesRequest.transformSFToEMXNotes(sfNote);
      return emxNote1;

    }
    
    
    
	/**
	 * 
	 * @param name
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */

	private AnalyticsEventWrapper getEvent(String name) throws AnalyticsEventPublisherException {
		try {
			return analyticsEventUtil.getEvent(name);
		} catch (Exception e) {

			throw new AnalyticsEventPublisherException(
					"Exception in getEvent eventName[ " + name + "]" + e.getMessage());
		}

	}


}
