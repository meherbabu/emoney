package com.integration.sf.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.SourceSystem;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;

@Service
@Qualifier("SfAlertDismissServiceImpl")
public class SfAlertDismissService implements ProcessMessage{

    Logger log = LoggerFactory.getLogger(SfAlertDismissService.class);
    
    @Value("${emoney.url}")
    private String emoneyserviceurl;
    @Value(("${emoney.context.alert.update}"))
    private String alertUpdate;

    Map<String, String> headers = new HashMap<>();
  
    private AccessTokenGenerator sFTokenUtil;    
    private AnalyticsEventPublisher analyticsEventPublisher;   
    private HandlingExceptionMessages handlingExceptionMessages;  
    private HttpExchangeService httpExchangeService ;  
    private AnalyticsEventUtil analyticsEventUtil;  
    private JsonUtility jsonUtility;

	@Autowired
    public SfAlertDismissService(			
			AccessTokenGenerator sFTokenUtil,
			AnalyticsEventPublisher analyticsEventPublisher, JsonUtility jsonUtility,
			HttpExchangeService httpExchangeService, HandlingExceptionMessages handlingExceptionMessages,
			AnalyticsEventUtil analyticsEventUtil) {
		this.sFTokenUtil = sFTokenUtil;
		this.analyticsEventPublisher = analyticsEventPublisher;
		this.jsonUtility = jsonUtility;
		this.httpExchangeService = httpExchangeService;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.analyticsEventUtil = analyticsEventUtil;		
	}
	
    private void updateAlert(Map<String, Object> params, AnalyticsEventWrapper analyticsEvent, String queueName)
    		 throws DataPublishingException, SendToExchangeException{

        String urlAlertUpdateContext = null;
       // RmqMessage result = null;
        //api/alerts/{alertId}/dismiss
        String alertId = null;
       // EmxErrorResponse eMoneyErrorResponse = null;
       try{
    	   analyticsEventPublisher.publish(analyticsEvent);
           headers = sFTokenUtil.getEmoneyAccessTokenHeaders((String)params.get("office"));
           headers.forEach((s, s2) -> log.debug("Key" + s + "**** " + "value " + s2));
           
           alertId = (String)params.get("alertId")!=null?((String)params.get("alertId")).trim():"";
           if(!alertId.isEmpty()){
        	   urlAlertUpdateContext = emoneyserviceurl + alertUpdate;// + alertId + "/dismiss";
               urlAlertUpdateContext = urlAlertUpdateContext.replaceAll("\\{alertId\\}", alertId);
               log.info("**** url for dismiss alert for eMoney***" + urlAlertUpdateContext);
               analyticsEvent.setStatus(EnumEventCurrentStatus.CALLTOEMX.toString());
               analyticsEvent.setFinalStatus(EnumEventFinalStatus.PROCESSING.toString());
               analyticsEventPublisher.publish(analyticsEvent);
               
               Object result2 = httpExchangeService.sendToExchange(
    					SourceSystem.EMONEY, 
    					queueName, 
    					urlAlertUpdateContext, 
    					HttpMethod.POST, 
    					headers, 
    					null,
    					params);
               
               if ( StringUtils.isEmpty(result2 )){
            	   analyticsEventPublisher.publish(analyticsEvent.error());
            	   throw new DataPublishingException (" response from Emoney is empty");
    			}
                analyticsEvent.success(EnumEventCurrentStatus.RECEIVED);
                analyticsEventPublisher.publish(analyticsEvent);

                analyticsEvent.processing(EnumEventCurrentStatus.PUSHED_RMQ);
    			analyticsEventPublisher.publish(analyticsEvent); 
           }else{
        	   analyticsEventPublisher.publish(analyticsEvent.error());
        	   throw new DataPublishingException("AlertId param in the request is Null or Empty..!!"); 
           }
           
       }catch (SendToExchangeException e){
    	   throw e;
       }catch (Exception e) {
			throw new DataPublishingException(e);
       }
       log.info("***END of the Dismiss Alert flow***");
    }



	@Override
	public void processMessage(String queueName, MessageType messageType, String message)  {
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
    	try {
			 if ( messageType == MessageType.UPDATE){
				wrapper = analyticsEventUtil.getEvent("sf-alert-update");
				Map<String,Object> map = jsonUtility.getMapFromJsonString(message);
				this.updateAlert(map, wrapper, queueName);
				return;
			}
		} catch (Exception e) {
			try {
				handlingExceptionMessages.processException(
						SourceSystem.EMONEY,
						new SendToExchangeException(e), 
						queueName,						
						jsonUtility.getJsonStringFromObject(message)
						);
				analyticsEventPublisher.publish(
						wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			log.error("Exception in ProcessEmxClientMessage.processMessage", e);
		}    	
    }

	@Override
	public void processMessage(String queueName, MessageType type, Object message) {
		// TODO Auto-generated method stub
		
	}	

}

