package com.integration.sf.mqlistener;

import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.service.LoggerUtil;

/**
 * This Class pick messages from createTask Queue in RabbitMQ
 */
@Component
public class SfTaskMessageListener {

	private ProcessMessage taskProcessorService;
	private static final Logger logger = LoggerFactory.getLogger(SfTaskMessageListener.class);

	Log log = LoggerUtil.getLog(this);

	public SfTaskMessageListener(@Qualifier("TaskProcessorServiceImpl") ProcessMessage taskProcessorService) {
		this.taskProcessorService = taskProcessorService;
	}

	/**
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 */
	@RabbitListener(queues = "${mq.sf.task.create.queue}", concurrency = "${mq.sf.task.create.concurrency:1-1}" )
	public void taskMessageReceiver(Message message) {
		logger.info("*********** SfTaskMessageListener : Payload Received from CREATE QUEUE  **************");
		taskProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.CREATE,
				new String(message.getBody()));
		logger.info("********** SfTaskMessageListener : END OF Payload Create Task LIFE CYCLE *************");		
	}

	@RabbitListener(queues = "${mq.sf.task.update.queue}", concurrency = "${mq.sf.task.update.concurrency:1-1}" )
	public void updateTask(Message message) {
		logger.info("*********** SfTaskMessageListener : Payload Received from UPDATE QUEUE  **************");
		taskProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.UPDATE,
				new String(message.getBody()));
		logger.info("********** SfTaskMessageListener : END OF Payload UPDATE Task LIFE CYCLE *************");	
	}

	@RabbitListener(queues = "${mq.sf.task.delete.queue}", concurrency = "${mq.sf.task.delete.concurrency:1-1}" )
	public void deleteTask(Message message) {
		logger.info("*********** SfTaskMessageListener : Payload Received from DELETE QUEUE  **************");
		taskProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.DELETE,
				new String(message.getBody()));
		logger.info("********** SfTaskMessageListener : END OF Payload DELETE Task LIFE CYCLE *************");	
	}

	@RabbitListener(queues = "${mq.emx.task.response.queue}", concurrency = "${mq.emx.task.response.concurrency:1-1}" )
	public void taskResponse(Message message) {
		logger.info("*********** SfTaskMessageListener : Payload Received from RESPONSE QUEUE  **************");
		taskProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.RESPONSE,
				new String(message.getBody()));
		logger.info("********** SfTaskMessageListener : END OF Payload RESPONSE Task LIFE CYCLE *************");	

	}
}
