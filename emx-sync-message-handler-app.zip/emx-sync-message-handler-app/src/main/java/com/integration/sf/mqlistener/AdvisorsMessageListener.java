package com.integration.sf.mqlistener;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;
import com.integration.service.LoggerUtil;

import com.integration.sf.service.EmxAdvisorsResponseService;
import org.apache.commons.logging.Log;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AdvisorsMessageListener {
	Log logger = LoggerUtil.getLog(this);
	@Value("${mq.sf.advisors.get.queue}")
	private String queue;

	@Value("${mq.emx.advisors.response.queue}")
	private String responsequeue;

	private ProcessMessage emxAdvisorsResponseService;

	private ProcessMessage advisorsService;
	@Autowired
	 EmxAdvisorsResponseService emxAdvisors;

	@Autowired
	public AdvisorsMessageListener(@Qualifier("AdvisorsService") ProcessMessage advisorsService,
			@Qualifier("EmxAdvisorsResponseService") ProcessMessage emxAdvisorsResponseService) {
		this.advisorsService = advisorsService;
		this.emxAdvisorsResponseService =emxAdvisorsResponseService;
	}

	@RabbitListener(queues = "${mq.sf.advisors.get.queue}", concurrency = "${mq.sf.advisors.get.concurrency:1-1}" )
	public void advisors(Message message) {
		logger.info("message received ved from RMQ" + message);
		logger.info("Start AdvisorsMessageListener.advisors");

		advisorsService.processMessage(queue, MessageType.GET, new String(message.getBody()));

		logger.info("End AdvisorMessageListener.advisors");

	}

	// response from emx for get all advisors
	@RabbitListener(queues = "${mq.emx.advisors.response.queue}", concurrency = "${mq.emx.advisors.response.concurrency:1-1}" )
	public void advisorsResponse(Message message) {
		logger.info("Advisors response message received ved from RMQ " + message);
		logger.info("Start AdvisorsMessageListener.advisorsResponse");
         try {
			 emxAdvisorsResponseService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.RESPONSE, new String(message.getBody()));
		 }
		 catch (Exception e){
         	e.printStackTrace();
		 }

	}

}
