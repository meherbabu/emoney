package com.integration.sf.mqlistener;

import org.apache.commons.logging.Log;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.integration.bean.common.MessageType;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.service.LoggerUtil;

@Component
public class SfNotesMessageListener {

	private ProcessMessage notesProcessorService;

	Log log = LoggerUtil.getLog(this);


	@Autowired
	public SfNotesMessageListener(@Qualifier("NotesProcessorServiceImpl") ProcessMessage notesProcessorService) {
		this.notesProcessorService = notesProcessorService;
	}

	/**
	 * 
	 * @param message
	 */
	@RabbitListener(queues = "${mq.sf.notes.create.queue}" , concurrency = "${mq.sf.notes.create.concurrency:1-1}" )
	public void receiveCreateNotes(Message message) {
		notesProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.CREATE, new String(message.getBody()));
	}

	/***
	 * @param message
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	@RabbitListener(queues = "${mq.sf.notes.update.queue}" , concurrency = "${mq.sf.notes.update.concurrency:1-1}" )
	public void updateListener(Message message) {
		notesProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.UPDATE, new String(message.getBody()));
	}
	/**
	 * 
	 * @param message
	 */
	@RabbitListener(queues = "${mq.sf.notes.delete.queue}", concurrency = "${mq.sf.notes.delete.concurrency:1-1}" )
	public void deleteNotes(Message message) {

		notesProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.DELETE, new String(message.getBody()));

	}
	/**
	 * 
	 * @param message
	 */
	@RabbitListener(queues = "${mq.emx.note.response.queue}", concurrency = "${mq.emx.note.response.concurrency:1-1}" )
	public void emxNotesResponse(Message message) {
		notesProcessorService.processMessage(message.getMessageProperties().getConsumerQueue(), MessageType.RESPONSE, new String(message.getBody()) );

	}
}
