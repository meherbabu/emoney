package com.integration.sf.service;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.SourceSystem;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;

@Service
@Qualifier("EmxAdvisorsResponseService")
public class EmxAdvisorsResponseService implements ProcessMessage {

	Log log = LoggerUtil.getLog(this);

	@Value("${saleforce.url}")
	private String sfUrl;
	@Value("${saleforce.context.advisors.get}")
	private String sfContext;

	private AnalyticsEventUtil analyticsEventUtil;

	private AnalyticsEventPublisher eventPublisher;

	private HandlingExceptionMessages handlingExceptionMessages;

	private AccessTokenGenerator accessTokenGenerator;

	private HttpExchangeService httpExchangeService;

	MessageSender messageSender;

	@Autowired
	public EmxAdvisorsResponseService(AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher,
			HandlingExceptionMessages handlingExceptionMessages, AccessTokenGenerator accessTokenGenerator,
			HttpExchangeService httpExchangeService, MessageSender messageSender) {
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.accessTokenGenerator = accessTokenGenerator;
		this.httpExchangeService = httpExchangeService;
		this.messageSender = messageSender;
	}

	@Override
	public void processMessage(String queueName, MessageType type, String message) {

		log.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
		log.debug(message);

		AnalyticsEventWrapper wrapper = null;
		try {

			switch (type) {
			// posting response to SF
			case RESPONSE:
				wrapper = analyticsEventUtil.getEvent("emx-advisor-response");
				ObjectMapper objectMapper = new ObjectMapper();
				JsonNode jsonNode = null;

				jsonNode = objectMapper.readTree(message);
				String trackingId = jsonNode.get("trackingId").textValue();
				String orgId = jsonNode.get("orgId").textValue();
				String sfOffice = jsonNode.get("sfOffice").textValue();
				// extracting advisors from string
				JsonNode jsonNode1 = jsonNode.get("advisors");
				log.debug("" + jsonNode1);
				String advisors = objectMapper.writeValueAsString(jsonNode1);
				log.debug("String value " + advisors);

				wrapper.setTrackingIdValue(trackingId);
				wrapper.add("orgId", orgId);

				postToSF(queueName, advisors, wrapper, sfOffice);
				break;
			default:
				break;
			}
		}
		catch (SendToExchangeException e) {
			// catch here but doing nothing. message is already logged.
		}		
		catch (Exception e) {
			handlingExceptionMessages.processException(SourceSystem.SALESFORCE, new SendToExchangeException(e),
					queueName, message);
			eventPublisher.publish(wrapper.error(EnumEventCurrentStatus.TRANSFORMING));
			log.error("Exception in sending Advisors to SF", e);
		}
		log.info("End of the EmxAdvisorsResponse Services");
	}

	/**
	 * 
	 * @param queueName
	 * @param message
	 * @param wrapper
	 * @param office
	 * @throws SendToExchangeException
	 */
	private void postToSF(String queueName, String message, AnalyticsEventWrapper wrapper, String office)
			throws SendToExchangeException, DataPublishingException {

		try {

			// todo wiped out with lee Token service
			Map<String, String> headers = accessTokenGenerator.getSaleforceAccessTokenHeadersUsingEmoneyOffice(office);
			sfUrl = accessTokenGenerator.getSaleforceUrlUsingEmoney(office);
			// todo clean up code and get url for method
			String url = sfUrl + sfContext;
			log.info("***url of SF to post Advisors***" + url);
			// Initial event ;
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.CALLTOSF));
			httpExchangeService.sendToExchange(SourceSystem.EMONEY, queueName, url, HttpMethod.PATCH, headers, message);
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.CALLTOSF));
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.SENDING_FOR_ACK)
					.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}
	}

	@Override
	public void processMessage(String queueName, MessageType type, Object message) {

	}

}
