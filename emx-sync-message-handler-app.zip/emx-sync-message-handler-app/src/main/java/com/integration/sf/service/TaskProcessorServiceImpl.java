package com.integration.sf.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventType;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxTask;
import com.integration.bean.emx.EmxTaskResponse;
import com.integration.bean.sf.Acknowledgement;
import com.integration.bean.sf.SfEmxTask;
import com.integration.bean.sf.SfEmxTasksPiiDataImpl;
import com.integration.bean.sf.SfTask;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.dao.SfEmxHeaderMapRepository;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.transformation.modal.SFToEMoneyTaskRequest;

/**
 * This class used to transform SFTask object to EmoneyTask Request Object.
 */
@Service
@Qualifier("TaskProcessorServiceImpl")
public class TaskProcessorServiceImpl implements ProcessMessage {

	Log logger = LoggerUtil.getLog(this);
    
    @Value("${emoney.url}")
    private String emoneyserviceurl;
    
    @Value(("${emoney.context.task.create}"))
    private String createTaskContext;
    
    @Value(("${emoney.context.task.update}"))
    private String updateTaskContext;
    
    @Value(("${emoney.context.task.delete}"))
    private String deleteTaskContext;
    
    @Value("${saleforce.context.task.response}")
    private String sfServiceContext;
    
    @Value("${mq.emx.task.response.queue}")
    String queueResponse;
    
    @Value("com.emx.integration")
    private String responseExchange;
    
    @Value("emx.task.response")
    private String responseRoutingkey;
    
    @Value("false")
    private boolean isPersistent;
    
 
    private SFToEMoneyTaskRequest sfToEMoneyTaskRequest;
    private MessageSender messageSender;    
    private SfEmxHeaderMapRepository repository;
    private AccessTokenGenerator sFTokenUtil;
    private AnalyticsEventPublisher analyticsEventPublisher;	
    private JsonUtility jsonUtility;
    private HttpExchangeService httpExchangeService ;
    private HandlingExceptionMessages handlingExceptionMessages;
	private AnalyticsEventUtil analyticsEventUtil;
	private AnalyticsEventPublisher eventPublisher;
	private PiiDataLog piiDataLog; 



	@Autowired
    public TaskProcessorServiceImpl(
			SFToEMoneyTaskRequest sfToEMoneyTaskRequest, MessageSender messageSender,
			SfEmxHeaderMapRepository repository, AccessTokenGenerator sFTokenUtil,
			AnalyticsEventPublisher analyticsEventPublisher, JsonUtility jsonUtility,
			HttpExchangeService httpExchangeService, HandlingExceptionMessages handlingExceptionMessages,
			AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher,
			SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl) {
		this.sfToEMoneyTaskRequest = sfToEMoneyTaskRequest;
		this.messageSender = messageSender;
		this.repository = repository;
		this.sFTokenUtil = sFTokenUtil;
		this.analyticsEventPublisher = analyticsEventPublisher;
		this.jsonUtility = jsonUtility;
		this.httpExchangeService = httpExchangeService;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.piiDataLog = sfEmxTasksPiiDataImpl;
	}

	/**

     * @param operation
     * @throws DataProcessingException
     * @throws DataPublishingException
     */
	public void createClientRequestProcessMessage(String queueName ,SfEmxTask taskWrapper, MessageType operation,
			AnalyticsEventWrapper event) throws DataPublishingException, SendToExchangeException {
		logger.info("***    Inside TaskProcessorServiceImpl : "+taskWrapper.toString());
	    SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl = (SfEmxTasksPiiDataImpl) piiDataLog; //Newly added 
		try {
			Map<String, String> headers = sFTokenUtil
					.getEmoneyAccessTokenHeaders(taskWrapper.getSfTask().getMetadata().getOffice());

			SfTask sfTask = taskWrapper.getSfTask().getTask();
			analyticsEventPublisher.publish(event.processing(EnumEventCurrentStatus.TRANSFORMING));
			// transformation
			EmxTask eMoneyTaskRequest = sfToEMoneyTaskRequest.transformSFTaskToEMoneyTask(sfTask) ;//transformSfTask2EmoneyTask(sfTask, operation);
			analyticsEventPublisher.publish(event.success(EnumEventCurrentStatus.TRANSFORMING));
			logger.info("*******after transformed SF to eMoney Task PayLoad********" + eMoneyTaskRequest.toString());
		   
			Object result = null;
			if (operation == MessageType.UPDATE ) {
				String taskId = sfTask.geteMoneyTaskId();

				event.setEventTypeValue(EnumEventType.UPDATE).processing(EnumEventCurrentStatus.CALLTOEMX);
				analyticsEventPublisher.publish(event);

//				result = eMoneyTaskRestClient.updateTaskToEMX(eMoneyTaskRequest, taskId, headers);
			    String uri=emoneyserviceurl+updateTaskContext;//+taskId;
			    Map<String,Object> params = new HashMap<String,Object>();
			    params.put("taskId", taskId);
			    sfEmxTasksPiiDataImpl.setPiiData(eMoneyTaskRequest.getClientId(), eMoneyTaskRequest.getAssignedTo()); //Newly added 
	
			    result = httpExchangeService.sendToExchange(
										SourceSystem.SALESFORCE, 
										queueName, 
										uri, 
										HttpMethod.PUT, 
										headers, 
										jsonUtility.getJsonStringFromObject(eMoneyTaskRequest),
										params);
		        analyticsEventPublisher.publish(event.success());

			} else {
				event.setEventTypeValue(EnumEventType.CREATE).processing(EnumEventCurrentStatus.CALLTOEMX);
				analyticsEventPublisher.publish(event);
				String url = emoneyserviceurl + createTaskContext;
				String message = jsonUtility.getJsonStringFromObject(eMoneyTaskRequest);
				 sfEmxTasksPiiDataImpl.setPiiData(eMoneyTaskRequest.getClientId(), eMoneyTaskRequest.getAssignedTo()); //Newly added 
		
				 result = httpExchangeService.sendToExchange(
										SourceSystem.SALESFORCE, 
										queueName, 
										url, 
										HttpMethod.POST, 
										headers, 
										jsonUtility.getJsonStringFromObject(eMoneyTaskRequest),
										null);
				
				analyticsEventPublisher.publish(event);
				logger.info("*****Converting payload into String****" + message);
				//result = eMoneyTaskRestClient.postTaskToEMX(eMoneyTaskRequest, headers);

			}
			if ( StringUtils.isEmpty(result ))
			{
				eventPublisher.publish(event.error());
				throw new DataPublishingException (" response from Emoney is empty");
			}
			event.success(EnumEventCurrentStatus.RECEIVED);
			eventPublisher.publish(event);

			event.processing(EnumEventCurrentStatus.PUSHED_RMQ);
			eventPublisher.publish(event);
			
			EmxTaskResponse tempTastResp = (EmxTaskResponse)jsonUtility.getObjectFromJsonString(String.valueOf(result), EmxTaskResponse.class);// result			
			tempTastResp.setOrgId(taskWrapper.getSfTask().getMetadata().getOrgId());
			tempTastResp.setSfTaskId(taskWrapper.getSfTask().getTask().getTaskId());
			
			messageSender.send(responseExchange, responseRoutingkey,isPersistent, jsonUtility.getJsonStringFromObject(tempTastResp ));
			
			event.success(EnumEventCurrentStatus.PUSHED_RMQ);
			eventPublisher.publish(event);
		}
		catch (SendToExchangeException e)
		{
			throw e;
		}
		catch (Exception e) {
			throw new DataPublishingException(e);
		}

		logger.info("*********** END OF THE TASK FLOW *************");
	}
	/**
	 * 
	 * @param queueName
	 * @param params
	 * @param analyticsEvent
	 * @throws DataPublishingException
	 * @throws SendToExchangeException
	 */
    public void deletetaskService(String queueName, Map<String, Object>  params ,AnalyticsEventWrapper  analyticsEvent) throws DataPublishingException, SendToExchangeException  {
    	SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl = (SfEmxTasksPiiDataImpl) piiDataLog;
        try {
			logger.info("deletetaskService :: "+params);
			// {"office":"salesforceOffice-2","taskId":"1254211","orgId":"salesforceOffice-2","trackingId":"452124121"}       
			String taskId = String.valueOf(params.get("taskId"));
			String trackingId = String.valueOf(params.get("trackingId"));
			String office = String.valueOf(params.get("office"));
			String orgId = String.valueOf(params.get("orgId"));
			
			Map<String,String> headers = sFTokenUtil.getEmoneyAccessTokenHeaders(office);
			analyticsEventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.CALLTOEMX).
					setTrackingIdValue(trackingId));
			sfEmxTasksPiiDataImpl.setPiiData(null,null);		
			
			String uri =emoneyserviceurl+deleteTaskContext;
			
			Object result = httpExchangeService.sendToExchange(
									SourceSystem.SALESFORCE, 
									queueName, 
									uri, 
									HttpMethod.DELETE, 
									headers, 
									null,
									params);
      
//         result = eMoneyTaskRestClient.deleteTaskToEMX(headers,taskId);
			analyticsEventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.RECEIVED));
		} catch (SendToExchangeException e) {
			e.printStackTrace();
		} catch (Exception e) {
			throw new DataPublishingException (e);
		} 

    }
    /**
     * 
     * @param queueName
     * @param emxTaskResponse
     * @param analyticsEvent
     * @throws Exception
     */
    public void emoneytaskResponse(String queueName , EmxTaskResponse emxTaskResponse,AnalyticsEventWrapper analyticsEvent) throws Exception {
         try {
             String Id = emxTaskResponse.getSfTaskId();
             //query db for sfEntity
             String sfEntity = repository.findSfEntity(emxTaskResponse.getOrgId(), "task");
             Map<String,String> headers = sFTokenUtil.getSaleforceAccessTokenHeaders(emxTaskResponse.getOrgId());
             
             Map<String, Object> params = new HashMap<String, Object>();
             params.put("entity", sfEntity);
             params.put("id", Id);
             
             String url =sFTokenUtil.getSaleforceUrl(emxTaskResponse.getOrgId())+sfServiceContext;// + sfEntity + "/" + Id;
             
             logger.info("SF_entity value fetching from DB" + sfEntity);
             logger.info("*** url of the Acknowledgment for Task Service" +url);
             logger.info(headers);
             
             analyticsEventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.CALLTOSF));

             Acknowledgement acknowledgement = new Acknowledgement();
             acknowledgement.seteMoney_Id__c(emxTaskResponse.getTaskId());
             
             logger.info("Payload for ACK "+acknowledgement);
             
             Object result = httpExchangeService.sendToExchange(
									SourceSystem.EMONEY, 
									queueName, 
									url, 
									HttpMethod.PATCH, 
									headers, 
									jsonUtility.getJsonStringFromObject(acknowledgement),
									params);
             logger.info("****** Sucessfully sent Task Acknowledgment to SF******* ");
             analyticsEventPublisher.publish(analyticsEvent.success().add("Response body", result));
		} catch (SendToExchangeException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException(e);
		}

    }

    @Override
    public void processMessage(String queueName, MessageType type, Object message) {
    	// TODO Auto-generated method stub
    	
    }
    
    @Override
    public void processMessage(String queueName, MessageType messageType, String message) {
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
    	try {
			if ( messageType == MessageType.CREATE)
			{
				wrapper = analyticsEventUtil.getEvent("sf-task-create");
				SfEmxTask taskWrapper = (SfEmxTask)jsonUtility.getObjectFromJsonString(message, SfEmxTask.class);
				//create (queueName, notesRequest,messageType ,wrapper);
			    createClientRequestProcessMessage( queueName, taskWrapper, messageType, wrapper) ;
				return;
			}
			else if ( messageType == MessageType.UPDATE)
			{
				wrapper = analyticsEventUtil.getEvent("sf-task-update");
				SfEmxTask taskWrapper = (SfEmxTask)jsonUtility.getObjectFromJsonString(message, SfEmxTask.class);
				//create (queueName, notesRequest,messageType ,wrapper);
			    createClientRequestProcessMessage( queueName, taskWrapper, messageType, wrapper) ;
				return;
			}
			else if ( messageType == MessageType.DELETE)
			{
				wrapper = analyticsEventUtil.getEvent("sf-task-delete");
				Map<String, Object> map = jsonUtility.getMapFromJsonString(message);
				deletetaskService(queueName, map, wrapper);
				return;
			}
			else if ( messageType == MessageType.RESPONSE)
			{
				wrapper = analyticsEventUtil.getEvent("emx-task-response-create");
				EmxTaskResponse emxNotesResponse = (EmxTaskResponse)jsonUtility.getObjectFromJsonString(message, EmxTaskResponse.class);
				emoneytaskResponse( queueName ,emxNotesResponse, wrapper);
				return;
			}
		} catch (SendToExchangeException e) {
		 	logger.error("Exception in TaskProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error().add("Error message ", e.getCause().getMessage()));
		} catch (Exception e) {
			logger.error("Exception in TaskProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e);
			try {
				handlingExceptionMessages.processException(
						SourceSystem.EMONEY,
						new SendToExchangeException(e), 
						queueName,						
						message
						);
				eventPublisher.publish(
						wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));
			} catch (Exception e1) {
				e1.printStackTrace();				
			}			
		}    	
    }// END OF processMessage
  
}
