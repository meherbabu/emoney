package com.integration.sf.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.EnumEventSourceNDestination;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.emx.EmxNotesResponse;
import com.integration.bean.sf.SfEmxNotesPiiDataImpl;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.exception.DataPublishingException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.SfToEmxCommonUtil;

@Service
@Qualifier ("ProcessSfNoteMessage")
public class ProcessSfNoteMessage implements ProcessMessage {

	Log logger = LoggerUtil.getLog(this);
	
	@Value("${mq.emx.notes.response.queue}")
	String responseQueue;

	@Value("${mq.emx.note.response.exchange}")
	private String responseExchange;
	    
	@Value("${mq.emx.note.response.routingkey}")
	private String responseRoutingkey;
	
	@Value("${mq.emx.note.response.persistence: false}")
	private boolean isPersistent;
	
	@Value("${emoney.url}")
	private String eMoneyUrl;

	@Value("${saleforce.context.note.create}")
	private String noteCreateContext;

	@Value("${emoney.context.note.update}")
	private String noteUpdateContext;

	private HttpExchangeService postMessageToEndServer;

	private AccessTokenGenerator tokenUtil;

	private SfToEmxCommonUtil commonUtils;

	private AnalyticsEventUtil analyticsEventUtil;

	private AnalyticsEventPublisher eventPublisher;
	
	private MessageSender notesResponseSender;
	
	private JsonUtility jsonUtility;
	
	private PiiDataLog piiDataLog; 
	
	/**
	 *
	 * @param postMessageToEndServer
	 * @param tokenUtil
	 * @param commonUtils
	 * @param analyticsEventUtil
	 * @param eventPublisher
	 * @param notesResponseSender
	 */
	@Autowired
	public ProcessSfNoteMessage(HttpExchangeService postMessageToEndServer,
			AccessTokenGenerator tokenUtil, SfToEmxCommonUtil commonUtils,
			AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher, MessageSender notesResponseSender,
			JsonUtility jsonUtility, SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl) {
		this.postMessageToEndServer = postMessageToEndServer;
		this.tokenUtil = tokenUtil;
		this.commonUtils = commonUtils;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.notesResponseSender = notesResponseSender;
		this.jsonUtility = jsonUtility;
		this.piiDataLog = sfEmxNotesPiiDataImpl;
	}

	@Override
	public void processMessage(String queueName, MessageType type, String message) {

		logger.info("Start ProcessSfNoteMessage.processMessage");
		logger.debug("Process message...Queue [" + queueName + "] , Message Type [" + type + "].  Message: ");
		logger.debug(message);
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
		SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog;
		try {
			String[] data = null;
			Map<String, String> headers = null;
			String responseObject = null;
			EmxNotesResponse eMoney = null;
			List<Object[]> objectArray = null;

			if (type == MessageType.CREATE) {
				// this array contain String[trackingID, "orgId", "office","clientId",
				// "noteId"]
				data = commonUtils.getSfNoteInfoFromMessageQueue(message,type);
				// get Access Token
				headers = tokenUtil.getEmoneyAccessTokenHeaders(data[2]);
			}
			if ((type == MessageType.UPDATE)) {
				// this array contain String[trackingID, "orgId", "office","clientId",
				// "noteId","eMoneyNoteId"]
				data = commonUtils.getSfNoteInfoFromMessageQueue(message,type);
				// get Access Token
				headers = tokenUtil.getEmoneyAccessTokenHeaders(data[2]);
			}

			switch (type) {

			case CREATE:
				wrapper = analyticsEventUtil.getEvent("sf-note-create");
			 
				eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[3])
						.setNoteIdValue(data[4]).setAdditionalPropertyValue("orgId", data[1]));

				// TransformMessages
				objectArray = commonUtils.transformNoteUpdateMessage(message);
				// this array contain Object["orgId","office","clientId","noteId","eMoneyId","Slit message by Note"]
				for (Object[] objects : objectArray) {
					eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.CALLTOEMX)
							.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
					
					String clientId = objects[2].toString();
					String noteId = objects[3].toString();
					String eMoneyNotesId = objects[4].toString(); //Newly added 
					sfEmxNotesPiiDataImpl.setPiiData(clientId, eMoneyNotesId, noteId); //Newly added
					Map<String,Object> uriParamValue = new HashMap<>();
					uriParamValue.put("clientId", clientId);
					uriParamValue.put("noteId", noteId);
					responseObject = (String) postMessageToEndServer.sendToExchange(eMoneyUrl + noteUpdateContext,
							HttpMethod.POST, headers, objects[5].toString(),uriParamValue);
					eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
					eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.TRANSFORMING)
							.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
					
					if (responseObject != null) {
						logger.info("EMX Update Note  " + responseObject);

						eMoney = (EmxNotesResponse) jsonUtility.getObjectFromJsonString(responseObject,
								EmxNotesResponse.class);

						eMoney.setSfNoteId(data[5]);
						eMoney.setOrgId(data[1]);

						eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
						eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.SENDING_FOR_ACK)
								.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

						notesResponseSender.send(responseExchange, responseRoutingkey, isPersistent,
								jsonUtility.getJsonStringFromObject(eMoney));
						eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.SENDING_FOR_ACK)
								.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

					} else
						throw new DataPublishingException("failed to send notes response to AMQ");
					logger.info("******sending create notes response to AMQ*****" + responseObject);
					
				}
				break;// to terminate
			case UPDATE:
				
				wrapper = analyticsEventUtil.getEvent("sf-note-update");
				eventPublisher.publish(wrapper.setTrackingIdValue(data[0]).setClientIdValue(data[3])
						.setDestinationValue(EnumEventSourceNDestination.EMX)
						.setNoteIdValue(data[4]).setAdditionalPropertyValue("orgId", data[1]).setAdditionalPropertyValue("SfNoteId", data[4]));

				// TransformMessages
				objectArray = commonUtils.transformNoteUpdateMessage(message);
				// received as objectArray ["orgId","office","clientId","noteId",sfNoteId,"Split message by Note"]
				for (Object[] objects : objectArray) {
					eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.CALLTOEMX)
							.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
					
					String clientId = objects[2].toString();
					String noteId = objects[3].toString();
					String eMoneyNotesId = objects[4].toString(); //Newly added 
					sfEmxNotesPiiDataImpl.setPiiData(clientId, eMoneyNotesId, noteId); //Newly added
					Map<String,Object> uriParamValue = new HashMap<>();
					uriParamValue.put("clientId", clientId);
					uriParamValue.put("noteId", noteId);
					responseObject = (String) postMessageToEndServer.sendToExchange(eMoneyUrl + noteUpdateContext,
							HttpMethod.PUT, headers, objects[5].toString(),uriParamValue);
					eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
					eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.TRANSFORMING)
							.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
					
					if (responseObject != null) {
						logger.info("EMX Update Note Response " + responseObject);

						eMoney = (EmxNotesResponse) jsonUtility.getObjectFromJsonString(responseObject,
								EmxNotesResponse.class);

						eMoney.setSfNoteId(data[4]);
						eMoney.setOrgId(data[1]);

						eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
						eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.SENDING_FOR_ACK)
								.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

						notesResponseSender.send(responseExchange, responseRoutingkey, isPersistent, 
								jsonUtility.getJsonStringFromObject(eMoney));
						eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.SENDING_FOR_ACK)
								.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

					} else
						throw new DataPublishingException("failed to send notes response to AMQ");
					logger.info("******sending create notes response to AMQ*****" + responseObject);

				}
				break;
			default:
				break;
			}
		} catch (Exception e) {
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.TRANSFORMING)
					.setFinalStatusValue(EnumEventFinalStatus.ERROR)
					.setAdditionalPropertyValue("Error Message ", e.getMessage()));
		
			logger.error("Exception in ProcessSfNoteMessage.processMessage" + piiDataLog.logPiiData(), e);
		}
		logger.info("End ProcessSfNoteMessage.processMessage");

	}
	
	@Override
	public void processMessage(String queueName, MessageType type, Object message) {
		// TODO Auto-generated method stub
		
	}

}
