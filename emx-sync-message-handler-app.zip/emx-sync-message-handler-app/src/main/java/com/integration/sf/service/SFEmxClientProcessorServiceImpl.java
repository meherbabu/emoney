/**
 * <h1>EventProcessorServiceImpl for create/update/delete : </h1>
 * The EventProcessorServiceImpl program implements EventProcessorService.
 * This class is called from RMQMessageListener, When ever there is Salesforce request Object in the queue.
 * <p>
 * Listen will call this service to send the salesforce object to emoney.
 * This class splits, transforms and post/put/delete messages to emoney service.
 * Response will be published to response Queue.
 * <p>
 * *
 *
 * @author Vinay Domala
 * @version 1.0
 */
package com.integration.sf.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.EnumEventSourceNDestination;
import com.integration.bean.common.MessageType;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.common.SourceSystem;
import com.integration.bean.emx.EmxClientRequest;
import com.integration.bean.emx.EmxClientRequestV2;
import com.integration.bean.emx.EmxClientResponse;
import com.integration.bean.sf.Acknowledgement;
import com.integration.bean.sf.SfClientRequest;
import com.integration.bean.sf.SfEmxClientPiiDataImpl;
import com.integration.common.service.AccessTokenGenerator;
import com.integration.common.service.ProcessMessage;
import com.integration.dao.SfEmxHeaderMapRepository;
import com.integration.dao.SfEmxIdLogRepository;
import com.integration.exception.DataPublishingException;
import com.integration.exception.SendToExchangeException;
import com.integration.model.SfEmxIdLog;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.HandlingExceptionMessages;
import com.integration.service.HttpExchangeService;
import com.integration.service.JsonUtility;
import com.integration.service.MessageSender;
import com.integration.transformation.SFToEMoneyRequest;

@Service
@Qualifier("SFEmxClientProcessorServiceImpl")
public class SFEmxClientProcessorServiceImpl implements ProcessMessage {

    private static final Logger logger = LoggerFactory.getLogger(SFEmxClientProcessorServiceImpl.class);

    @Value("${mq.sf.client.response.exchange}")
	private String exchangeResponse;

	@Value("${mq.sf.client.response.routingkey}")
	private String routingkeyResponse;
	
	@Value("${mq.sf.client.response.persistence}")
	private boolean isPersistent;
	
	@Value("${saleforce.context.client.acknowledgment}")
	private String sfUrlContext;

    @Value("${emoney.url}")
    private String emoneyserviceurl;

    
    @Value("${emoney.context.client.create}")
    private String clientCreateContext;
	
    @Value("${emoney.context.client.update}")
    private String clientUpdateContext;

    @Value("${emoney.context.client.delete}")
    private String clientDeleteContext;

    private SFToEMoneyRequest sfToEMoneyRequest;	
	private AnalyticsEventPublisher eventPublisher;
    private MessageSender messageSender;    
    private SfEmxIdLogRepository sfEmxIdLogRepository;
    private AccessTokenGenerator accessTokenHeaderGenerator;
    private AccessTokenGenerator sFTokenUtil;
    private SfEmxHeaderMapRepository repository;
    private JsonUtility jsonUtility;
    private HandlingExceptionMessages handlingExceptionMessages;
    private HttpExchangeService httpExchangeService;
    private AnalyticsEventUtil analyticsEventUtil;
    private PiiDataLog piiDataLog; 
    
    
  
    @Autowired
    public SFEmxClientProcessorServiceImpl(SFToEMoneyRequest sfToEMoneyRequest, AnalyticsEventPublisher eventPublisher,
			MessageSender messageSender, SfEmxIdLogRepository sfEmxIdLogRepository,
			AccessTokenGenerator accessTokenHeaderGenerator, AccessTokenGenerator sFTokenUtil,
			SfEmxHeaderMapRepository repository, JsonUtility jsonUtility,
			HandlingExceptionMessages handlingExceptionMessages, HttpExchangeService httpExchangeService,
			AnalyticsEventUtil analyticsEventUtil,
			SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl ) {
		this.sfToEMoneyRequest = sfToEMoneyRequest;
		this.eventPublisher = eventPublisher;
		this.messageSender = messageSender;
		this.sfEmxIdLogRepository = sfEmxIdLogRepository;
		this.accessTokenHeaderGenerator = accessTokenHeaderGenerator;
		this.sFTokenUtil = sFTokenUtil;
		this.repository = repository;
		this.jsonUtility = jsonUtility;
		this.handlingExceptionMessages = handlingExceptionMessages;
		this.httpExchangeService = httpExchangeService;
		this.analyticsEventUtil = analyticsEventUtil;
		this.piiDataLog = sfEmxClientPiiDataImpl; 
	}

	@Override
    public void processMessage(String queueName, MessageType type, Object message) {
    	// TODO Auto-generated method stub
    	
    }
    
    @Override
    public void processMessage(String queueName, MessageType messageType, String message) {
		AnalyticsEventWrapper wrapper = AnalyticsEventWrapper.getNewInstance();
    	try {
			if ( messageType == MessageType.CREATE)
			{
				wrapper = analyticsEventUtil.getEvent("sf-client-create");
				SfClientRequest sfClientRequest = (SfClientRequest)jsonUtility.getObjectFromJsonString(message, SfClientRequest.class);
				createOrUpdateClientRequestProcessMessage( queueName,sfClientRequest, messageType, wrapper) ;
			 
				return;
			}
			if ( messageType == MessageType.UPDATE)
			{
				wrapper = analyticsEventUtil.getEvent("sf-client-update");
				SfClientRequest sfClientRequest = (SfClientRequest)jsonUtility.getObjectFromJsonString(message, SfClientRequest.class);
				createOrUpdateClientRequestProcessMessage( queueName,sfClientRequest, messageType, wrapper) ;
			  
				return;
			}
			if ( messageType == MessageType.DELETE)
			{
				wrapper = analyticsEventUtil.getEvent("sf-client-delete");
				EmxClientRequestV2 emxClientRequestV2 = (EmxClientRequestV2)jsonUtility.getObjectFromJsonString(message, EmxClientRequestV2.class);
				deleteClientRequestProcessMessage(queueName, emxClientRequestV2, wrapper);
			  
				return;
			}
			if ( messageType == MessageType.RESPONSE)
			{
				wrapper = analyticsEventUtil.getEvent("emx-client-response-create");
				EmxClientResponse emxNotesResponse = (EmxClientResponse)jsonUtility.getObjectFromJsonString(message, EmxClientResponse.class);
				createOrUpdateClientResponseProcessMessage( queueName ,emxNotesResponse, wrapper);
				return;
			}
		} catch (SendToExchangeException e) {
			logger.error("Exception in SFEmxClientProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error().add("Error message ", e.getCause().getMessage()));
		} catch (Exception e) {
			logger.error("Exception in SFEmxClientProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e);
			try {
				handlingExceptionMessages.processException(
						SourceSystem.EMONEY,
						new SendToExchangeException(e), 
						queueName,						
						message
						);
				eventPublisher.publish(
						wrapper.error(EnumEventCurrentStatus.TRANSFORMING).add("Error Message ", e.getMessage()));
			} catch (Exception e1) {
				logger.error("Exception in SFEmxClientProcessorServiceImpl.processMessage" + piiDataLog.logPiiData(), e1);
				e1.printStackTrace();
			}
		}    	
    }
    /**
     * 
     * @param queueName
     * @param sfClientRequestObj
     * @param operation
     * @param analyticsEvent
     * @throws DataPublishingException
     * @throws SendToExchangeException
     */
    private void createOrUpdateClientRequestProcessMessage(
    		String queueName, 
    		SfClientRequest sfClientRequestObj, 
    		MessageType operation, 
    		AnalyticsEventWrapper analyticsEvent)  throws DataPublishingException, SendToExchangeException {
    	SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl = (SfEmxClientPiiDataImpl ) piiDataLog;  //Newlyadded
    	try {
    		
    		sfEmxClientPiiDataImpl.setPiiData(sfClientRequestObj.getClients()[0].getId(), sfClientRequestObj.getClients()[0].getOwnerId(),
    		                                  null); //Newly Added
    
    		eventPublisher.publish(analyticsEvent);
			logger.info("***    Inside ClientRequestProcessMessage :: "+sfClientRequestObj);
			logger.info("***    Operation :: "+operation);

				logger.info("***Transforming SFRequest to EmoneyRequest for  :: "+operation);
				
				//EVENT BEFORE TRANFORMATION
				analyticsEvent.setStatus(EnumEventCurrentStatus.TRANSFORMING.toString());
				eventPublisher.publish(analyticsEvent);
				logger.info("***BEFORE Transformation :: EVENT Publish:: "+analyticsEvent);
		
				
				//CALLING TRANSFORMATION
				EmxClientRequest emoneyclient = 
						transformSfclient2EmoneyClient(sfClientRequestObj, operation); 
				
				//EVENT AFTER TRANFORMATION
				analyticsEvent.setStatus(EnumEventCurrentStatus.PROCESSED.toString());
				eventPublisher.publish(analyticsEvent);
				logger.info("***AFTER Transformation :: EVENT Publish:: "+analyticsEvent);
		
				
				//DB
				SfEmxIdLog mappingObject = new SfEmxIdLog();				
				mappingObject.setMessageId(sfClientRequestObj.getClients()[0].getMessageID());        	
				mappingObject.setSfofficeId(sfClientRequestObj.getClients()[0].getMetadata().getOffice());
				mappingObject.setSforgId(sfClientRequestObj.getClients()[0].getMetadata().getOrgId());
				mappingObject.setEntityType("SF");
				

				//EVENT CALLING REST
				eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.CALLTOEMX)); 
				logger.info("*** EVENT Publish:: "+analyticsEvent);
				
				// net to replace sfClientRequestObj.getClients()[0].getId() with salesforce id
				String office = sfClientRequestObj.getClients()[0].getMetadata().getOffice();
				Map<String, String> headers = accessTokenHeaderGenerator.getEmoneyAccessTokenHeaders(office);        		
				Object result = null;
				String messageToHttp = jsonUtility.getJsonStringFromObject(emoneyclient);
				logger.info("*** Request Message to Emoney :: "+messageToHttp);
				if(MessageType.CREATE == operation)
				{
					//DB
					mappingObject.setSfId(sfClientRequestObj.getClients()[0].getId()); 
					
			    	String url = emoneyserviceurl +clientCreateContext;
			
			        result = httpExchangeService.sendToExchange(
											SourceSystem.SALESFORCE, 
											queueName, 
											url, 
											HttpMethod.POST, 
											headers, 
											messageToHttp,
											null);
			        eventPublisher.publish(analyticsEvent.success());
			        
					
				}else {
					mappingObject.setSfId(sfClientRequestObj.getClients()[0].getId()); 
					//DB
					mappingObject.setEmxId(sfClientRequestObj.getClients()[0].geteMoneyId());         		
					//REST CALL        		
					Map<String, Object> requestParamsValues = new HashMap<String,Object>();
					requestParamsValues.put("clientId", emoneyclient.getId());
					sfEmxClientPiiDataImpl.setPiiData(sfClientRequestObj.getClients()[0].getId(), sfClientRequestObj.getClients()[0].getOwnerId(), 
							sfClientRequestObj.getClients()[0].geteMoneyId());
			    	String url = emoneyserviceurl+clientUpdateContext;

			    	result = httpExchangeService.sendToExchange(
											SourceSystem.SALESFORCE, 
											queueName, 
											url, 
											HttpMethod.PUT, 
											headers, 
											messageToHttp,
											requestParamsValues);
			        eventPublisher.publish(analyticsEvent.success());
			       
				}  
				//EVENT AFTER REST CALL
				analyticsEvent.setSrcValue(EnumEventSourceNDestination.EMX)
				.setDestinationValue(EnumEventSourceNDestination.RMQ);
				
				
				EmxClientResponse emoneyClientResponseResult = (EmxClientResponse)jsonUtility.getObjectFromJsonString(String.valueOf(result), EmxClientResponse.class);
	        	emoneyClientResponseResult.setSfClientId(sfClientRequestObj.getClients()[0].getId());
	        	emoneyClientResponseResult.setOrgId(sfClientRequestObj.getClients()[0].getMetadata().getOrgId());
	        	//DB
	        	mappingObject.setEmxId(emoneyClientResponseResult.getId()); 
	        	
	        	if(MessageType.CREATE == operation){
	        		createOrUpdateSfEmxIDLog(mappingObject,MessageType.CREATE.toString());
	        	}else{
	        		createOrUpdateSfEmxIDLog(mappingObject,MessageType.UPDATE.toString());
	        	}	        	
	        	
	        	//EVENT AFTER SUCCESS RESPONSE FROM REST
	        	logger.info("EMoneyClientResponse Got sucessfull from EMX Server: For operation : "+operation);
				analyticsEvent.success(EnumEventCurrentStatus.RECEIVED);				
				logger.info("*** EVENT Publish:: "+analyticsEvent);
	        	eventPublisher.publish(analyticsEvent);	
	        	// PUBLISHING TO RESPONSE QUEUE
	        	messageSender.send(exchangeResponse,routingkeyResponse,isPersistent, jsonUtility.getJsonStringFromObject(emoneyClientResponseResult));
			
		} catch (SendToExchangeException e){
			analyticsEvent.setStatus(EnumEventCurrentStatus.CALLTOEMX.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.ERROR.toString());
			eventPublisher.publish(analyticsEvent);					
			throw e;
		} catch (Exception e) {
			analyticsEvent.setStatus(EnumEventCurrentStatus.CALLTOEMX.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.ERROR.toString());
			eventPublisher.publish(analyticsEvent);		
			throw new DataPublishingException(e);
		}
    	logger.info("*********** END OF ClientRequest *************");
    }

	void createOrUpdateSfEmxIDLog(SfEmxIdLog mappingObject, String operation) {
		List<SfEmxIdLog> sfIdList = null;
		if(operation.equals(MessageType.CREATE.toString())){
			if(mappingObject.getSfId()!=null){
				sfIdList = this.sfEmxIdLogRepository.findBySFID(mappingObject.getSfId());
			}
		}else{
			if(mappingObject.getSfId()!=null){
				sfIdList = this.sfEmxIdLogRepository.findBySFID(mappingObject.getSfId());
			}
		}
		
		if(sfIdList!=null && !sfIdList.isEmpty()){
			//update
			SfEmxIdLog sfemxdbObject = sfIdList.get(0);
			savetoDbSFEMXLog(mappingObject, sfemxdbObject);
		}else{
			//create
			SfEmxIdLog sfemxdbObject = new SfEmxIdLog();
			savetoDbSFEMXLog(mappingObject, sfemxdbObject);
		}
		
	}

	private void savetoDbSFEMXLog(SfEmxIdLog mappingObject, SfEmxIdLog sfemxdbObject) {
		sfemxdbObject.setEmxId(mappingObject.getEmxId());			
		sfemxdbObject.setEntityType(mappingObject.getEntityType());			
		sfemxdbObject.setMessageId(mappingObject.getMessageId());
		sfemxdbObject.setSfId(mappingObject.getSfId());
		sfemxdbObject.setSfofficeId(mappingObject.getSfofficeId());
		sfemxdbObject.setSforgId(mappingObject.getSforgId());	
		SfEmxIdLog entityMappingSaved = this.sfEmxIdLogRepository.saveAndFlush(sfemxdbObject);
		logger.info("DB Object: "+entityMappingSaved.toString());
	}
    
    //v1/salesforce/clients/{clientId}?trackingId={XXXXXX}&orgId={OOOOO}&offfice={YYYYY}
    
    /**
     * 
     * @param queueName
     * @param emoneyClientRequestV2
     * @param analyticsEvent
     */
	public void deleteClientRequestProcessMessage(String queueName,
			EmxClientRequestV2 emoneyClientRequestV2, AnalyticsEventWrapper analyticsEvent) throws DataPublishingException, SendToExchangeException {
		logger.info("***    Inside deleteClientRequestProcessMessage :: "+emoneyClientRequestV2);
    	logger.info("***    Operation :: Delete");
    	//TODO what needs to be done with the trackingId={XXXXXX}&orgId={OOOOO}&offfice={YYYYY}  
    	try{
    		//PII DATA
    		SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl = (SfEmxClientPiiDataImpl ) piiDataLog;  
    		eventPublisher.publish(analyticsEvent);
    		sfEmxClientPiiDataImpl.setPiiData(null,null,emoneyClientRequestV2.getClients()[0].getId()); //Newly Added
    	
    		analyticsEvent.processing(EnumEventCurrentStatus.CALLTOEMX);
        	eventPublisher.publish(analyticsEvent);
        	logger.info("*** EVENT Publish:: "+analyticsEvent);
        	
        	//DB
        	//mappingObject.setMessageId(sfClientRequestObj.getClients()[0].getMessageID());  
        	SfEmxIdLog mappingObject = new SfEmxIdLog();
        	mappingObject.setSfofficeId(emoneyClientRequestV2.getClients()[0].getMetadata().getOffice());
        	mappingObject.setSforgId(emoneyClientRequestV2.getClients()[0].getMetadata().getOrgId());
        	mappingObject.setEntityType("SF");
        	
    		// net to replace sfClientRequestObj.getClients()[0].getId() with saleforce id
    		// LRD always have office ID
    		String office = emoneyClientRequestV2.getClients()[0].getMetadata().getOffice();
    		Map<String, String> headers = accessTokenHeaderGenerator.getEmoneyAccessTokenHeaders(office);
    		String url = emoneyserviceurl+clientDeleteContext;	  
    		
			Map<String, Object> requestParamsValues = new HashMap<String,Object>();
			requestParamsValues.put("clientId", emoneyClientRequestV2.getClients()[0].getId());

	    	Object result = httpExchangeService.sendToExchange(
					SourceSystem.SALESFORCE, 
					queueName, 
					url, 
					HttpMethod.DELETE, 
					headers, 
					null,
					requestParamsValues);
	    	
			analyticsEvent.setSrcValue(EnumEventSourceNDestination.EMX);
        	analyticsEvent.setDestinationValue(EnumEventSourceNDestination.RMQ);
        	
			analyticsEvent.success(EnumEventCurrentStatus.RECEIVED);
        	eventPublisher.publish(analyticsEvent);

    	}  
		catch (SendToExchangeException e)
		{
			analyticsEvent.setStatus(EnumEventCurrentStatus.CALLTOEMX.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.ERROR.toString());
			eventPublisher.publish(analyticsEvent);	
			throw e;
		}
		catch (Exception e) {
			analyticsEvent.setStatus(EnumEventCurrentStatus.CALLTOEMX.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.ERROR.toString());
			eventPublisher.publish(analyticsEvent);	
			throw new DataPublishingException(e);
		}
   	
    	logger.info("*********** END OF ClientRequest *************");		
	}
    /**
     * 
     * @param queueName
     * @param emoneyClientResponseResult
     * @param analyticsEvent
     */
    public void createOrUpdateClientResponseProcessMessage( String queueName,
    		EmxClientResponse emoneyClientResponseResult, AnalyticsEventWrapper analyticsEvent) throws DataPublishingException, SendToExchangeException {
		try {
			eventPublisher.publish(analyticsEvent);
			String sfEntity = repository.findSfEntity(emoneyClientResponseResult.getOrgId(), "Client");
			Map<String,String>headers = sFTokenUtil.getSaleforceAccessTokenHeaders(emoneyClientResponseResult.getOrgId());
			headers.forEach((s, s2) -> logger.info("Key" + s + "**** " + "value " + s2));			
	
			analyticsEvent.setStatus(EnumEventCurrentStatus.SENDING_FOR_ACK.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.PROCESSING.toString());
			eventPublisher.publish(analyticsEvent);
			
			Acknowledgement acknowledgement =new Acknowledgement();
			acknowledgement.seteMoney_Id__c(emoneyClientResponseResult.getId());
			String sfId = emoneyClientResponseResult.getSfClientId();
			// url for ack SF/services/data/v42.0/sobjects/{Account Object}/{Client Salesforce Id}'
			String url =sFTokenUtil.getSaleforceUrl(emoneyClientResponseResult.getOrgId())+sfUrlContext;//+sfEntity+"/"+sfId;
			
			Map<String, Object> requestParamsValues = new HashMap<String,Object>();
			requestParamsValues.put("entity", sfEntity);
			requestParamsValues.put("id", sfId);
			
	    	Object result = httpExchangeService.sendToExchange(
					SourceSystem.SALESFORCE, 
					queueName, 
					url, 
					HttpMethod.PATCH, 
					headers, 
					jsonUtility.getJsonStringFromObject(acknowledgement),
					requestParamsValues);
	    	
	    	eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.SENDING_FOR_ACK));
		} catch (SendToExchangeException e) {
			analyticsEvent.setStatus(EnumEventCurrentStatus.SENDING_FOR_ACK.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.ERROR.toString());
			eventPublisher.publish(analyticsEvent);	
			throw e;
		} catch (Exception e) {
			analyticsEvent.setStatus(EnumEventCurrentStatus.SENDING_FOR_ACK.toString());
			analyticsEvent.setStatus(EnumEventFinalStatus.ERROR.toString());
			eventPublisher.publish(analyticsEvent);	
			throw new DataPublishingException(e);
		}
		logger.info("*********** END OF ResponseProcess *************");
    }
    /**
     * 
     * @param sfClientRequest
     * @param operation
     * @return
     */
    EmxClientRequest transformSfclient2EmoneyClient(SfClientRequest sfClientRequest, MessageType operation) {
		EmxClientRequest emoneyclient = null;
		logger.info("*** Inside Transformation  for operation :"+operation);		
		List<EmxClientRequest> listEMoney = sfToEMoneyRequest.transformObject(sfClientRequest,operation);
		emoneyclient = listEMoney.get(0);		
		return emoneyclient;		
	}
}
