package com.integration.common.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * A sample class for adding error information in the response
 */

public class RestErrorInfo {
	
	@JsonProperty("code")
    public int code;
	
	@JsonProperty("message")
    public String message;

    public RestErrorInfo(String exceptionString, Exception ex, int code) {
        this.message = exceptionString+"<<>> :"+ex.getLocalizedMessage();
        this.code = code;
    }
    
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
