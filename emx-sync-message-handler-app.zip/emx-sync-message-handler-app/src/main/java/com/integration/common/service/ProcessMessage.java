package com.integration.common.service;

import com.integration.bean.common.MessageType;

public interface ProcessMessage {

	/**
	 * 
	 * @param type
	 * @param message
	 * @throws Exception
	 */
	public void processMessage(String queueName, MessageType type, String message) ;
	/**
	 * 
	 * @param queueName
	 * @param type
	 * @param message
	 */
	public void processMessage(String queueName, MessageType type, Object message) ;
}
