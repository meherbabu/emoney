package com.integration.common.service;

import java.util.Map;

public interface AccessTokenGenerator {

	/**
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	Map<String, String> getSaleforceAccessTokenHeaders(String orgId) throws Exception;

	/**
	 * @param params
	 * @return
	 * @throws Exception
	 */
	Map<String, String> getEmoneyAccessTokenHeaders(String emoneyId) throws Exception;

	/**
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	Map<String, String> getSaleforceAccessTokenHeadersUsingEmoneyOffice(String emxOffice) throws Exception;

	/**
	 * 
	 * @param orgId
	 * @return
	 * @throws Exception
	 */
	String getSaleforceUrl(String orgId) throws Exception;
	/**
	 * 
	 * @param emxOffice
	 * @return
	 * @throws Exception
	 */
	String getSaleforceUrlUsingEmoney(String emxOffice) throws Exception ;

	/**
	 * 
	 * @param emoneyId
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getEmoneyAccessAdminTokenHeaders(String emoneyId) throws Exception ;

}