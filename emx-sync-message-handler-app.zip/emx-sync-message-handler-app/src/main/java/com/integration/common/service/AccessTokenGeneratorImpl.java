
package com.integration.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.integration.configuration.EmxAccessTokenHeaderProperties;
import com.integration.configuration.EmxAccessTokenParamsProperties;
import com.integration.configuration.SfAccessTokenHeaderProperties;
import com.integration.configuration.SfAccessTokenParamsProperties;
import com.integration.dao.CredentialService;
import com.integration.service.LoggerUtil;
import com.integration.service.token.JWTTokenGenerator;
import com.integration.service.token.JWTTokenParams;
import com.integration.service.token.PostForAccessToken;

@Service
public class AccessTokenGeneratorImpl implements AccessTokenGenerator {
	Log logger = LoggerUtil.getLog(this);

	//@Value("${jwttoken.emoney.url}")
	String emoneyUrl;

	//@Value("${jwttoken.saleforce.url}")
	String sfUrl;

	private static final String EMONEY = "Emoney";
	private static final String SALEFORCE = "Saleforce";

	private PostForAccessToken postForAccessToken;

	private JWTTokenGenerator jWTTokenGenerator;

	private SfAccessTokenHeaderProperties sFAccessTokenHeaderProperties;

	private SfAccessTokenParamsProperties sFAccessTokenParamsProperties;

	private EmxAccessTokenHeaderProperties emoneyAccessTokenHeaderProperties;

	private EmxAccessTokenParamsProperties emoneyAccessTokenParamsProperties;

	private CredentialService credentialService;

	@Autowired
	public AccessTokenGeneratorImpl(SfAccessTokenHeaderProperties sFAccessTokenHeaderProperties,
			SfAccessTokenParamsProperties sFAccessTokenParamsProperties,
			EmxAccessTokenHeaderProperties emoneyAccessTokenHeaderProperties,
			EmxAccessTokenParamsProperties emoneyAccessTokenParamsProperties, CredentialService credentialService,
			PostForAccessToken postForAccessToken, JWTTokenGenerator jWTTokenGenerator

	) {
		this.sFAccessTokenHeaderProperties = sFAccessTokenHeaderProperties;
		this.sFAccessTokenParamsProperties = sFAccessTokenParamsProperties;
		this.emoneyAccessTokenHeaderProperties = emoneyAccessTokenHeaderProperties;
		this.emoneyAccessTokenParamsProperties = emoneyAccessTokenParamsProperties;
		this.credentialService = credentialService;
		this.postForAccessToken = postForAccessToken;
		this.jWTTokenGenerator = jWTTokenGenerator;

	}

	/**
	 *
	 * @param orgId
	 * @return
	 * @throws Exception
	 */
//	@Cacheable(cacheNames = "getTokenHeaders")
	protected Map<String, String> getTokenHeaders(String orgId) throws Exception {
		JWTTokenParams params = credentialService.getTokenParams(orgId);
		return getSaleforceAccessToken(params, orgId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.integration.util.AccessTokenGeneratorImpl#getSaleforceAccessTokenHeaders(
	 * java.lang.String)
	 */
	@Override
	@Cacheable(cacheNames = "getSaleforceAccessTokenHeaders")
	public Map<String, String> getSaleforceAccessTokenHeaders(String orgId) throws Exception {
		JWTTokenParams params = credentialService.getTokenParams(orgId, SALEFORCE);
		return getSaleforceAccessToken(params, orgId);
	}

	@Override
	@Cacheable(cacheNames = "getSaleforceUrl")
	public String getSaleforceUrl(String orgId) throws Exception {
		JWTTokenParams params = credentialService.getTokenParams(orgId, SALEFORCE);
		return params.getUrl();
	}

	@Override
	@Cacheable(cacheNames = "getSaleforceUrlUsingEmoney")
	public String getSaleforceUrlUsingEmoney(String emxOffice) throws Exception {
		String orgId = credentialService.getAppIdUsingEmxOffice(emxOffice);
		JWTTokenParams params = credentialService.getTokenParams(orgId, SALEFORCE);
		return params.getUrl();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.integration.util.AccessTokenGeneratorImpl#getEmoneyAccessTokenHeaders(
	 * java.lang.String)
	 */
	@Override
	@Cacheable(cacheNames = "getEmoneyAccessTokenHeaders")
	public Map<String, String> getEmoneyAccessTokenHeaders(String emoneyId) throws Exception {

		JWTTokenParams params = credentialService.getTokenParams(emoneyId, EMONEY);
		if (!StringUtils.isEmpty(params.getAccessToken())) {
			return getLocalHeadersWithBearierToker(params.getAccessToken());
		}
		return getEmoneyAccessToken(params);
	}
	
	@Override
	@Cacheable(cacheNames = "getEmoneyAccessAdminTokenHeaders")
	public Map<String, String> getEmoneyAccessAdminTokenHeaders(String emoneyId) throws Exception {

		JWTTokenParams params = credentialService.getTokenParams(emoneyId, EMONEY);
		if (!StringUtils.isEmpty(params.getAdminToken())) {
			return getLocalHeadersWithBearierToker(params.getAdminToken());
		}
		return getEmoneyAccessToken(params);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.integration.util.AccessTokenGeneratorImpl#
	 * getSaleforceAccessTokenHeadersUsingEmoneyOffice(java.lang.String)
	 */
	@Override
	@Cacheable(cacheNames = "getSaleforceAccessTokenHeadersUsingEmoneyOffice")
	public Map<String, String> getSaleforceAccessTokenHeadersUsingEmoneyOffice(String emxOffice) throws Exception {
		String orgId = credentialService.getAppIdUsingEmxOffice(emxOffice);
		JWTTokenParams params = credentialService.getTokenParams(orgId, SALEFORCE);
		return getSaleforceAccessToken(params, orgId);
	}

	@CacheEvict(value = { "getTokenHeaders", "getSaleforceAccessTokenHeaders", "getEmoneyAccessTokenHeaders",
			"getSaleforceAccessTokenHeadersUsingEmoneyOffice",
			"getEmoneyAccessTokenHeadersUsingSaleforce" ,"getSaleforceUrl","getSaleforceUrlUsingEmoney","getEmoneyAccessAdminTokenHeaders"}, allEntries = true)
	@Scheduled(fixedDelayString = "${jwttoken.cacheRefreshInMilliSeconds:120000}", initialDelay = (60000 * 2))
	public void clearAllCaches() {
		logger.info("Clearing all cache");
	}

	/**
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	private Map<String, String> getSaleforceAccessToken(JWTTokenParams params, String orgId) throws Exception {

		Map<String, String> headers;
		try {
			logger.info ("JWT token Params -->");
			
			String token = jWTTokenGenerator.getSFJwtToken(params);

			logger.info ("JWT token  -->" + token);
						
			Map<String, String> paramsValuesMap = new HashMap<String, String>();
			sFAccessTokenParamsProperties.getParamsValues().forEach((k, v) -> {
				paramsValuesMap.put(k, v);
			});
			paramsValuesMap.put("assertion", token);

			Map<String, String> headersMap = sFAccessTokenHeaderProperties.getHeaders();
			// Call Access Token URL
			sfUrl = getSaleforceUrl(orgId) + "/services/oauth2/token";
            logger.info ("### Salesforce URL to get access token :: "+ sfUrl);

			Map<String, Object> response = postForAccessToken.getSaleforceAccessToken(sfUrl, headersMap,
					paramsValuesMap);
			logger.info("Access Token " + response);

			StringBuffer buffer = new StringBuffer();
			buffer.append(response.get("token_type")).append(" ").append(response.get("access_token"));

			headers = new HashMap<String, String>();
			headers.put("Authorization", buffer.toString());
			headers.put("Content-Type", "application/json");
			headers.put("accept", "application/json");

		} catch (Exception e) {
			logger.error("Exception in getSaleforceAccessToken ", e);
			throw e;
		}
		logger.info("getSaleforceAccessToken header " + headers);

		return headers;
	}

	/**
	 * 
	 * @return
	 */
	private Map<String, String> getDefaultLocalHeaders() {
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Accept", "application/json");
		return headers;
	}

	/**
	 * 
	 * @return
	 */
	private Map<String, String> getLocalHeadersWithBearierToker(String token) {
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Accept", "application/json");
		headers.put("Authorization", "Bearer " + token);

		return headers;
	}

	/**
	 * 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	private Map<String, String> getEmoneyAccessToken(JWTTokenParams params) throws Exception {

		Map<String, String> headers;
		try {
			String token = jWTTokenGenerator.getSFJwtToken(params);
			Map<String, String> paramsValuesMap = new HashMap<String, String>();
			emoneyAccessTokenParamsProperties.getParamsValues().forEach((k, v) -> {
				paramsValuesMap.put(k, v);
			});
			paramsValuesMap.put("client_assertion", token);

			Map<String, String> headersMap = emoneyAccessTokenHeaderProperties.getHeaders();

			emoneyUrl = params.getAud();//+"/connect/token";
			Map<String, Object> response = postForAccessToken.getEmoneyAccessToken(emoneyUrl, headersMap,
					paramsValuesMap);

			logger.info("Access Token " + response);

			StringBuffer buffer = new StringBuffer();
			buffer.append(response.get("token_type")).append(" ").append(response.get("access_token"));

			headers = new HashMap<String, String>();
			headers.put("Authorization", buffer.toString());
			headers.put("Content-Type", "application/json");
			headers.put("accept", "application/json");
		} catch (Exception e) {
			logger.error("Exception in getEmoneyAccessToken ", e);
			throw e;
		}
		logger.info(" getEmoneyAccessToken token " + headers);
		return headers;
	}

}
