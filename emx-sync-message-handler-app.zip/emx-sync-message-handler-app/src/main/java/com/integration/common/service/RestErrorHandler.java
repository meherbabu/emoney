package com.integration.common.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

public class RestErrorHandler implements ResponseErrorHandler {
	  private static Logger logger = LoggerFactory.getLogger(RestErrorHandler.class);
 

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
    	logger.error("Response error: {} {}", response.getStatusCode(), response.getBody());    	
    }
 
    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {    	
        return (false); 
    }


}
