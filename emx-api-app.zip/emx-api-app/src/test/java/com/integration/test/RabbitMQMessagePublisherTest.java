package com.integration.test;

/**
 *  The purpose of this class is to publish a message to Rabbit MQ and then query for it
 *  POST to publish a message
 *  GET to Query the same message
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = Application.class)
//@ActiveProfiles("dev")
public class RabbitMQMessagePublisherTest {

   /* @Autowired
    RabbitTemplate rabbitTemplate;

    @org.junit.Test
    public void publish () {
        String message = null ;
        if ( message == null ) {
            message = "{testmessage: 'This is a test'" + (new Random().toString())
                    + "}";
        }
        rabbitTemplate.setExchange("test");
        rabbitTemplate.setRoutingKey("test");
        rabbitTemplate.convertAndSend(message);
        rabbitTemplate.convertAndSend( (new Random()).toString() );
    }*/


}
