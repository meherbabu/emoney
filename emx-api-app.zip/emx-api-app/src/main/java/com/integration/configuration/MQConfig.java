package com.integration.configuration;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author vdomala
 * 
 *         Config file for the RabbitMQ Server. This file holds Exchange, Queues
 *         and RoutingKey information. It Creates the abstraction Template to
 *         interact with RabbitMQ Server. Make sure you provide all the
 *         information in application.yml file.
 *
 */
@Configuration
public class MQConfig {

	private Log logger = LogFactory.getLog("com.integration.configuration");
	
	@Value("${mq.config.queues.durability: false}")
	private boolean isQueuesDurable;
	
	@Value("${mq.config.exchange.durability: false}")
	private boolean isExchangeDurable;
	
	private boolean isAutoDelete = false;

	public final static String EXCHANGE_NAME = "com.emx.integration";

	@Bean
	public Queue queue() {
		return new Queue("temp1", isQueuesDurable);
	}

	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	@Bean
	public AmqpTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
		final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		rabbitTemplate.setChannelTransacted(true);
		return rabbitTemplate;
	}

	@Bean
	RabbitAdmin rabbitAdmin(ConnectionFactory connectionFactory) {
		return new RabbitAdmin(connectionFactory);
	}

	@Bean
	TopicExchange exchange(RabbitAdmin rabbitAdmin) {

		TopicExchange exchange2 = new TopicExchange("com.emx.integration", isExchangeDurable, isAutoDelete);
		rabbitAdmin.declareExchange(exchange2);
		logger.info("Declared Exchange : [com.emx.integration]");

		String[] orgs = new String[] { "sf", "emx" };
		String[] entities = new String[] { "client", "alert", "task", "notes" };
		String[] operations = new String[] { "create", "update", "delete" };

		for (String org : orgs) {
			for (String entity : entities) {
				for (String op : operations) {
					Queue queue1 = new Queue(org + "." + entity + "." + op, isQueuesDurable);
					rabbitAdmin.declareQueue(queue1);
					logger.info("Declared Queue [" + org + "." + entity + "." + op + "]");
					rabbitAdmin.declareBinding(
							BindingBuilder.bind(queue1).to(exchange2).with(org + "." + entity + "." + op));
					logger.info("Bound Queue [" + org + "." + entity + "." + op + "] to Using Routing Key [" + org + "."
							+ entity + "." + op + "]");
				}
			}
		} // end of for loop
		return exchange2;

	}/// end of exchange

}