package com.integration.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.integration.service.AnalyticsProperties;

@Component
@ConfigurationProperties(prefix = "analytics")

public class AnalyticsPropertiesImpl implements AnalyticsProperties {

	private Map<String, ArrayList<String>> events = new HashMap<String, ArrayList<String>>();

	@Override
	public Map<String, ArrayList<String>> getEvents() {
		return events;
	}

	public void setEvents(Map<String, ArrayList<String>> events) {
		this.events = events;
	}

}
