package com.integration.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.integration.util.controller.CommonValidation;

@Configuration
public class Common {
	
	CommonValidation commonValidation;
	
	@Autowired
	public Common(CommonValidation commonValidation) {
		this.commonValidation = commonValidation;
	}
	
	@Bean (name="CommonValidation")
	public CommonValidation getCommonValidation ()
	{
		return commonValidation;
	}


}
