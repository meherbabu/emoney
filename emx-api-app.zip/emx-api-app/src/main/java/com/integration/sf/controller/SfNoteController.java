package com.integration.sf.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

@RestController
@RequestMapping(value = "${sf.context.notes}")
public class SfNoteController extends AbstractRestHandler<Object> {

	private ProcessMessageInterface sfNotesService;
	
	@Autowired
	public SfNoteController(@Qualifier ("SfNotesImpl") ProcessMessageInterface sfNotesService) {
		this.sfNotesService = sfNotesService;
	}

	/**
	 *
	 * @param message
	 * @return
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 */
	@PostMapping(
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = { APPLICATION_JSON_VALUE })
	public ResponseEntity<?> createNote(@RequestBody String message) throws DataPublishingException, DataValidationException{

		log.info("***********Inside SF notes Controller from SF to EMX flow************");
		sfNotesService.create(message, null);
		log.info("***********Inside SF notes Controller from SF to EMX flow************");		
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received create Notes"),
				HttpStatus.CREATED);

	}

	/**
	 *
	 * @param message
	 * @return
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 */
	@RequestMapping(method = RequestMethod.PUT, 
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> updateNote(@RequestBody String message) throws DataPublishingException, DataValidationException{

		log.info("Start SFNoteController.updateNote");
		sfNotesService.update(message, null);
		log.info("End SFNoteController.updateNote");

		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received update Notes request"),
				HttpStatus.OK);
	}

	// https://IntegrationServer/clients/{clientId}/notes/{noteId}?trackingId=xxxx
	@RequestMapping(value = "/clients/{eMoneyId}/notes/{eMoneyNoteId}",
					method = RequestMethod.DELETE, 
					produces = { APPLICATION_JSON_VALUE })
	public ResponseEntity<Object> deleteNotes(@PathVariable(value = "eMoneyId", required = true) String eMoneyId ,
											  @PathVariable(value = "eMoneyNoteId", required = true) String noteId,
											  @RequestParam(value = "office", required = true) String office,
											  @RequestParam(value = "orgId", required = true) String orgId,
											  @RequestParam(value = "trackingId", required = true) String trackingId) throws DataPublishingException, DataValidationException{
		
		log.info("Start SFNoteController.deleteNotes");		
		Map<String, String> map = new HashMap<String, String>();
		map.put("clientId", eMoneyId);
		map.put("noteId", noteId);
		map.put("trackingId", trackingId);
		map.put("orgId", orgId);
		map.put("office", office);
		sfNotesService.delete(null,map);		
		log.info("End SFNoteController.deleteNotes");
		//sfNotesService.deleteNotes(clientId, noteId, trackingId,orgId,office);
		return new ResponseEntity<Object>(
					new ResponseMessageBean("204", "IS has received delete Notes request"),
					HttpStatus.NO_CONTENT);
	}
}
	   
	

