package com.integration.sf.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.Id;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.sf.SfEmxNotesPiiDataImpl;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.common.service.SfNoteCommonService;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

@Service
@Qualifier ("SfNotesImpl")
public class SfNotesImpl implements  ProcessMessageInterface {

    Log log = LoggerUtil.getLog(this);

    @Value("${mq.sf.notes.create.exchange}")
    private String exchange;
    
    @Value("${mq.sf.notes.create.routingkey}")
    private String routingkey;
    
    @Value("${mq.sf.notes.create.persistence: false}")
    private boolean isSFCreateNotesPersistent;
    
    @Value("${mq.sf.notes.create.queue}")
    private String queue;
    
    @Value("${mq.sf.notes.update.exchange}")
    private String updateExchange;
    
    @Value("${mq.sf.notes.update.routingkey}")
    private String updateRoutingkey;
    
    @Value("${mq.sf.notes.update.persistence: false}")
    private boolean isSFUpdateNotesPersistent;
    
    @Value("${mq.sf.notes.update.queue}")
    private String updateQueue;
    
    @Value("com.emx.integration")
    private String deleteExchange;
    
    @Value("sf.notes.delete")
    private String deleteRoutingkey;
    
    @Value("${mq.sf.notes.delete.persistence: false}")
    private boolean isSFDeleteNotesPersistent;
    
    @Value("${validator.sf.notes.create.template.name}")
    private String createTemplateName;

    @Value("${validator.sf.notes.create.template.id}")
    private String createTemplateId;
    
    @Value("${validator.sf.notes.update.template.name}")
    private String updateTemplateName;
    
    @Value("${validator.sf.notes.update.template.id}")
    private String updateTemplateId;
    
    private MessageSender messageSender;
    
    
    private JsonValidator validator;
    
    private JsonUtility jsonUtility;
    
    private AnalyticsEventPublisher eventPublisher;
    
    private AnalyticsEventUtil analyticsEventUtil;
    
    private EmxToSfCommonUtil commonUtils;
    
    private SfNoteCommonService sfNoteCommonService;
    
    private PiiDataLog piiDataLog;
    
    @Autowired
	 public SfNotesImpl(
			 MessageSender messageSender,
			 JsonValidator validator,
			 JsonUtility jsonUtility,
			 AnalyticsEventPublisher eventPublisher,
			 AnalyticsEventUtil analyticsEventUtil,
			 EmxToSfCommonUtil commonUtils,
			 SfNoteCommonService sfNoteCommonService,
			 SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl
			 ) {
		this.messageSender = messageSender;
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.eventPublisher = eventPublisher;
		this.analyticsEventUtil = analyticsEventUtil;
		this.commonUtils = commonUtils;
		this.sfNoteCommonService = sfNoteCommonService;
		this.piiDataLog = sfEmxNotesPiiDataImpl;
	}
   
   
//    @Override
//    public void create(Object message, Map<String, String> params)
//    		throws DataPublishingException, DataValidationException {
//    	// TODO Auto-generated method stub
//    	
//    }
    
    @Override
    public void upcert(Object message, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
    	// TODO Auto-generated method stub
    	
    }
    @Override
    public void create(Object messagep, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
 
        log.info("***validating message ******");
        List<ErrorBean> errors = new ArrayList<>();
        try {
        
        	String message = String.valueOf(messagep);
            AnalyticsEventWrapper analyticsEvent = analyticsEventUtil.getEvent("sf-note-create");
			String trackingID = sfNoteCommonService.getMessageParamsFromMessage(message);
		
			analyticsEvent.setTrackingId(trackingID);
			eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.VALIDATING));
		 	SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
        	sfEmxNotesPiiDataImpl.setPiiData(null,null,null); //Newly added
        	
            errors = validator.validate(createTemplateId, createTemplateName, new ByteArrayInputStream(message.getBytes()));
            
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(analyticsEvent.error(EnumEventCurrentStatus.VALIDATING));
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			trackingID = sfNoteCommonService.getMessageParamsFromMessage(message);
            
			eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.VALIDATING));
			eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.TRANSFORMING));
            notesTransformation(message,analyticsEvent);
			eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.TRANSFORMING));
		    

        } 
        catch ( DataValidationException e)
        {
        	throw e;
        }
        catch (Exception e) {
            log.error("Exce"+ piiDataLog.logPiiData(), e);
            throw new DataPublishingException("Internal Error " + e.getMessage());
        }
    }
    
  
    
    @Override
    public void update(Object messagep, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
		log.info("Start SFNotesImpl.update");
		AnalyticsEventWrapper wrapper = null;

		try {
			SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
			String message = String.valueOf(messagep);
			String trackingId = commonUtils.getTrackingIdEmxClient(message);
			wrapper = analyticsEventUtil.getEvent("sf-note-update").setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			// Validate messages
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.VALIDATING).
					setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
			List<ErrorBean> errors = validator.validate(updateTemplateId, updateTemplateName, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.VALIDATING).
					setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
			log.info(" No Validation Errors.  Sending message to queue");
			
			// Slit message in two and send it one by one
			List<Object[]> splitMessage =  commonUtils.splitEmxNoteMessage(message);			
			for (Object[] objects : splitMessage) {
				eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.PUSHED_RMQ).
						setFinalStatusValue(EnumEventFinalStatus.PROCESSING).
						setClientIdValue(String.valueOf(objects[0])).
						setNoteIdValue(String.valueOf(objects[1])));
			//clientId,eMoneynotesid,noteid
	        sfEmxNotesPiiDataImpl.setPiiData(String.valueOf(objects[0]) ,String.valueOf(objects[2]) ,String.valueOf(objects[1])); //Newlyadded
	        	
	        	
				messageSender.send(updateExchange, updateRoutingkey, isSFUpdateNotesPersistent, String.valueOf(objects[2]));
				eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
			
			}
			// reset the message to Receive Status
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.RECEIVED)
					.setFinalStatusValue(EnumEventFinalStatus.SUCCESS).setMessageIdValue("").clearAdd());
			
			log.info("Sent message to queue");
	          
		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));			
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} 
		catch (Exception e) {
			log.error("Exception occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End SFNotesImpl.update");
		}
	}


    public void notesTransformation(String message,AnalyticsEventWrapper analyticsEvent) throws DataProcessingException{

		try {
			String value = null;
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = null;
			jsonNode = objectMapper.readTree(message);
			JsonNode nodes = jsonNode.withArray("notes");
			SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
			for (JsonNode node : nodes) {
				// removing notes list and adding single note to message
				((ObjectNode) jsonNode).remove("notes");
				((ObjectNode) jsonNode).set("notes", node);
				value = objectMapper.writeValueAsString(jsonNode);
				String clientId = jsonNode.get("notes").get("note").get("eMoneyId").asText();
				String noteId  = jsonNode.get("notes").get("note").get("noteId").asText();
				sfEmxNotesPiiDataImpl.setPiiData(clientId, null, noteId);
				analyticsEvent.setIds(new Id("eMoneyId", clientId, null));
				log.info("*******value after trim******" + value);
				log.info("*******Sending notes to queue**************" + jsonNode.toString());

				messageSender.send(exchange, routingkey, isSFCreateNotesPersistent, jsonNode.toString());
			}
			log.info("*****send all notes to Queue******");
		} catch (JsonProcessingException e) {
			throw new DataProcessingException("JsonProcessingException in notesTransformation " + e.getMessage());
		} catch (IOException e) {
			throw new DataProcessingException("IOException  in notesTransformation " + e.getMessage());

		} catch (Exception e) {
			throw new DataProcessingException("Exception  in notesTransformation " + e.getMessage());

		}
    }


	 @Override
	 public void delete(Object messagep, Map<String, String> params)
			 throws DataPublishingException, DataValidationException {
		 
		AnalyticsEventWrapper wrapper = null;
		try {
			SfEmxNotesPiiDataImpl sfEmxNotesPiiDataImpl = (SfEmxNotesPiiDataImpl) piiDataLog; 
			String clientId = params.get("clientId");
			String trackingId = params.get("trackingId");
			String orgId = params.get("orgId");
			String office = params.get("office");
			//String eMoneyNotesId = params.get("eMoneyNotesId");   //Newly added
			//String noteId = params.get("noteId");                 //Newlyadded
			sfEmxNotesPiiDataImpl.setPiiData(clientId, null, null);
			wrapper = analyticsEventUtil.getEvent("sf-note-delete").setClientIdValue(clientId)
					.setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper.processing());
			String message = jsonUtility.getJsonStringFromObject(params);
			//String message = String.valueOf(params);
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ));			
			messageSender.send(deleteExchange, deleteRoutingkey, isSFDeleteNotesPersistent, message);
			eventPublisher.publish(wrapper.success());
			
		
		} catch (Exception e) {
			log.error("Exception occurs in SfNotesImpl.delete"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End SfNotesImpl.delete");
		}
			
	}

//	@Override
//	public void upcert(SfNoteRequest sfNoteRequest, OperationTypes operationType)
//			throws DataValidationException, DataProcessingException, DataPublishingException{
//
//		log.info("***validating SalesforceNoteRequest ******");
//
//		List<ErrorBean> errors = new ArrayList<>();
//		try {
//
//			AnalyticsEventWrapper analyticsEvent = ((operationType == OperationTypes.UPDATE)
//					? analyticsEventUtil.getEvent("sf-note-update")
//					: analyticsEventUtil.getEvent("sf-note-create"));
//
//			errors = validator.validate(updateTemplateId, updateTemplateName,
//					new ByteArrayInputStream(jsonUtility.getJsonStringFromObject(sfNoteRequest).getBytes()));
//
//			if (!CollectionUtils.isEmpty(errors)) {
//				log.info("Validation errors : message(s)" + errors);
//				eventPublisher.publish(analyticsEvent.error(EnumEventCurrentStatus.VALIDATING));
//				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
//			}
//			eventPublisher.publish(analyticsEvent.success());
//			if (errors == null || errors.isEmpty()) {
//				this.messageSplitSendtoRMQ(sfNoteRequest, operationType, analyticsEvent);
//			} else {
//				log.info("Validation errors : message(s)" + errors);
//			}
//		} catch (Exception e) {
//			log.error("Exception ", e);
//			throw new DataValidationException("Exception Error " + e.getMessage());
//		}
//	}
//

    /**
     * @param sfNoteRequest
     * @param operationType
     * @throws DataPublishingException
     * @throws DataValidationException
     */
//	@Transactional
//	private void messageSplitSendtoRMQ(SfNoteRequest sfNoteRequest, OperationTypes  operationType, AnalyticsEventWrapper analyticsEvent)
//			throws DataProcessingException {
//		
//		// Validation Passed now split and publish to RMQ
//		try {
//			log.info("*** Splitting the request SFNoteRequest and calling Publisher for each Client ***");
//			for (SfNotesWrapper sfNotesWrapper : sfNoteRequest.getNotes()) {
//				
//				analyticsEvent.setClientId(sfNotesWrapper.getSfNote().geteMoneyId());
//				analyticsEvent.setNoteId(sfNotesWrapper.getSfNote().getNoteId());
//				log.info("*** EVENT Publish:: " + analyticsEvent);
//				eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.SPLITTING));
//
//				// Splitter
//				SfNoteRequest sfNoteRequestSplit = new SfNoteRequest();
//				sfNoteRequestSplit.setSourceSystem(sfNoteRequest.getSourceSystem());
//				sfNoteRequestSplit.setTrackingID(sfNoteRequest.getTrackingID());
//				List<SfNotesWrapper> sfNotesWrapperList = new ArrayList<SfNotesWrapper>();
//				sfNotesWrapperList.add(sfNotesWrapper);
//				sfNoteRequestSplit.setNotes(sfNotesWrapperList);
//
//				String message = jsonUtility.getJsonStringFromObject(sfNoteRequestSplit);
//				// publishing
//				if (operationType == OperationTypes.UPDATE) 
//				{
//					log.info("*** calling pubslisher for Update ***");
//					messageSender.send(updateExchange, updateRoutingkey,message);
//				}
//				eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.SPLITTING));
//			}
//		} catch (JsonProcessingException e) {
//			throw new DataProcessingException ("JsonProcessingException " + e.getMessage());
//		} catch (Exception e) {
//			throw new DataProcessingException ("Exception " + e.getMessage());
//		}
//	}

}

