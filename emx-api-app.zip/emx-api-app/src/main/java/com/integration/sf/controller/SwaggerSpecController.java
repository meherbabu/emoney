package com.integration.sf.controller;

import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.InputStream;


/**
 * Get swagger specs
 */

@RestController
@RequestMapping(value = "spec")
public class SwaggerSpecController {

    @GetMapping (value = "{specName}.json", produces = "application/json")
    @ResponseBody ()
    String getSwaggerSpec(@PathVariable String specName) {
        InputStream in = this.getClass().getResourceAsStream("/swaggerdocs/" + specName + ".json");
        StringBuffer stringBuffer = new StringBuffer("");
        int i = 0;
        try {
            i = in.read();

        while ( i != -1 ) {
            stringBuffer.append(Character.toChars(i));
            i = in.read();
        }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuffer.toString().trim();
    }

    @GetMapping (produces = "application/json")
    String[] getSpecResourecs() {
        String[] values ={
                "emx-sf-alerts-swagger.json",
                "emx-sf-client-swagger.json",
                "emx-sf-note-swagger.json",
                "emx-sf-tasks-swagger.json",
                "sf-emx-alert-swagger.json",
                "sf-emx-client-swagger.json",
                "sf-emx-metadata-mapping.json",
                "sf-emx-note-swagger.json",
                "sf-emx-onboarding.json",
                "sf-emx-tasks-swagger.json"
        } ;
        return values;
    }

}
