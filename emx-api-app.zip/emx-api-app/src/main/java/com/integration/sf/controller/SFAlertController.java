package com.integration.sf.controller;


import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

@RestController
@RequestMapping(value = "${sf.context.alerts}")
public class SFAlertController extends AbstractRestHandler<Object> {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    
    
    private ProcessMessageInterface alertService;
    
    @Autowired
    public SFAlertController(@Qualifier("SFAlertServiceImpl") ProcessMessageInterface alertService) {
    	this.alertService = alertService;
	}
    
    
    // /v1/salesforce/alerts/{alertId}/dismiss?trackingId={XXXXXX}&orgId={OOOOO}&offfice={YYYYY}
    @RequestMapping(value = "{alertId}/dismiss",
            method = RequestMethod.POST,
//            consumes = {APPLICATION_JSON_VALUE, TEXT_PLAIN_VALUE, "text/json"},
            produces = {APPLICATION_JSON_VALUE})
    public ResponseEntity<Object> updateAlert(@PathVariable(value = "alertId", required = true) String alertId,
                                              @RequestParam(value = "trackingId",required = true) String trackingId,
                                              @RequestParam(value = "orgId",required =true) String orgId,
                                              @RequestParam(value = "office" ,required = true) String office) throws DataPublishingException, DataValidationException{

    	Map<String, String> map = new HashMap<String, String>();
		map.put("alertId", alertId);
		map.put("trackingId", trackingId);
		map.put("orgId", orgId);
		map.put("office", office);
        alertService.update (null, map);
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received alert request."),
				HttpStatus.CREATED);
    }

}
