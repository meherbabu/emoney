package com.integration.sf.service;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.Id;
import com.integration.bean.common.OperationTypes;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.sf.SfEmxTasksPiiDataImpl;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.AnalyticsEventPublisherException;
//import com.integration.service.task.SFTaskMessageBrokerConfig;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

/**
 * this Services uses to process the SFTaskRequest and Splitting tasks.
 */
@Service
@Qualifier ("SfTaskServiceImpl")
public class SfTaskServiceImpl implements  ProcessMessageInterface {
	
    Log log = LoggerUtil.getLog(this);

    @Value("${mq.sf.task.create.queue}")
    public String queueName;
    @Value("${mq.sf.task.create.exchange}")
    public String createExchange;
    @Value("${mq.sf.task.create.routingkey}")
    public String creatRoutingkey;
    
    @Value("${mq.sf.task.create.persistence: false}")
    public boolean isSFCreateTaskPersistent;
    
    @Value("${mq.sf.task.update.queue}")
    public String updateQueue;
    @Value("${mq.sf.task.update.exchange}")
    public String updateExchange;
    @Value("${mq.sf.task.update.routingkey}")
    public String updateRoutingKey;
    @Value("${mq.sf.task.update.persistence: false}")
    public boolean isSFUpdateTaskPersistent;
    @Value("${mq.sf.task.delete.exchange}")
    public String deleteExchange;
    @Value("${mq.sf.task.delete.routingkey}")
    public String deleteRoutingkey;
    
    @Value("${mq.sf.task.delete.persistence: false}")
    public boolean isSFDeleteTaskPersistent;

    @Value("${validator.sf.task.create.template.name}")
    private String creatTemplateName;
    @Value("${validator.sf.task.update.template.name}")
    private String updateTemplateName;
    @Value("${validator.sf.task.update.template.id}")
    private String updateTemplateId;

    @Value("${validator.sf.task.create.template.id}")
    private String createTemplateId;

    private MessageSender messageSender;
    
    private AnalyticsEventPublisher eventPublisher;

    private JsonValidator validator;
    
	private AnalyticsEventUtil analyticsEventUtil;
    
	private JsonUtility jsonUtility;
	
	private PiiDataLog piiDataLog;
	
	
	
	@Autowired
    public SfTaskServiceImpl(MessageSender messageSender, AnalyticsEventPublisher eventPublisher,
			JsonValidator validator, AnalyticsEventUtil analyticsEventUtil, JsonUtility jsonUtility,
			SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl) {
		super();
		this.messageSender = messageSender;
		this.eventPublisher = eventPublisher;
		this.validator = validator;
		this.analyticsEventUtil = analyticsEventUtil;
		this.jsonUtility = jsonUtility;
		this.piiDataLog = sfEmxTasksPiiDataImpl ; 
	}

	@Override
    public void create(Object message, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
    	// TODO Auto-generated method stub
    	
    }
    
    @Override
    public void update(Object message, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
    }
    

    @Override
    public void upcert(Object messagep, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {

        log.info("*****Started Tasks service ****** ");
        List<ErrorBean> errors = new ArrayList<ErrorBean>();
        AnalyticsEventWrapper analyticsEvent = null;
        try {
        	SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl = (SfEmxTasksPiiDataImpl) piiDataLog;
        	String message = String.valueOf(messagep);
			OperationTypes operationType = OperationTypes.CREATE.toString()
					.equalsIgnoreCase(params.get("OperationTypes")) ? OperationTypes.CREATE : OperationTypes.UPDATE;
			analyticsEvent = ((operationType == OperationTypes.UPDATE)
					? analyticsEventUtil.getEvent("sf-task-update")
					: analyticsEventUtil.getEvent("sf-task-create"));
        	
            if (operationType == OperationTypes.CREATE)
            {
                errors = validator.validate(createTemplateId, creatTemplateName, new ByteArrayInputStream(message.getBytes()));
               // String clientId = params.get("clientId");  //Newly added
                //String assignedTo = params.get("assignedTo");  //Newly added 
                //sfEmxTasksPiiDataImpl.setPiiData(clientId,assignedTo); //Newly added 
            }
            else if (operationType == OperationTypes.UPDATE)
            {
                errors = validator.validate(updateTemplateId, updateTemplateName, new ByteArrayInputStream(message.getBytes()));
                //String clientId = params.get("clientId");  //Newly added
                //String assignedTo = params.get("assignedTo");  //Newly added 
                //sfEmxTasksPiiDataImpl.setPiiData(clientId,assignedTo); //Newly added 
            }
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(analyticsEvent.error(EnumEventCurrentStatus.VALIDATING));
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(analyticsEvent.success());
			
			splitterService(message, operationType, analyticsEvent);
            
        } catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EMXClientServiceImpl.create"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(analyticsEvent.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		}		

    }

    /**
     * 
     * @param message
     * @param operationType
     * @param analyticsEvent
     * @throws DataProcessingException
     */
	private void splitterService(String message, OperationTypes operationType, AnalyticsEventWrapper analyticsEvent)
			throws DataProcessingException {

		try {
			SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl = (SfEmxTasksPiiDataImpl) piiDataLog; //Newly added 
			eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.SPLITTING));
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(message);

			JsonNode nodes = jsonNode.withArray("tasks");
			for (JsonNode node : nodes) {
				// removing array of tasks and adding sings task to message
				((com.fasterxml.jackson.databind.node.ObjectNode) jsonNode).remove("tasks");
				((com.fasterxml.jackson.databind.node.ObjectNode) jsonNode).set("tasks", node);
				String value = objectMapper.writeValueAsString(jsonNode);
				String clientId = jsonNode.get("tasks").get("task").get("eMoneyId").asText();
				String assignedTo = jsonNode.get("tasks").get("task").get("assignedTo").asText();  //Newly added 
				sfEmxTasksPiiDataImpl.setPiiData(clientId, assignedTo);        //Newly added 
				log.info("*****Tasks ****" + value);
				analyticsEvent.setIds(new Id("eMoneyId", clientId, null));
				eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.PUSHED_RMQ));
				if (operationType == OperationTypes.CREATE) {
					log.info("*******Sending  tasks to createQueue**************");
					messageSender.send(createExchange, creatRoutingkey, isSFCreateTaskPersistent, value);
				} else if (operationType == OperationTypes.UPDATE) {
					log.info("*******sending tasks to UpdateQueue*********");
					messageSender.send(updateExchange, updateRoutingKey, isSFUpdateTaskPersistent, value);
				}
				eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.PUSHED_RMQ));
			}
			
			eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.SPLITTING));
			
		} catch ( Exception  e) {
			eventPublisher.publish(analyticsEvent.error(EnumEventCurrentStatus.PUSHED_RMQ));
			eventPublisher.publish(analyticsEvent.error(EnumEventCurrentStatus.SPLITTING));
			throw new DataProcessingException("Exception occurs in splitterService " + e.getMessage());
		}
		log.info("*****send all tasks to Queue******");
	}


    /**
     * @param param
     * @param operation
     * @throws DataPublishingException
     * @throws DataProcessingException
     * @throws DataValidationException
     */
    @Override
    public void delete(Object messagep, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {

        log.info("******* calling AMQ services to delete task**********");
        AnalyticsEventWrapper analyticsEvent = null;
        try {
        	SfEmxTasksPiiDataImpl sfEmxTasksPiiDataImpl = (SfEmxTasksPiiDataImpl) piiDataLog;
        	 analyticsEvent = analyticsEventUtil.getEvent("sf-task-delete");
 			eventPublisher.publish( analyticsEvent.processing());
 		    //String  clientId = params.get("clientId");    //Newly Added 
 		    //String  assignedTo = params.get("assignedTo");  //Newly Added 
 		    sfEmxTasksPiiDataImpl.setPiiData(null, null);  //Newly Added 
			String message = jsonUtility.getJsonStringFromObject(params);
 			eventPublisher.publish( analyticsEvent.processing(EnumEventCurrentStatus.PUSHED_RMQ));
			messageSender.send(deleteExchange, deleteRoutingkey, isSFDeleteTaskPersistent, message);
 			eventPublisher.publish( analyticsEvent.success());
			log.info(params);
			//param.forEach((s, s2) -> System.out.println("key =" + s + "value " + s2));
			log.info("sending params to AMQ service");
 			eventPublisher.publish( analyticsEvent.success(EnumEventCurrentStatus.RECEIVED));
 			
		} catch (JsonProcessingException | AnalyticsEventPublisherException e) {
			log.error("Exception occurs in EmxTaskServiceImpl.delete"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(analyticsEvent.error());
			throw new DataPublishingException("delete Error " + e.getMessage());
		}
    }
}

