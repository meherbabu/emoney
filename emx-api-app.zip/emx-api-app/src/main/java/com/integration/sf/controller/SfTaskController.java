package com.integration.sf.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.common.OperationTypes;
import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

@RestController
@RequestMapping(value = "${sf.context.tasks}")
public class SfTaskController extends AbstractRestHandler<Object> {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private ProcessMessageInterface sfTaskService;
    
	@Autowired
	public SfTaskController( @Qualifier ("SfTaskServiceImpl") ProcessMessageInterface sfTaskService) {
		this.sfTaskService = sfTaskService;
	}
     

    @RequestMapping(
    		method = RequestMethod.POST, 
    		consumes = {APPLICATION_JSON_VALUE}, 
    		produces = {APPLICATION_JSON_VALUE})
    
    public ResponseEntity<Object> create(@RequestBody String message) throws DataPublishingException, DataValidationException{
        log.info("****Inside the Tasks Controller****");

		Map<String, String> params = new HashMap<String, String>();
		params.put("OperationTypes", OperationTypes.CREATE.toString());

		sfTaskService.upcert(message, params);
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received create task request."),
				HttpStatus.CREATED);

   }

    @RequestMapping(
            method = RequestMethod.PUT,
            consumes = {APPLICATION_JSON_VALUE},
            produces = {APPLICATION_JSON_VALUE})
    public ResponseEntity<Object> update(@RequestBody String message) throws DataPublishingException, DataValidationException{
    	
		Map<String, String> params = new HashMap<String, String>();
		params.put("OperationTypes", OperationTypes.UPDATE.toString());

		sfTaskService.upcert(message, params);

		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received update task request."),
				HttpStatus.OK);

    }

    @RequestMapping(value = "/{eMoneyTaskId}",
            method = RequestMethod.DELETE,
            produces = {APPLICATION_JSON_VALUE})
    public ResponseEntity<Object> delete(@PathVariable(value = "eMoneyTaskId") String taskId,
                                         @RequestParam(value = "trackingId", required = true) String trackingId, 
                                         @RequestParam(value = "orgId", required = true) String orgId,
                                         @RequestParam(value = "office", required = true) String office) 
                                        		 throws DataPublishingException, DataValidationException{
		Map<String, String> map = new HashMap<String, String>();
		map.put("taskId", taskId);
		map.put("trackingId", trackingId);
		map.put("orgId", orgId);
		map.put("office", office);
		sfTaskService.delete(null, map);
        return new ResponseEntity<Object>(
                new ResponseMessageBean("204", "IS has received delete Task request"),
                HttpStatus.NO_CONTENT);
    }
}