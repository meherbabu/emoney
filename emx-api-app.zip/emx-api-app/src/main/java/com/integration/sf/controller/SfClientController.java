package com.integration.sf.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.common.OperationTypes;
import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "${sf.context.clients}")
public class SfClientController extends AbstractRestHandler<Object> {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	
	private ProcessMessageInterface clientService;

	@Autowired
	public SfClientController( @Qualifier ("SfClientServiceImpl") ProcessMessageInterface clientService) {
		this.clientService = clientService;
	}
   
    /**
     * 
     * @param sfClientRequest
     * @param request
     * @param response
     * @throws DataPublishingException
     * @throws DataProcessingException
     * @throws DataValidationException
     * @throws AnalyticsEventPublisherException 
     */
    @RequestMapping(
            method = RequestMethod.POST,
            consumes = {APPLICATION_JSON_VALUE},
            produces = {APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> createClient(@RequestBody String sfClientRequest) 
			            throws DataPublishingException, DataValidationException{
    	
		Map<String, String> params = new HashMap<String, String>();
		params.put("OperationTypes", OperationTypes.CREATE.toString());
	
    	clientService.upcert(sfClientRequest, params);
    	
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received Create Client "),
				HttpStatus.CREATED);
    	
    }


   @RequestMapping(
            method = RequestMethod.PUT,
            consumes = {APPLICATION_JSON_VALUE},
            produces = {APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> updateClient(@RequestBody String sfClientRequest)
            		 throws DataPublishingException, DataValidationException{
	   
		Map<String, String> params = new HashMap<String, String>();
		params.put("OperationTypes", OperationTypes.UPDATE.toString());
		clientService.upcert(sfClientRequest, params);
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received Update Client "),
				HttpStatus.OK);
    }
   
   /**
    *
    * @param request
    * @param response
    * @throws DataPublishingException
    * @throws DataProcessingException
    * @throws DataValidationException
 * @throws AnalyticsEventPublisherException 
    */
  @RequestMapping(
		   value="/{clientId}",
           method = RequestMethod.DELETE,
           produces = {APPLICATION_JSON_VALUE})
   @ResponseStatus(HttpStatus.NO_CONTENT)
   public ResponseEntity<?> deleteClient(
		   @PathVariable String clientId,
		   @RequestParam(value = "trackingId", required = true) String trackingId,
		  // @RequestParam(value = "orgId", required = true) String orgId,
		   @RequestParam(value = "office", required = true) String office)
        		   throws DataPublishingException, DataValidationException{
	   	log.info("*** Inside Delete Client Controller ***");
	   	
		Map<String, String> map = new HashMap<String, String>();
		map.put("clientId", clientId);
		map.put("trackingId", trackingId);
		//map.put("orgId", orgId);
		map.put("office", office);
	   	clientService.delete(null,map);
	   	
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.NO_CONTENT.toString(), "IS has received delete Client "),
				HttpStatus.NO_CONTENT);
	   	
   }
   
   @RequestMapping(method = RequestMethod.GET)
   @ResponseStatus(HttpStatus.FORBIDDEN)
   @ApiOperation(value = "Query for Sf Clients",
           notes = "Returns the status message of the new resource in the Location header.")
   public String query(HttpServletRequest request, HttpServletResponse response) 
		   throws DataPublishingException, DataProcessingException, DataValidationException {
       return "{message: GET is NOT ALLOWED}";
   }


    @RequestMapping(value = "/health",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Test", notes = "TEST")
    public
    @ResponseBody
    String getHeath(HttpServletRequest request, HttpServletResponse response) throws Exception {
        return "Salesfoce Client API Is UP";
    }
}
