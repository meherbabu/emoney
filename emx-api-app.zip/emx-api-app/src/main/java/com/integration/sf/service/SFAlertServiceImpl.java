package com.integration.sf.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.JsonUtility;
import com.integration.service.MessageSender;

@Service
@Qualifier ("SFAlertServiceImpl")
public class SFAlertServiceImpl implements  ProcessMessageInterface {

    @Value("${mq.sf.alert.update.exchange}")
    private String alertExchange;

    @Value("${mq.sf.alert.update.routingkey}")
    private String alertRoutingKey;
  

    @Value("${mq.sf.alert.update.persistence: false}")
    private boolean isSFUpdateAlertPersistent;
    
    Logger log = LoggerFactory.getLogger(SFAlertServiceImpl.class);
    
    private AnalyticsEventPublisher eventPublisher;

	private JsonUtility jsonUtility;

	private MessageSender mqSender;
 
	private AnalyticsEventUtil analyticsEventUtil;
	

	@Autowired
	public SFAlertServiceImpl(AnalyticsEventPublisher eventPublisher, JsonUtility jsonUtility, MessageSender mqSender,
			AnalyticsEventUtil analyticsEventUtil) {
		this.eventPublisher = eventPublisher;
		this.jsonUtility = jsonUtility;
		this.mqSender = mqSender;
		this.analyticsEventUtil = analyticsEventUtil;
	}


	@Override
	public void update(Object messagep, Map<String, String> params)
			throws DataPublishingException, DataValidationException {

		AnalyticsEventWrapper wrapper = null;
		try {
	  			
			wrapper = analyticsEventUtil.getEvent("sf-alert-create");
			wrapper.setTrackingIdValue(params.get("trackingId")).add("alertId", params.get("alertId"))
			.add("orgId", params.get("orgId")).add("office", params.get("office"));
			eventPublisher.publish(wrapper);
			String message = jsonUtility.getJsonStringFromObject(params);
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ));			
			mqSender.send(alertExchange, alertRoutingKey, isSFUpdateAlertPersistent, message);
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.PUSHED_RMQ));			
		} catch (Exception e) {
			log.error("Exception occurs in EmxTaskServiceImpl.delete", e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EmxTaskServiceImpl.delete");
		}
    }


    @Override
    public void create(Object message, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
    	// TODO Auto-generated method stub
    	
    }


	@Override
	public void upcert(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}
    
}
