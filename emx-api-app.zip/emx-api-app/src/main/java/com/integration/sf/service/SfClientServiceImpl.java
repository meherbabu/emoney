package com.integration.sf.service;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.Id;
import com.integration.bean.common.Metadata;
import com.integration.bean.common.OperationTypes;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.emx.EmxClientDataV2;
import com.integration.bean.emx.EmxClientRequestV2;
import com.integration.bean.sf.SfClientData;
import com.integration.bean.sf.SfClientRequest;
import com.integration.bean.sf.SfEmxClientPiiDataImpl;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidatorImpl;
import com.integration.service.validation.beans.ErrorBean;

/*
 * Service to Process a Create Clients Request From Sales Force
 */
@Service
@Qualifier ("SfClientServiceImpl")
public class SfClientServiceImpl implements  ProcessMessageInterface {

	Log log = LoggerUtil.getLog(this);

	@Value("${mq.sf.client.create.exchange}")
	private String exchange;

	@Value("${mq.sf.client.create.routingkey}")
	private String routingkey;
	
	@Value("${mq.sf.client.create.persistence: false}")
	private boolean isSFCreateClientPersistent;

	@Value("${mq.sf.client.update.exchange}")
	private String updateExchange;

	@Value("${mq.sf.client.update.routingkey}")
	private String updateRoutingkey;
	
	@Value("${mq.sf.client.update.persistence: false}")
	private boolean isSFUpdateClientPersistent;

	@Value("${mq.sf.client.delete.exchange}")
	private String deleteExchange;

	@Value("${mq.sf.client.delete.routingkey}")
	private String deleteRoutingkey;
	
	@Value("${mq.sf.client.delete.persistence: false}")
	private boolean isSFDeleteClientPersistent;


	private MessageSender mqSender;

	private AnalyticsEventPublisher eventPublisher;

	private JsonValidatorImpl validator;

	private JsonUtility jsonUtility;

	private AnalyticsEventUtil analyticsEventUtil;
	
	private SforgEmxoffMapRepository SforgEmxoffMapRepository;
	
	private PiiDataLog piiDataLog; 

	@Autowired
	public SfClientServiceImpl(MessageSender mqSender, AnalyticsEventPublisher eventPublisher,
			JsonValidatorImpl validator, JsonUtility jsonUtility, AnalyticsEventUtil analyticsEventUtil
			,SforgEmxoffMapRepository SforgEmxoffMapRepository,
			SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl) {
		this.mqSender = mqSender;
		this.eventPublisher = eventPublisher;
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.analyticsEventUtil = analyticsEventUtil;
		this.SforgEmxoffMapRepository = SforgEmxoffMapRepository;
		this.piiDataLog = sfEmxClientPiiDataImpl;
	}
	
	

	@Override
	public void create(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void update(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Create or Udpate a Client Request from Sales Force
	 *
	 * @param sfClientRequest
	 *            - Request From SF
	 * @param operationType
	 *            - Create or Update
	 * @throws DataValidationException
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	@Override
	public void upcert(Object messagep, Map<String, String> params)
				throws DataPublishingException, DataValidationException {

		AnalyticsEventWrapper wrapper = null;
		SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl = (SfEmxClientPiiDataImpl) piiDataLog; //Newly added 
		try {
	
    		 String message = String.valueOf(messagep);
    		 //String trackingId = params.get("trackingId");                       //Newly added    
    	    // sfEmxClientPiiDataImpl.setPiiData(trackingId, null, null); //Newly added
    		// 
			OperationTypes operationTypes = OperationTypes.CREATE.toString()
					.equalsIgnoreCase(params.get("OperationTypes")) ? OperationTypes.CREATE : OperationTypes.UPDATE;
    		
			
			wrapper = ((operationTypes == OperationTypes.UPDATE)
					? analyticsEventUtil.getEvent("sf-client-update")
					: analyticsEventUtil.getEvent("sf-client-create"));
			
			eventPublisher.publish( wrapper.processing());
			
			List<ErrorBean> errors = validator.validate("sf-create-client", new ByteArrayInputStream(message.getBytes()));

			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error(EnumEventCurrentStatus.VALIDATING));
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.success());	  
			
			SfClientRequest sfClientRequest = 
					(SfClientRequest)jsonUtility.getObjectFromJsonString(message, SfClientRequest.class);
			
			messageSplitSendtoRMQ(sfClientRequest, operationTypes, wrapper);
			
		} catch (DataValidationException e) {	
			log.error("DataValidationException occurs in SFClientServiceImpl.upsert"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in SFClientServiceImpl.upsert"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw new DataPublishingException("Internal Error " + e.getMessage());
		}finally {
			log.info("End SFClientServiceImpl.upsert");
		}		
	}


	/**
	 * 
	 * @param sfClientRequest
	 * @param operationType
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	void messageSplitSendtoRMQ(SfClientRequest sfClientRequest, OperationTypes opType,
			AnalyticsEventWrapper analyticsEvent) throws DataPublishingException, DataProcessingException,
			DataValidationException, AnalyticsEventPublisherException {
		// Validation Passed now split and publish to RMQ
		log.info("*** Splitting the request SFClientRequest and calling Publisher for each Client ***");

		try {
			eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.SPLITTING));
            
			for (SfClientData sfClientData : sfClientRequest.getClients()) {
				SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl = (SfEmxClientPiiDataImpl ) piiDataLog;  //Newlyadded
				sfEmxClientPiiDataImpl.setPiiData(sfClientData.getId(),sfClientData.getOwnerId(), sfClientData.geteMoneyId()); //Newlyadded
				analyticsEvent.setMessageId(sfClientData.getMessageID());
				if (opType == OperationTypes.CREATE) {
					analyticsEvent.setIds(new Id("SF_ID", sfClientData.getId(), null));
				} else {
					analyticsEvent.setIds(new Id("EMONEY_ID", sfClientData.geteMoneyId(), null));
				}
				log.info("*** EVENT Publish:: " + analyticsEvent);
				eventPublisher.publish(analyticsEvent);

				// Splitter
				SfClientRequest sfClientRequestSplit = new SfClientRequest();
				sfClientRequestSplit.setSourceSystem(sfClientRequest.getSourceSystem());
				sfClientRequestSplit.setTrackingID(sfClientRequest.getTrackingID());
				SfClientData[] clients = { sfClientData };
				// clients[0] = sfClientData;
				sfClientRequestSplit.setClients(clients);
				// validate
				validateIdForOperation(opType, sfClientData, sfClientRequestSplit);
				// publishing

				String	message = jsonUtility.getJsonStringFromObject(sfClientRequestSplit);
				eventPublisher.publish(analyticsEvent.processing(EnumEventCurrentStatus.PUSHED_RMQ));
				
				if (opType == OperationTypes.UPDATE) {
					log.info("*** calling pubslisher for Update ***::"+message);
					mqSender.send(updateExchange, updateRoutingkey, isSFUpdateClientPersistent, message);
				} else {
					log.info("*** calling pubslisher for Create ***:: "+message);
					mqSender.send(exchange, routingkey, isSFCreateClientPersistent, message);
				}
				eventPublisher.publish(analyticsEvent.success(EnumEventCurrentStatus.PUSHED_RMQ));
			}
			eventPublisher.publish(	analyticsEvent.success(EnumEventCurrentStatus.SPLITTING));		
		} catch (DataValidationException e) {
			log.error("Exception occurs in SFClientServiceImpl.upsert"+ piiDataLog.logPiiData(), e);
			throw e;
		} catch (Exception e) {
			throw new DataProcessingException ("*** Exception in SFClientServiceImpl.upser.messageSplitSendtoRMQ");
		}
	}
	/**
	 * 
	 * @param opType
	 * @param sfClientData
	 * @param sfClientRequestSplit
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
	private void validateIdForOperation(OperationTypes opType, SfClientData sfClientData,
			SfClientRequest sfClientRequestSplit)
			throws DataPublishingException, DataProcessingException, DataValidationException {
		if (opType == OperationTypes.UPDATE) {
			if ((sfClientData.geteMoneyId() != null)) {
				if (sfClientData.geteMoneyId().toString().trim() == "") {
					throw new DataValidationException(
							"eMoneyId is not valid, cannot be empty for UPDATE. MsgID:" + sfClientData.getMessageID());
				}
			} else {
				throw new DataValidationException(
						"Emoney ID is not valid, cannot be Null for Update. MsgID:" + sfClientData.getMessageID());
			}
			if ((sfClientData.getId() != null)) {
				if (sfClientData.getId().toString().trim() == "") {
					throw new DataValidationException(
							"ID [SFID] is not valid, cannot be empty for Update. MsgID:" + sfClientData.getMessageID());
				}
			} else {
				throw new DataValidationException(
						"ID [SFID] is not valid, cannot be Null for Update. MsgID:" + sfClientData.getMessageID());
			}
		} else if (opType == OperationTypes.CREATE) {
			if ((sfClientData.getId() != null)) {
				if (sfClientData.getId().toString().trim() == "") {
					throw new DataValidationException(
							"ID is not valid, cannot be empty for CREATE. MsgID:" + sfClientData.getMessageID());
				}
			} else {
				throw new DataValidationException(
						"ID is not valid, cannot be Null for Create. MsgID:" + sfClientData.getMessageID());
			}
		} else {
			throw new DataValidationException(
					"Recevied Wrong Operation, Its neither Create nor Update..!!. MsgID:" + sfClientData.getMessageID());
		}
	}

	@Override
	public void delete(Object messagep, Map<String, String> params) throws DataPublishingException, DataValidationException {
		
		AnalyticsEventWrapper wrapper = null;
		SfEmxClientPiiDataImpl sfEmxClientPiiDataImpl = (SfEmxClientPiiDataImpl) piiDataLog; 
		
		try {
			String orgId =null;
			String clientId = params.get("clientId");
			String trackingId = params.get("trackingId");
			//String orgId = params.get("orgId");
			String office = params.get("office");
			//String ownerId = params.get("ownerId"); //Newly added
			//String eMoneyId = params.get("eMoneyId"); //Newly added 
			sfEmxClientPiiDataImpl.setPiiData(trackingId,null,clientId); //Newlyadded
			if(office!=null){			
				orgId = this.SforgEmxoffMapRepository.findOrgId(office);
			}			
			params.put("orgId", orgId);
			wrapper = analyticsEventUtil.getEvent("sf-client-delete").setClientIdValue(clientId)
					.setTrackingIdValue(trackingId);
			eventPublisher.publish( wrapper.processing());

			// creating Object
			EmxClientRequestV2 emoneyClientRequestV2 = new EmxClientRequestV2();
      		EmxClientDataV2 emoneyClientDataV2 = new EmxClientDataV2();
			emoneyClientDataV2.setId(clientId);
			Metadata metadata = new Metadata();
			metadata.setOrgId(orgId);
			metadata.setOffice(office);
			emoneyClientDataV2.setMetadata(metadata);
		
			
			EmxClientDataV2[] clients = { emoneyClientDataV2 };
			emoneyClientRequestV2.setClients(clients);
			String message = jsonUtility.getJsonStringFromObject(emoneyClientRequestV2);
			eventPublisher.publish( wrapper.success());
			
		
			mqSender.send(deleteExchange, deleteRoutingkey, isSFDeleteClientPersistent, message);
		} catch (Exception e) {
			log.error("Exception occurs in SFClientServiceImpl.delete"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End SFClientServiceImpl.delete");
		}
	}

}
