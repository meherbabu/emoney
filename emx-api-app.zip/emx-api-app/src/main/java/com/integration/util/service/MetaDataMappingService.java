package com.integration.util.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.integration.bean.common.ConvertErrorBean;
import com.integration.common.bean.MetaDataMappingBean;
import com.integration.common.bean.MetaDataRootMappingBean;
import com.integration.dao.SfEmxHeaderMapRepository;
import com.integration.dao.SfEmxMappingRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.model.SfEmxHeaderMap;
import com.integration.model.SfEmxMapping;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

@Service
public class MetaDataMappingService {

	Log log = LoggerUtil.getLog(this);

	private JsonValidator validator;

	private JsonUtility jsonUtility;

	private SfEmxHeaderMapRepository sfEmxHeaderMapRepository;

	private SfEmxMappingRepository sfEmxMappingRepository;

	@Value("sf-meta-mapping")
	private String mappingId;

	@Autowired
	public MetaDataMappingService(JsonValidator validator, JsonUtility jsonUtility,
								  SfEmxHeaderMapRepository sfEmxHeaderMapRepository,
								  SfEmxMappingRepository sfEmxMappingRepository) {
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.sfEmxHeaderMapRepository = sfEmxHeaderMapRepository;
		this.sfEmxMappingRepository = sfEmxMappingRepository;

	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	public void create(String message) throws DataPublishingException, DataProcessingException, DataValidationException,
			AnalyticsEventPublisherException {
		validate(message);
		upcertDb(message);
	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	public StringBuffer get() throws DataPublishingException, DataProcessingException, DataValidationException,
			AnalyticsEventPublisherException {
		StringBuffer buffer = new StringBuffer();
		try {
			MetaDataRootMappingBean metaDataRootMappingBean = new MetaDataRootMappingBean();
			List<SfEmxHeaderMap> all = sfEmxHeaderMapRepository.findAll();
			for (SfEmxHeaderMap sf2EmxHeaderMapper : all) {

				MetaDataMappingBean bean = new MetaDataMappingBean();
				bean.setsF2EmxHeaderMapper(sf2EmxHeaderMapper);
				List<SfEmxMapping> mappingList = sfEmxMappingRepository
						.findAllByHeaderMapId(sf2EmxHeaderMapper.getId());
				bean.setSfEmxMapping(mappingList);
				metaDataRootMappingBean.getMappings().add(bean);

			}
			buffer.append(jsonUtility.getJsonStringFromObject(metaDataRootMappingBean));
		} catch (Exception e) {
			throw new DataProcessingException("Exception in getAlldata " + e.getMessage());
		}
		return buffer;
	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	private void upcertDb(String message) throws DataPublishingException, DataProcessingException,
			DataValidationException, AnalyticsEventPublisherException {

		try {
			MetaDataRootMappingBean metaDataRootMappingBean = (MetaDataRootMappingBean) jsonUtility.getObjectFromJsonString(message,
					MetaDataRootMappingBean.class);
			List<MetaDataMappingBean> mapping = metaDataRootMappingBean.getMappings();

			for (MetaDataMappingBean metaDataMappingBean_mappings : mapping) {

				SfEmxHeaderMap sfEmxHeaderMap = metaDataMappingBean_mappings.getsF2EmxHeaderMapper();
				List<SfEmxMapping> sfEmxMappingList = metaDataMappingBean_mappings.getSfEmxMapping();
				// look up and find header. if found , update it.
				SfEmxHeaderMap foundHeader = sfEmxHeaderMapRepository.findSfEntityObject(
						sfEmxHeaderMap.getSfOrg(),
						sfEmxHeaderMap.getEmxEntity());
				int recordCound = 0;

				if (foundHeader != null) {
					sfEmxHeaderMap.setId(foundHeader.getId());
					recordCound = sfEmxMappingRepository.deleteAllByHeaderMapId(foundHeader.getId());
					log.debug("Delete sfEmxMappingRepository count " + recordCound);

				}
				sfEmxHeaderMapRepository.save(sfEmxHeaderMap);
				for (SfEmxMapping sfEmxMapping : sfEmxMappingList) {

					sfEmxMapping.setSemId(sfEmxHeaderMap.getId());
					sfEmxMapping.setSfOrg(sfEmxHeaderMap.getSfOrg());
					sfEmxMapping.setEntity(sfEmxHeaderMap.getEmxEntity());
				}
				if (!sfEmxMappingList.isEmpty()) {
					sfEmxMappingRepository.saveAll(sfEmxMappingList);
				}

			}

		} catch (IOException e) {
			log.error("IOException ", e);
			throw new DataProcessingException("IOException " + e.getMessage());
		} catch (Exception e) {
			log.error("Exception ", e);
			throw new DataProcessingException("Exception " + e.getMessage());
		}

	}

	/**
	 * 
	 * @param templateId
	 * @param templateName
	 * @param exchange
	 * @param routingkey
	 * @param message
	 * @return
	 * @throws Exception
	 */
	private void validate(String message) throws DataValidationException, DataProcessingException,
			DataPublishingException, AnalyticsEventPublisherException {
		log.info("Start MetaDataMappingServiceImpl.validate");

		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		try {
			errors = validator.validate(mappingId, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			log.info(" No Validation Errors.  Sending message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End MetaDataMappingServiceImpl.validate");
		}

		return;
	}
}
