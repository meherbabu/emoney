package com.integration.util.controller;

import org.springframework.stereotype.Component;

import com.integration.dao.SforgEmxoffMapRepository;

@Component
public class CommonValidation {
	
	private SforgEmxoffMapRepository sforgEmxoffMapRepository;

	public CommonValidation(SforgEmxoffMapRepository sforgEmxoffMapRepository) {
		this.sforgEmxoffMapRepository = sforgEmxoffMapRepository;
	}
	/**
	 * 
	 * @param office
	 * @return
	 */
	public boolean isValidOffice (String office)
	{
		
		try {
			boolean map =  sforgEmxoffMapRepository.existsByEmxOffice(office);
			return map;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 *
	 * @param orgId
	 * @return
	 */
	public boolean isValidOrgId (String orgId)
	{
		
		try {
			boolean map =  sforgEmxoffMapRepository.existsByOrgId(orgId);			
			return (map);
			
		} catch (Exception e) {
			return false;
		}
	}

}
