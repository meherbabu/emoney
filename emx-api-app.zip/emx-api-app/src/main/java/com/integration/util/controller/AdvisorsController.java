package com.integration.util.controller;


import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.LoggerUtil;
import com.integration.util.service.AdvisorsService;


@RestController
@RequestMapping(value = "${util.context.advisors}")
public class AdvisorsController extends  AbstractRestHandler<Object> {

	private  Log log = LoggerUtil.getLog(this);
   
	private AdvisorsService advisorsService;

	@Autowired
	public AdvisorsController(AdvisorsService advisorsService) {
		this.advisorsService = advisorsService;
	}

    ///util/advisors?trackingId={XXXXXX}&orgId={OOOOO}
    @RequestMapping(
            method = RequestMethod.GET,
            produces = {APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Object> get(	@RequestParam(value = "trackingId",required = true) String trackingId, 
    									@RequestParam(value = "orgId",required = true) String orgId) throws DataPublishingException, DataValidationException {

        log.info("Start Advisors Controller.get");
        log.info("*** Inside Advisor Controller  trackingId ***[" + trackingId+"]");
        log.info("*** Inside Advisors Controller  office ***[" + orgId+"]");

        advisorsService.advisors(trackingId,orgId);

        return new ResponseEntity<Object>(new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received get Advisors request"),
                HttpStatus.OK);
    }


}
