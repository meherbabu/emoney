package com.integration.util.service;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidatorImpl;
import com.integration.service.validation.beans.ErrorBean;

@Service
public class AdvisorsService {

	private  Log log = LoggerUtil.getLog(this);

	
	@Value("${mq.sf.advisors.get.queue}")
    private String queueName;
    
    @Value("${mq.sf.advisors.get.exchange}")
    private String exchange;
    
    @Value("${mq.sf.advisors.get.routingkey}")
    private String routingkey;
    
    @Value("${mq.sf.advisors.get.persistence: false}")
    private boolean isPersistent;

    Map<String, String> params = new HashMap<>();

    @Value("${validator.sf.advisors.get.template.name}")
    private String templateName;

    @Value("${validator.sf.advisors.get.template.id}")
    private String templateId;
    
    
    private MessageSender messageSender;
    private AnalyticsEventUtil analyticsEventUtil;
    private AnalyticsEventPublisher eventPublisher;
    private JsonUtility jsonUtility;
    private JsonValidatorImpl validator;
    
    

    @Autowired
   public AdvisorsService(MessageSender messageSender, 
			AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher, JsonUtility jsonUtility,
			JsonValidatorImpl validator) {
		super();
		this.messageSender = messageSender;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.jsonUtility = jsonUtility;
		this.validator = validator;
	}


	/**
	 * 
	 * @param trackingId
	 * @param orgId
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
    public void advisors(String trackingId, String orgId) throws DataPublishingException, DataValidationException {


        try {
			params.put("trackingId", trackingId);
			params.put("orgId", orgId);

			AnalyticsEventWrapper wrapper = analyticsEventUtil.getEvent("sf-advisors-get").
			        setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper.add("orgId",orgId));
 
			String message = jsonUtility.getJsonStringFromObject(params);
			validate(templateId, templateName, message, wrapper);
			sendMessage(exchange, routingkey, message, wrapper);

			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.RECEIVED).setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
		} 
        catch ( DataValidationException e)
        {
        	throw e;
        }
        catch (DataProcessingException | AnalyticsEventPublisherException |JsonProcessingException e) {
			// TODO Auto-generated catch block
			throw new DataPublishingException (e);
		}

    }
    
    /**
     * 
     * @param templateId
     * @param templateName
     * @param message
     * @param wrapper
     * @throws DataValidationException
     * @throws DataPublishingException
     */

    private void validate(String templateId, String templateName,
                          String message, AnalyticsEventWrapper wrapper) throws DataValidationException, DataPublishingException {
        log.info("Start Validating Advisors request");

        eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.VALIDATING));

        List<ErrorBean> errors = new ArrayList<ErrorBean>();
        try {
            errors = validator.validate(templateId, templateName, new ByteArrayInputStream(message.getBytes()));
            if (!CollectionUtils.isEmpty(errors)) {
                log.info(" Validation errors : message(s)" + errors);
                eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
                throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
            }
            eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
            log.info(" No Validation Errors.  Sending message to queue");

        } catch (JsonValidationException e) {
            log.error("JsonValidationException occurs in AdvisorsServices", e);
            eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
            throw new DataPublishingException("JsonValidationException " + e.getMessage());
        } catch (DataValidationException e) {
            throw e;
        } catch (Exception e) {
            log.error("Exception occurs in AdvisorsServices ", e);
            eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
            throw new DataPublishingException("Internal Error " + e.getMessage());
        } finally {
            log.info("End AdvisorsServices");
        }

        return;
    }

    private void sendMessage(String exchange, String routingkey, String message, AnalyticsEventWrapper wrapper)
            throws DataValidationException, DataProcessingException, DataPublishingException,
            AnalyticsEventPublisherException {
        log.info("Start AdvisorsService.sendMessage");
        try {
            log.info(" No Validation Errors..Sending message to queue");
            eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.PUSHED_RMQ).
                    setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
            messageSender.send(exchange, routingkey, isPersistent, message);
            eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

            log.info("Sent message to queue");

        } catch (Exception e) {
            log.error("Exception occurs in AdvisorsServices", e);
            eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
            throw new DataPublishingException("Internal Error " + e.getMessage());
        } finally {
            log.info("End AdvisorsServices");
        }

        log.info("End of the sendMessage service");
        return;
    }


}
