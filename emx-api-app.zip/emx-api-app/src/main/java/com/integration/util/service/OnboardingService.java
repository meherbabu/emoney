package com.integration.util.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.integration.bean.common.ConvertErrorBean;
import com.integration.common.bean.TokenMappingBean;
import com.integration.common.bean.TokenMappingEmoneyBean;
import com.integration.common.bean.TokenMappingRootBean;
import com.integration.dao.CredentialKeysRepository;
import com.integration.dao.CredentialParamsRepository;
import com.integration.dao.CredentialRepository;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.model.Credential;
import com.integration.model.CredentialKeys;
import com.integration.model.CredentialParams;
import com.integration.model.SfOrgEmxOffMap;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.token.JWTTokenParams;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

@Service
public class OnboardingService {

	Log log = LoggerUtil.getLog(this);

	private JsonValidator validator;

	private JsonUtility jsonUtility;

	private CredentialRepository credentialRepository;

	private SforgEmxoffMapRepository sforgEmxoffMapRepository;

	private CredentialParamsRepository credentialParamsRepository;

	private CredentialKeysRepository credentialKeysRepository;

	private static String SALEFORCE = "Saleforce";

	private static String EMONEY = "Emoney";

	@Value("sf-onboarding-mapping")
	private String mappingId;

	@Autowired
	public OnboardingService(JsonValidator validator, JsonUtility jsonUtility,
			CredentialRepository credentialRepository, SforgEmxoffMapRepository sforgEmxoffMapRepository,
			CredentialParamsRepository credentialParamsRepository, CredentialKeysRepository credentialKeysRepository) {
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.credentialRepository = credentialRepository;
		this.sforgEmxoffMapRepository = sforgEmxoffMapRepository;
		this.credentialParamsRepository = credentialParamsRepository;
		this.credentialKeysRepository = credentialKeysRepository;

	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	public void create(String message) throws DataPublishingException, DataProcessingException, DataValidationException,
			AnalyticsEventPublisherException {
		validate(message);
		upcertDb(message);
	}

	/**
	 * 
	 * @param appId
	 * @return
	 */
	private TokenMappingBean getMapBean(String appId) {

		TokenMappingBean mappBean = new TokenMappingBean();
		mappBean.setName(appId);
		Credential credential = credentialRepository.findFirstByAppId(appId);

		List<CredentialParams> credentialParamsList = credentialParamsRepository
				.findAllByCredIdOrderById(credential.getId());

		mappBean.setParams(transformTokenParams(credentialParamsList));
		CredentialKeys tempRec = credentialKeysRepository.findFirstByName(appId);

		mappBean.getParams().setPrivateKey(tempRec.getPrivateKey());
		mappBean.getParams().setPublicKey(tempRec.getPublicKey());

		return mappBean;
	}

	/**
	 *
	 * @return
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	public StringBuffer get() throws DataPublishingException, DataProcessingException, DataValidationException,
			AnalyticsEventPublisherException {
		StringBuffer buffer = new StringBuffer();
		try {

			List<SfOrgEmxOffMap> list = sforgEmxoffMapRepository.findAllByOrderByOrgId();

			TokenMappingRootBean root = null;
			String tempOrgId = "";
			TokenMappingEmoneyBean tokenMappingEmoneyBean = null;
			List<TokenMappingRootBean> tokenMappingRootBeanList = new ArrayList<TokenMappingRootBean>();

			for (SfOrgEmxOffMap n : list) {
				boolean orgIdIsNotTheSame = (!tempOrgId.equals(n.getOrgId()));
				tempOrgId = n.getOrgId();
				// loop through the list.
				// if the org id is not the same build new grouping
				if (orgIdIsNotTheSame) {
					root = new TokenMappingRootBean();
					tokenMappingRootBeanList.add(root);
					root.setSaleforceTokenMappingBean(getMapBean(n.getOrgId()));
					root.seteMTokenMappingBean(new ArrayList<TokenMappingEmoneyBean>());
					tokenMappingEmoneyBean = new TokenMappingEmoneyBean();
					tokenMappingEmoneyBean.setEmoneyOffice(getMapBean(n.getEmxOffice()));
					root.geteMTokenMappingBean().add(tokenMappingEmoneyBean);
				} else {
					tokenMappingEmoneyBean = new TokenMappingEmoneyBean();
					tokenMappingEmoneyBean.setEmoneyOffice(getMapBean(n.getEmxOffice()));
					root.geteMTokenMappingBean().add(tokenMappingEmoneyBean);

				}

			}

			buffer.append(jsonUtility.getJsonStringFromObject(tokenMappingRootBeanList));
		} catch (Exception e) {
			throw new DataProcessingException("Exception in getAlldata " + e.getMessage());
		}
		return buffer;
	}

	/**
	 * 
	 * @param credentialParamsList
	 * @return
	 */
	private JWTTokenParams transformTokenParams(List<CredentialParams> credentialParamsList) {
		JWTTokenParams jWTTokenParams = new JWTTokenParams();

		for (CredentialParams cre : credentialParamsList) {
			try {
				if ("accessToken".equalsIgnoreCase(cre.getParamName())) {
					continue;
				}
				BeanUtils.setProperty(jWTTokenParams, cre.getParamName(), cre.getParamValue());
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jWTTokenParams;

	}

	/**
	 * 
	 * @param list
	 * @return
	 */
	private String combineStringList(List<String> list) {
		StringBuffer buffer = new StringBuffer();
		for (String value : list) {
			buffer.append(value);
		}
		return buffer.toString();

	}

	/**
	 * This method get new key for credential
	 * 
	 * @param name
	 * @param privateKey
	 * @return
	 */

	private CredentialKeys getCredentialKey(String name, String privateKey, String publicKey) {
		CredentialKeys key = credentialKeysRepository.findFirstByOrderByName();
		try {
			if (privateKey == null || privateKey.isEmpty()) {
				return key;
			}

			String myPrivateKey = privateKey;
			String myPublicKey = publicKey;

			CredentialKeys tempRec = credentialKeysRepository.findFirstByName(name);
			// if not find , create new entry
			if (tempRec == null) {
				tempRec = new CredentialKeys();
				tempRec.setName(name);
				tempRec.setPrivateKey(myPrivateKey);
				tempRec.setPublicKey(myPublicKey);
				key = credentialKeysRepository.save(tempRec);
				return key;

			}
			// if find , update key
			tempRec.setPrivateKey(myPrivateKey);
			tempRec.setPublicKey(myPublicKey);
			key = credentialKeysRepository.save(tempRec);
		} catch (Exception e) {

		}
		return key;
	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	private void upcertDb(String message) throws DataPublishingException, DataProcessingException,
			DataValidationException, AnalyticsEventPublisherException {

		try {

			// CredentialKeys key = credentialKeysRepository.findFirstByOrderByName();
			// if (key == null)
			// {
			// throw new DataValidationException("Must have at least on record in
			// Credential_key table");
			// }

			TokenMappingRootBean root = (TokenMappingRootBean) jsonUtility.getObjectFromJsonString(message,
					TokenMappingRootBean.class);

			List<SfOrgEmxOffMap> saveSfOrgEmxOffMapList = new ArrayList<SfOrgEmxOffMap>();
			if (root != null) {
				TokenMappingBean saleforceBean = root.getSaleforceTokenMappingBean();
				String orgId = saleforceBean.getName();
				JWTTokenParams sfParams = saleforceBean.getParams();
				Credential credentialBean = credentialRepository.findFirstByAppId(orgId);
				CredentialKeys key = getCredentialKey(orgId, sfParams.getPrivateKey(), sfParams.getPublicKey());
				sfParams.setPrivateKey(null);
				sfParams.setPublicKey(null);
				// if exist in credential do not create new one.
				if (credentialBean == null) {
					credentialBean = new Credential();
					credentialBean.setAppId(orgId);
					credentialBean.setAppName(SALEFORCE);
					/// set 1 for now. will get from id from credential_keys table
					credentialBean.setCredKeysId(key.getId());
					credentialBean = credentialRepository.save(credentialBean);
					// credentialBean.get
				}
				// update cred id reference
				else {
					credentialBean.setCredKeysId(key.getId());
					credentialBean = credentialRepository.save(credentialBean);

				}

				Long recordCount = credentialParamsRepository.deleteByCredId(credentialBean.getId());
				log.info("numbRecDeleted " + recordCount);
				List<CredentialParams> credentialParamsList = getCredentialParams(sfParams, credentialBean.getId());
				credentialParamsRepository.saveAll(credentialParamsList);

				List<TokenMappingEmoneyBean> emoneyBeans = root.geteMTokenMappingBean();

				for (TokenMappingEmoneyBean tokenMappingEmoneyBean : emoneyBeans) {
					TokenMappingBean bean = tokenMappingEmoneyBean.getEmoneyOffice();
					String emxOfficeName = bean.getName();
					String isActiveStr = String.valueOf(bean.isActive());
					JWTTokenParams params = bean.getParams();
					CredentialKeys officeKey = getCredentialKey(emxOfficeName, params.getPrivateKey(),
							params.getPublicKey());
					params.setPrivateKey(null);
					params.setPublicKey(null);

					SfOrgEmxOffMap emxOffBean = sforgEmxoffMapRepository.findByOrgIdAndEmxOffice(orgId, emxOfficeName);
					if (emxOffBean == null) {
						emxOffBean = new SfOrgEmxOffMap();
					}
					emxOffBean.setEmxOffice(emxOfficeName);
					if (StringUtils.isEmpty(isActiveStr) || "null".equalsIgnoreCase(isActiveStr)) {
						isActiveStr = "false";
					}
					emxOffBean.setIsActive(isActiveStr);
					emxOffBean.setOrgId(orgId);
					saveSfOrgEmxOffMapList.add(emxOffBean);
					
					
					// if exist in credential do not create new one.
					credentialBean = credentialRepository.findFirstByAppId(emxOfficeName);
					if (credentialBean == null) {
						credentialBean = new Credential();
						credentialBean.setAppId(emxOfficeName);
						credentialBean.setAppName(EMONEY);
						/// set 1 for now. will get from id from credential_keys table
						credentialBean.setCredKeysId(officeKey.getId());
						credentialBean = credentialRepository.save(credentialBean);
					}
					// update cred id reference
					else {
						credentialBean.setCredKeysId(officeKey.getId());
						credentialBean = credentialRepository.save(credentialBean);
					}

					recordCount = credentialParamsRepository.deleteByCredId(credentialBean.getId());
					log.info("numbRecDeleted " + recordCount);
					credentialParamsList = getCredentialParams(params, credentialBean.getId());
					credentialParamsRepository.saveAll(credentialParamsList);

				}
			}

			// if list is not empty , save all items at once.
			if (!saveSfOrgEmxOffMapList.isEmpty()) {
				sforgEmxoffMapRepository.saveAll(saveSfOrgEmxOffMapList);
			}

		} catch (IOException e) {
			log.error("IOException ", e);
			throw new DataProcessingException("IOException " + e.getMessage());
		} catch (Exception e) {
			log.error("Exception ", e);
			throw new DataProcessingException("Exception " + e.getMessage());
		}

	}

	/**
	 * 
	 * @param sfParams
	 * @param id
	 * @return
	 */
	private List<CredentialParams> getCredentialParams(JWTTokenParams sfParams, Long id) {

		// sfParams
		List<CredentialParams> paramsList = new ArrayList<CredentialParams>();
		try {

			String params = jsonUtility.getJsonStringFromObject(sfParams);
			Map<String, Object> value = jsonUtility.getMapFromJsonString(params);
			value.forEach((k, v) -> {
				CredentialParams l = new CredentialParams();
				l.setParamName(k);
				l.setParamValue(String.valueOf(v));
				l.setCredId(id);
				paramsList.add(l);
			});

		} catch (Exception e) {
			log.error("Exception in getCredentialParams ", e);
		}

		return paramsList;
	}

	/**
	 *
	 * @param message
	 * @throws DataValidationException
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	private void validate(String message) throws DataValidationException, DataProcessingException,
			DataPublishingException, AnalyticsEventPublisherException {
		log.info("Start OnboardingService.validate");

		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		try {
			errors = validator.validate(mappingId, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			log.info(" No Validation Errors.  Sending message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End MetaDataMappingServiceImpl.validate");
		}

		return;
	}
}
