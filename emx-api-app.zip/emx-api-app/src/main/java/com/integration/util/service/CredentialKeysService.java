package com.integration.util.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.integration.bean.common.ConvertErrorBean;
import com.integration.dao.CredentialKeysRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.model.CredentialKeys;
import com.integration.service.LoggerUtil;
import com.integration.service.validation.beans.ErrorBean;

@Service
public class CredentialKeysService {

	Log log = LoggerUtil.getLog(this);

	CredentialKeysRepository credentialKeysRepository;

	@Autowired
	public CredentialKeysService(CredentialKeysRepository credentialKeysRepository) {
		this.credentialKeysRepository = credentialKeysRepository;

	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	public void create(CredentialKeys message) throws DataPublishingException, DataProcessingException,
			DataValidationException, AnalyticsEventPublisherException {
		validate(message);
		upcertDb(message);
	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	public CredentialKeys get() throws DataPublishingException, DataProcessingException, DataValidationException,
			AnalyticsEventPublisherException {
		CredentialKeys keys = null;

		try {

			keys = credentialKeysRepository.findFirstByOrderByName();
			if (keys == null) {
				throw new DataValidationException("No record found");
			}

		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			throw new DataPublishingException("Internal Error " + e.getMessage());
		}
		return keys;
	}

	/**
	 * 
	 * @param message
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@Transactional
	private void upcertDb(CredentialKeys message) throws DataPublishingException, DataProcessingException,
			DataValidationException, AnalyticsEventPublisherException {

		try {
			CredentialKeys keys = credentialKeysRepository.findFirstByOrderByName();
			// if not null , update, else insert.
			if ( keys != null)
			{
				message.setId(keys.getId());
				message.setPrivateKey(message.getPrivateKey().trim());
				credentialKeysRepository.save(message);
				return;
			}
			credentialKeysRepository.save(message);
			

		} catch (Exception e) {
			log.error("Exception ", e);
			throw new DataProcessingException("Exception " + e.getMessage());
		}

	}

	/**
	 * 
	 * @param templateId
	 * @param templateName
	 * @param exchange
	 * @param routingkey
	 * @param message
	 * @return
	 * @throws Exception
	 */
	private void validate(CredentialKeys message) throws DataValidationException, DataProcessingException,
			DataPublishingException, AnalyticsEventPublisherException {
		log.info("Start OnboardingService.validate");

		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		try {
			if (StringUtils.isEmpty(message.getName())) {
				errors.add(new ErrorBean("name", " name cannot be empty or null"));
			}
			if (StringUtils.isEmpty(message.getPrivateKey())) {
				errors.add(new ErrorBean("privateKey", " privateKey cannot be empty or null"));
			}
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			log.info(" No Validation Errors.  Sending message to queue");

		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End MetaDataMappingServiceImpl.validate");
		}

		return;
	}
}
