package com.integration.util.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

@RestController
@RequestMapping (value="${util.context.validator}")

public class ValidateController extends AbstractRestHandler<Object> {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private JsonValidator validator;

	@Autowired
	public ValidateController(JsonValidator metaDataMappingService) {
		this.validator = metaDataMappingService;
	}

	/**
	 * 
	 * @param eMoneyClientRequest
	 * @param bindingResult
	 * @param request
	 * @param response
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */

	@RequestMapping( value= "/{mappingId}",
			method = RequestMethod.POST, 
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> create(@RequestBody String message, @PathVariable String mappingId) throws DataPublishingException,
			DataProcessingException, DataValidationException, AnalyticsEventPublisherException {
		log.info("Start MetaDataMappingController.create");

		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		try {
			errors = validator.validate(mappingId, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			log.info(" No Validation Errors.  Sending message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in MetaDataMappingServiceImpl.validate", e);
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End MetaDataMappingServiceImpl.validate");
		}
		log.info("End MetaDataMappingController.create");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "Mapping data are successfully updated."),
				HttpStatus.OK);
	}
	


}
