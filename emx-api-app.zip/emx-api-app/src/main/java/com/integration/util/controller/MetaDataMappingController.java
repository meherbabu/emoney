package com.integration.util.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.util.service.MetaDataMappingService;

@RestController
@RequestMapping (value="${util.context.mapping}")

public class MetaDataMappingController extends AbstractRestHandler<Object> {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private MetaDataMappingService metaDataMappingService;

	@Autowired
	public MetaDataMappingController(MetaDataMappingService metaDataMappingService) {
		this.metaDataMappingService = metaDataMappingService;
	}

	/**
	 * 
	 * @param eMoneyClientRequest
	 * @param bindingResult
	 * @param request
	 * @param response
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */

	@RequestMapping(
			method = RequestMethod.POST, 
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> create(@RequestBody String message) throws DataPublishingException,
			DataProcessingException, DataValidationException, AnalyticsEventPublisherException {
		log.info("Start MetaDataMappingController.create");

		metaDataMappingService.create(message);
		log.info("End MetaDataMappingController.create");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "Mapping data are successfully updated."),
				HttpStatus.OK);
	}
	
	
	/**
	 * 
	 * @param eMoneyClientRequest
	 * @param bindingResult
	 * @param request
	 * @param response
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */

	@RequestMapping(
			method = RequestMethod.GET,  
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> get() throws DataPublishingException,
			DataProcessingException, DataValidationException, AnalyticsEventPublisherException {
		log.info("Start MetaDataMappingController.create");

		StringBuffer buffer = metaDataMappingService.get();
		log.info("End MetaDataMappingController.create");
		return new ResponseEntity<Object>(buffer,
				HttpStatus.OK);
	}


}
