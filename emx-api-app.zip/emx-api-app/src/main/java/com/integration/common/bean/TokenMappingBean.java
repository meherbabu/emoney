package com.integration.common.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.integration.service.token.JWTTokenParams;

public class TokenMappingBean {

	@JsonProperty("name")
	private String name;
	
	@JsonProperty("isActive")
	private Boolean isActive;

	@JsonProperty("params")
	private JWTTokenParams params = new JWTTokenParams();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public JWTTokenParams getParams() {
		return params;
	}

	public void setParams(JWTTokenParams params) {
		this.params = params;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	

}
