package com.integration.common.service;

import java.util.Map;

import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

public interface ProcessMessageInterface {
	/**
	 * 
	 * @param message
	 * @param params
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
	void upcert(Object message, Map<String,String> params)
			throws DataPublishingException, DataValidationException;
	/**
	 * 
	 * @param message
	 * @param params
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
	void create(Object message, Map<String,String> params)
			throws DataPublishingException, DataValidationException;
	/**
	 * 
	 * @param message
	 * @param params
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
	void update(Object message, Map<String,String> params)
			throws DataPublishingException, DataValidationException;
	/**
	 * 
	 * @param message
	 * @param params
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
	void delete(Object message, Map<String,String> params)
			throws DataPublishingException, DataValidationException;
	
}
