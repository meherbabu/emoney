package com.integration.common.bean;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MetaDataRootMappingBean {

	@JsonProperty("mappings")
	private List<MetaDataMappingBean> mappings = new ArrayList<MetaDataMappingBean>();

	@JsonProperty("mappings")
	public List<MetaDataMappingBean> getMappings() {
		return mappings;
	}

	public void setMappings(List<MetaDataMappingBean> mappings) {
		this.mappings = mappings;
	}

}
