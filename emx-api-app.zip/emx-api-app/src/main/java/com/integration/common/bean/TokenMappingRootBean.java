package com.integration.common.bean;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TokenMappingRootBean {

	@JsonProperty("salesforce_org")
	private TokenMappingBean saleforceTokenMappingBean = new TokenMappingBean();

	@JsonProperty("emoney_offices")
	private List<TokenMappingEmoneyBean> eMTokenMappingBean = new ArrayList<TokenMappingEmoneyBean>();

	public TokenMappingBean getSaleforceTokenMappingBean() {
		return saleforceTokenMappingBean;
	}

	public void setSaleforceTokenMappingBean(TokenMappingBean saleforceTokenMappingBean) {
		this.saleforceTokenMappingBean = saleforceTokenMappingBean;
	}

	public List<TokenMappingEmoneyBean> geteMTokenMappingBean() {
		return eMTokenMappingBean;
	}

	public void seteMTokenMappingBean(List<TokenMappingEmoneyBean> eMTokenMappingBean) {
		this.eMTokenMappingBean = eMTokenMappingBean;
	}

}
