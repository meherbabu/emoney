package com.integration.common.bean;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.integration.model.SfEmxHeaderMap;
import com.integration.model.SfEmxMapping;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MetaDataMappingBean {
	@JsonProperty("org_object")
	private SfEmxHeaderMap sfEmxHeaderMap = new SfEmxHeaderMap();
	
	@JsonInclude(Include.NON_EMPTY)
	@JsonProperty("entity")
	private List<SfEmxMapping> sfEmxMapping = new ArrayList<SfEmxMapping>();

	@JsonProperty("org_object")
	public SfEmxHeaderMap getsF2EmxHeaderMapper() {
		return sfEmxHeaderMap;
	}

	public void setsF2EmxHeaderMapper(SfEmxHeaderMap sfEmxHeaderMap) {
		this.sfEmxHeaderMap = sfEmxHeaderMap;
	}

	@JsonProperty("entity")
	public List<SfEmxMapping> getSfEmxMapping() {
		return sfEmxMapping;
	}

	public void setSfEmxMapping(List<SfEmxMapping> sfEmxMapping) {
		this.sfEmxMapping = sfEmxMapping;
	}
}
