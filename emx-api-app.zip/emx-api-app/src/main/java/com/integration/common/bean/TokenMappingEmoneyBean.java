package com.integration.common.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TokenMappingEmoneyBean {

	@JsonProperty("emoney_office")
	private TokenMappingBean emoneyOffice;

	@JsonProperty("emoney_office")
	public TokenMappingBean getEmoneyOffice() {
		return emoneyOffice;
	}

	public void setEmoneyOffice(TokenMappingBean emoneyOffice) {
		this.emoneyOffice = emoneyOffice;
	}

}
