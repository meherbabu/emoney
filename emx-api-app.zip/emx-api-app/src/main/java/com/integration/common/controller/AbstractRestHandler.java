package com.integration.common.controller;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.integration.common.bean.RestErrorInfo;
import com.integration.exception.AbstractIntegrationException;
import com.integration.exception.DataFormatException;
import com.integration.exception.DataMappingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.exception.InsufficientAuthorizationException;
import com.integration.exception.ResourceNotFoundException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.JsonUtility;

/**
 * This class is meant to be extended by all REST resource "controllers".
 * It contains exception mapping and other common REST API functionality
 */
public abstract class AbstractRestHandler<T> implements ApplicationEventPublisherAware {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    protected ApplicationEventPublisher eventPublisher;

    protected static final String  DEFAULT_PAGE_SIZE = "100";
    protected static final String DEFAULT_PAGE_NUM = "0";

    @Autowired
    JsonUtility  jsonUtility;
    
    @Autowired
    AnalyticsEventPublisher analyticsEventPublisher;
    

	@ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({DataFormatException.class, 
             DataMappingException.class})
    public    
    ResponseEntity<RestErrorInfo>  handleDataException(
    		AbstractIntegrationException ex, WebRequest request, HttpServletResponse response) {
    	RestErrorInfo restErrorInfo = new RestErrorInfo();
        log.info("Converting exception to RestResponse : " + ex.getMessage());
        try {
        	String str = ex.getMessage();
        	ObjectMapper map=new ObjectMapper();
            JsonNode nodes=map.readTree(str);
            StringBuffer errStr = new StringBuffer();
            for (JsonNode node : nodes) {
            	errStr.append(node.path("errorDesc").asText());
            }
			restErrorInfo.setCode(400);
			restErrorInfo.setMessage(errStr.toString());
		} catch (Exception e) {
			restErrorInfo.setCode(400);
			restErrorInfo.setMessage("Error while JSON Conversion to ErrorData inside handleDataException :"+e);
			return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.BAD_REQUEST);
		}
      
        return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.BAD_REQUEST);
    }

	@ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler({ DataValidationException.class})
    public    
    ResponseEntity<RestErrorInfo>  handleValidationException(
    		AbstractIntegrationException ex, WebRequest request, HttpServletResponse response) {
    	RestErrorInfo restErrorInfo = new RestErrorInfo();
        log.info("Converting exception to RestResponse : " + ex.getMessage());
        try {
        	String str = ex.getMessage();
 			restErrorInfo.setCode(400);
			restErrorInfo.setMessage(str);
		} catch (Exception e) {
			restErrorInfo.setCode(400);
			restErrorInfo.setMessage("Error while JSON Conversion to ErrorData inside handleDataException :"+e);
			return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.BAD_REQUEST);
		}
      
        return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.BAD_REQUEST);
    }


    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler({DataPublishingException.class})
    public
    ResponseEntity<RestErrorInfo> handleProcessingException(
    		AbstractIntegrationException ex, WebRequest request, HttpServletResponse response) {
    	
    	RestErrorInfo restErrorInfo = new RestErrorInfo();
        log.info("Converting exception to RestResponse : " + ex.getMessage());
        try {
        	String str = ex.getMessage();
        	ObjectMapper map=new ObjectMapper();
            JsonNode nodes=map.readTree(str);
            String errStr = null;
            for (JsonNode node : nodes) {
            	errStr = node.path("errorDesc").asText();
            }
			restErrorInfo.setCode(500);
			restErrorInfo.setMessage(errStr);
		} catch (Exception e) {
			restErrorInfo.setCode(500);
			restErrorInfo.setMessage("Error while JSON Conversion to ErrorData inside handleDataException :"+e);
			return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.INTERNAL_SERVER_ERROR);
		}
      
        return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.INTERNAL_SERVER_ERROR);
        
    }


    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler({InsufficientAuthorizationException.class})
    public
    ResponseEntity<RestErrorInfo> authorizonException(
    		AbstractIntegrationException ex, WebRequest request, HttpServletResponse response) {
    	RestErrorInfo restErrorInfo = new RestErrorInfo();
        log.info("Converting exception to RestResponse : " + ex.getMessage());
        try {
        	String str = ex.getMessage();
        	ObjectMapper map=new ObjectMapper();
            JsonNode nodes=map.readTree(str);
            String errStr = null;
            for (JsonNode node : nodes) {
            	errStr = node.path("errorDesc").asText();
            }
			restErrorInfo.setCode(401);
			restErrorInfo.setMessage(errStr);
		} catch (Exception e) {
			restErrorInfo.setCode(401);
			restErrorInfo.setMessage("Error while JSON Conversion to ErrorData inside handleDataException :"+e);
			return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.UNAUTHORIZED);
		}
      
        return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.UNAUTHORIZED);
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(ResourceNotFoundException.class)
    public
    ResponseEntity<RestErrorInfo> handleResourceNotFoundException(
    		ResourceNotFoundException ex, WebRequest request, HttpServletResponse response) {
    	
    	RestErrorInfo restErrorInfo = new RestErrorInfo();
        log.info("Converting exception to RestResponse : " + ex.getMessage());
        try {
        	String str = ex.getMessage();
        	ObjectMapper map=new ObjectMapper();
            JsonNode nodes=map.readTree(str);
            String errStr = null;
            for (JsonNode node : nodes) {
            	errStr = node.path("errorDesc").asText();
            }
			restErrorInfo.setCode(404);
			restErrorInfo.setMessage(errStr);
		} catch (Exception e) {
			restErrorInfo.setCode(404);
			restErrorInfo.setMessage("Error while JSON Conversion to ErrorData inside handleDataException :"+e);
			return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.NOT_FOUND);
		}
      
        return new ResponseEntity<RestErrorInfo>(restErrorInfo, HttpStatus.NOT_FOUND);
        
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.eventPublisher = applicationEventPublisher;
    }


    public AnalyticsEventPublisher getAnalyticsEventPublisher() {
        return analyticsEventPublisher;
    }

    public void setAnalyticsEventPublisher(AnalyticsEventPublisher analyticsEventPublisher) {
        this.analyticsEventPublisher = analyticsEventPublisher;
    }


}