package com.integration.common.service;

import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class SfNoteCommonService {

    Log log = LogFactory.getLog(SfNoteCommonService.class);
    public String getMessageParamsFromMessage(String message) {
        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode jsonNode = null;
        try {
            log.debug("message  from client" +message.getBytes());
            jsonNode = objectMapper.readTree(message);
            String trackingID = jsonNode.get("trackingID").textValue();
            log.debug("trackingId"+ trackingID );
            return trackingID;
        } catch (IOException e) {
            e.printStackTrace();
        }
       return null;
    }
}
