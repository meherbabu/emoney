package com.integration.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.common.service.APIServiceHealth;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1")
public class HealthController extends AbstractRestHandler<Object> {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private APIServiceHealth aPIServiceHealth;

	@Autowired
	public HealthController(APIServiceHealth aPIServiceHealth) {

		this.aPIServiceHealth = aPIServiceHealth;
	}

	@RequestMapping(method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	public String query(HttpServletRequest request, HttpServletResponse response)
			throws DataPublishingException, DataProcessingException, DataValidationException {
		return "{message: GET is NOT ALLOWED}";
	}

	@RequestMapping(value = "/health", method = RequestMethod.GET, produces = { "application/json", "application/xml" })
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Test", notes = "TEST")
	public @ResponseBody ResponseEntity<?> getHeath(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		return new ResponseEntity<Object>(aPIServiceHealth.health(), HttpStatus.OK);
	}
}
