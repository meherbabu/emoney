package com.integration.emx.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

@RestController
@RequestMapping(value = "${emx.context.clients}")
public class EmxClientController extends AbstractRestHandler<Object> {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private ProcessMessageInterface emxClientService;


	@Autowired
	public EmxClientController( @Qualifier ("EmxClientServiceImpl") ProcessMessageInterface emxClientService) {
		this.emxClientService = emxClientService;
	}

	/**
	 * 
	 * @param eMoneyClientRequest
	 * @return
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@RequestMapping(
			method = RequestMethod.POST, 
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> create(@RequestBody String eMoneyClientRequest)
			throws DataPublishingException, DataValidationException{
		log.info("***********Inside Create Client Controller - EMX to SF Flow Starting************");

		emxClientService.create(eMoneyClientRequest, null);
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received create Client request."),
				HttpStatus.CREATED);
	}

	/**
	 * 
	 * @param clientId
	 * @param trackingId
	 * @param orgId
	 * @param office
	 * @return
	 * @throws DataValidationException
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	@DeleteMapping(value = "/{clientId}",
			   params = { "trackingId", "office"},	          
			produces = { APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public ResponseEntity<?> delete(@PathVariable String clientId,
			@RequestParam(value = "trackingId", required = true) String trackingId,
			//@RequestParam(value = "orgId", required = true) String orgId,
			@RequestParam(value = "office", required = true) String office) 
					throws DataValidationException, DataPublishingException {

		log.info("*** Inside Delete Client Controller ***" + clientId);
		Map<String, String> map = new HashMap<String, String>();
		map.put("clientId", clientId);
		map.put("trackingId", trackingId);
		//map.put("orgId", orgId);
		map.put("office", office);
		
		emxClientService.delete(null,map);

		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.NO_CONTENT.toString(), "IS has received delete Client request."),
				HttpStatus.NO_CONTENT);

	}
	
	/**
	 * 
	 * @param message
	 * @param request
	 * @param response
	 * @return
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 * @throws AnalyticsEventPublisherException
	 */
	@PutMapping(
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = { APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> update(@RequestBody String message) 
			throws DataPublishingException,DataValidationException
	{
		log.info("Start EmxClientController.updateClient");
		
		emxClientService.update(message, null);
		log.info("End EmxClientController.updateClient");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received update Client request."),
				HttpStatus.OK);
	}	

}
