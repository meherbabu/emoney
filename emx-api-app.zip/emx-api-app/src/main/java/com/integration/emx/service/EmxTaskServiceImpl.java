package com.integration.emx.service;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.emx.EmxSFTaskPiiDataImpl;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

/*
 * Service to Process a Create Clients Request From Sales Force
 */
@Service
@Qualifier ("EmxTaskServiceImpl")
public class EmxTaskServiceImpl implements ProcessMessageInterface {

	Log log = LoggerUtil.getLog(this);

	@Value("${mq.emx.task.create.exchange}")
	private String createExchange;

	@Value("${mq.emx.task.create.routingkey}")
	private String createRoutingkey;
	
	@Value("${mq.emx.task.create.persistence: false}")
	private boolean isEmxCreateTaskPersistent;

	@Value("${mq.emx.task.update.exchange}")
	private String updateExchange;

	@Value("${mq.emx.task.update.routingkey}")
	private String updateRoutingkey;
	
	@Value("${mq.emx.task.update.persistence: false}")
	private boolean isEmxUpdateTaskPersistent;


	@Value("${mq.emx.task.delete.exchange}")
	private String deleteExchange;

	@Value("${mq.emx.task.delete.routingkey}")
	private String deleteRoutingkey;
	
	@Value("${mq.emx.task.delete.persistence: false}")
	private boolean isEmxDeleteTaskPersistent;


	@Value("${validator.emx.task.create.template.name}")
	private String createTaskTemplateName;

	@Value("${validator.emx.task.create.template.id}")
	private String createTaskTemplateId;

	@Value("${validator.emx.task.update.template.name}")
	private String updateTaskTemplateName;

	@Value("${validator.emx.task.update.template.id}")
	private String updateTaskTemplateId;

	@Value("${validator.emx.task.delete.template.name}")
	private String deleteTaskTemplateName;

	@Value("${validator.emx.task.delete.template.id}")
	private String deleteTaskTemplateId;

	private MessageSender emxMessageSender;

	private JsonValidator validator;

	private JsonUtility jsonUtilService;

	private AnalyticsEventUtil analyticsEventUtil;

	private AnalyticsEventPublisher eventPublisher;
	
	private EmxToSfCommonUtil commonUtils;
	
	private PiiDataLog piiDataLog;

	@Autowired
	public EmxTaskServiceImpl(MessageSender emxMessageSender, JsonValidator validator,
			JsonUtility jsonUtilService, AnalyticsEventUtil analyticsEventUtil,
			AnalyticsEventPublisher eventPublisher,
			EmxToSfCommonUtil commonUtils, EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl) {
		this.emxMessageSender = emxMessageSender;
		this.validator = validator;
		this.jsonUtilService = jsonUtilService;
		this.eventPublisher = eventPublisher;
		this.analyticsEventUtil = analyticsEventUtil;
		this.commonUtils = commonUtils;
		this.piiDataLog = emxSfTaskPiiDataImpl;
	}

	/**
	 * 
	 * @param name
	 * @return
	 * @throws AnalyticsEventPublisherException
	 */
	private AnalyticsEventWrapper getEvent(String name) throws AnalyticsEventPublisherException {
		try {
			return analyticsEventUtil.getEvent(name);
		} catch (Exception e) {

			throw new AnalyticsEventPublisherException("Exception in getEvent eventName[ "+name+"]" + e.getMessage());
		}

	}
	
	@Override
	public void create(Object object, Map<String, String> params)
			throws DataValidationException, DataPublishingException {
		 EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl = (EmxSFTaskPiiDataImpl) piiDataLog;
		AnalyticsEventWrapper wrapper = null;
		try {
		
			String message = String.valueOf(object);
			String trackingId = commonUtils.getTrackingIdEmxTask(message);
			//String orgId = params.get("orgId"); //Newly added 
			//emxSfTaskPiiDataImpl.setPiiData(orgId, null,null,null, null,null);
			wrapper = getEvent("emx-task-create").setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			validate(createTaskTemplateId, createTaskTemplateName, message, wrapper);
			List<Object[]> list = commonUtils.splitEmxTaskMessage(message);
			//new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer }
			for (Object[] objects : list) {				
				String clientId = String.valueOf(objects[0]);
				String eMoneyTaskId = String.valueOf(objects[1]);
				String messageId = commonUtils.getEmoneyTaskMessageIdEmxClient(message) ;
				String assignedTo = String.valueOf(objects[2]);    ///Correction for variable value of assigned to 
				String taskId = String.valueOf(objects[4]);
				wrapper = wrapper.setClientIdValue(clientId);
				wrapper = wrapper.setAdditionalPropertyValue(eMoneyTaskId,objects[1]) ;				
				//String  messageId = String.valueOf(objects[3]);   //Newly added 
				//wrapper = wrapper.setMessageIdValue(messageId) ; //Newly added
				wrapper = wrapper.setAdditionalPropertyValue(assignedTo, objects[2]); //Newly added
				emxSfTaskPiiDataImpl.setPiiData(taskId, null, clientId, eMoneyTaskId, messageId, assignedTo);
				
				sendMessage(createExchange, createRoutingkey, isEmxCreateTaskPersistent, String.valueOf(objects[5]), wrapper);				
			}
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED));
		} catch (DataProcessingException  | AnalyticsEventPublisherException e ) {
			wrapper.error(e.getMessage());
			throw new DataPublishingException (" Exception " + e.getMessage());
		} catch (DataValidationException e) {
			wrapper.error(e.getMessage());
			throw e;
		}

	}

	@Override
	public void update(Object object, Map<String,String> params) throws DataValidationException, DataPublishingException{
		
		AnalyticsEventWrapper wrapper = null;
		EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl = (EmxSFTaskPiiDataImpl) piiDataLog;
		try {
			String message = String.valueOf(object);
			String trackingId = commonUtils.getTrackingIdEmxTask(message);
			// Get event task
			wrapper = getEvent("emx-task-update").setTrackingIdValue(trackingId);	
			eventPublisher.publish(wrapper);		
			// Validate message;
			validate(updateTaskTemplateId, updateTaskTemplateName,message,wrapper)	;	
			// Slit the message
			List<Object[]> list = commonUtils.splitEmxTaskMessage(message);
			//new Object[] { clientId, eMoneyTaskId, assignedTo, messageTXT, taskId, buffer }
			for (Object[] objects : list) {
				String clientId = String.valueOf(objects[0]);
				wrapper = wrapper.setClientIdValue(clientId);
				String eMoneyTaskId = String.valueOf(objects[1]); //Newly added
				wrapper = wrapper.setAdditionalPropertyValue(eMoneyTaskId,objects[1]) ;	
				String assignedTo = String.valueOf(objects[2]);  //Newly added
			    String messageId = commonUtils.getEmoneyTaskMessageIdEmxClient(message) ;   //Newly added 
				String taskId = String.valueOf(objects[4]);       //Newly added 
				wrapper = wrapper.setMessageIdValue(messageId) ; //Newly added				
				wrapper = wrapper.setAdditionalPropertyValue(assignedTo, objects[2]); //Newly added
				emxSfTaskPiiDataImpl.setPiiData(trackingId,null,clientId,eMoneyTaskId,messageId,assignedTo); //Newly added 
				
				sendMessage(updateExchange, updateRoutingkey, isEmxUpdateTaskPersistent, String.valueOf(objects[5]),wrapper);			
			}
			eventPublisher.publish(wrapper.setTrackingIdValue("").success(EnumEventCurrentStatus.RECEIVED));	
			
		}catch (DataProcessingException  | AnalyticsEventPublisherException e ) {
			wrapper.error(e.getMessage());
			throw new DataPublishingException (" Exception " + e.getMessage());
		} catch (DataValidationException e) {
			wrapper.error(e.getMessage());
			throw e;
		}
	}

	@Override
	public void delete(Object object, Map<String, String> map) throws DataValidationException, DataPublishingException{
		AnalyticsEventWrapper wrapper = null;
		EmxSFTaskPiiDataImpl emxSfTaskPiiDataImpl = (EmxSFTaskPiiDataImpl) piiDataLog;//Newly added 
		try {
			String trackingId = map.get("trackingId");
			String taskId = map.get("taskId");   //Newly added 

			wrapper = getEvent("emx-task-delete").setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);

			String message = jsonUtilService.getJsonStringFromObject(map);
			validate(deleteTaskTemplateId, deleteTaskTemplateName, message, wrapper);
			emxSfTaskPiiDataImpl.setPiiData(taskId,null,null,null,null,null);//Newly added changed
			sendMessage(deleteExchange, deleteRoutingkey, isEmxDeleteTaskPersistent, message, wrapper);

			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED));
		} 
		catch ( AnalyticsEventPublisherException | JsonProcessingException e ) {
			eventPublisher.publish(wrapper.error(e.getMessage()));
			throw new DataPublishingException (" Exception " + e.getMessage());
		} catch (DataValidationException e) {
			eventPublisher.publish(wrapper.error(e.getMessage()));
			throw e;
		}		

	}

	/**
	 *
	 * @param templateId
	 * @param templateName
	 * @param message
	 * @param wrapper
	 * @throws DataValidationException
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	private void validate(String templateId, String templateName, 
			String message, AnalyticsEventWrapper wrapper) throws DataValidationException, DataPublishingException {
		log.info("Start EmxTaskServiceImpl.validateAndSend");

		eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));

		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		try {
			errors = validator.validate(templateId, templateName, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());
				
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.success());
			log.info(" No Validation Errors.  Sending message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EmxTaskServiceImpl.validateAndSend"  + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());			
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EmxTaskServiceImpl.validateAndSend" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EmxTaskServiceImpl.update");
		}

		return;
	}

	/**
	 *
	 * @param exchange
	 * @param routingkey
	 * @param message
	 * @param wrapper
	 * @throws DataValidationException
	 * @throws DataProcessingException
	 * @throws DataPublishingException
	 * @throws AnalyticsEventPublisherException
	 */
	private void sendMessage(String exchange, String routingkey, boolean isPersistent, String message, AnalyticsEventWrapper wrapper) 
			throws DataPublishingException {
		log.info("Start EmxTaskServiceImpl.validateAndSend");
		try {
			log.info(" No Validation Errors.  Sending message to queue");
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.PUSHED_RMQ).
					setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
			emxMessageSender.send(exchange, routingkey, isPersistent, message);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

			log.info("Sent message to queue");

		} catch (Exception e) {
			log.error("Exception occurs in EmxTaskServiceImpl.validateAndSend"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EmxTaskServiceImpl.update");
		}

		log.info("End EmxTaskServiceImpl.validateAndSend");
		return;
	}
	
	@Override
	public void upcert(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}

}
