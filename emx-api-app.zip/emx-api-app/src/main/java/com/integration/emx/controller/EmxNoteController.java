package com.integration.emx.controller;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

@RestController
@RequestMapping(value = "${emx.context.notes}")
public class EmxNoteController extends AbstractRestHandler<Object>{

	private ProcessMessageInterface emxNotesService;
	
	
	@Autowired
	public EmxNoteController(
			@Qualifier("EmxNotesServiceImpl") ProcessMessageInterface emxNotesService) {
		this.emxNotesService = emxNotesService;
		
	}

	/**
	 *
	 * @param message
	 * @return
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 */
	@RequestMapping(
			method = RequestMethod.POST, 
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> createNote(@RequestBody String message) 
			throws DataPublishingException, DataValidationException {
			
		log.info("Start NoteController.createNote");
		emxNotesService.create(message, null);
		log.info("End NoteController.createNote");

		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received create Notes request."),
				HttpStatus.CREATED);

	}

	/**
	 *
	 * @param message
	 * @return
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 */
	@RequestMapping(
			method = RequestMethod.PUT, 
			consumes = { APPLICATION_JSON_VALUE }, 
			produces = {APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> updateNote(@RequestBody String message) throws DataPublishingException, DataValidationException  {
		
		log.info("Start NoteController.updateNote");
		emxNotesService.update(message, null);
		log.info("End NoteController.updateNote");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received update Notes request."),
				HttpStatus.OK);

	}

	@RequestMapping(
			value = "/clients/{eMoneyId}/notes/{eMoneyNoteId}",
			method = RequestMethod.DELETE, 
			produces = { APPLICATION_JSON_VALUE })
	    public ResponseEntity<Object> deleteNotes(@PathVariable(value = "eMoneyId", required = true) String clientId ,
												  @PathVariable(value = "eMoneyNoteId",  required = true) String noteId,
                                                  @RequestParam(value = "trackingId", required = true) String trackingId,
												  @RequestParam(value = "office", required = true) String office) 
														  throws DataPublishingException, DataValidationException {
		
		Map<String, String> params = new HashMap<>();
		params.put("eMoneyId", clientId);
		params.put("eMoneyNoteId", noteId);
		params.put("trackingId", trackingId);
		params.put("office", office);

		emxNotesService.delete(null, params);
		return new ResponseEntity<Object>(
				new ResponseMessageBean("204", "IS has received delete Notes request."),HttpStatus.NO_CONTENT
		);
	}

}


	
	


