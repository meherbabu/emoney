package com.integration.emx.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.common.OperationTypes;
import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.APIServiceHealth;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "${emx.context.alerts}")
public class EmxAlertsController extends AbstractRestHandler<Object> {

protected final Logger log = LoggerFactory.getLogger(this.getClass());

	private APIServiceHealth aPIServiceHealth; 
	
    private ProcessMessageInterface alertService;

    @Autowired
    public EmxAlertsController(@Qualifier ("EmxAlertsServiceImpl") ProcessMessageInterface alertService,
    		APIServiceHealth aPIServiceHealth) {
    	
		this.alertService = alertService;
		this.aPIServiceHealth = aPIServiceHealth;
	}
    /**
     *
     * @param emoneyAlertsAnalyticsEvent
     * @param request
     * @param response
     * @return
     * @throws DataPublishingException
     * @throws DataProcessingException
     * @throws DataValidationException
     * @throws AnalyticsEventPublisherException
     */
    @RequestMapping(
            method = RequestMethod.POST,
            consumes = {APPLICATION_JSON_VALUE},
            produces = {APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> createAlert(@RequestBody String emoneyAlertsAnalyticsEvent) 
			throws DataPublishingException, DataValidationException{		
		log.info("*** Inside Create Client Controller ***");
		Map<String, String> params = new HashMap<String, String>();
		params.put("OperationTypes", OperationTypes.CREATE.toString());

		this.alertService.upcert(emoneyAlertsAnalyticsEvent, params);
    	return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received create Alert request."),
				HttpStatus.CREATED);    	
   	
    }

    /**
     * 

     * @param request
     * @param response
     * @throws DataPublishingException
     * @throws DataProcessingException
     * @throws DataValidationException
     * @throws AnalyticsEventPublisherException 
     */
   @RequestMapping(
            method = RequestMethod.PUT,
            consumes = {APPLICATION_JSON_VALUE},
            produces = {APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> updateAlert(@RequestBody String emoneyAlertsAnalyticsEvent) throws DataPublishingException, DataValidationException{
	   
    	log.info("*** Inside Update Client Controller ***");
		Map<String, String> params = new HashMap<String, String>();
		params.put("OperationTypes", OperationTypes.UPDATE.toString());

		alertService.upcert(emoneyAlertsAnalyticsEvent, params);
	   	return new ResponseEntity<Object>(
					new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received update  Alert request."),
					HttpStatus.OK);
    	
    }
   
   /**
    *
    * @param request
    * @param response
    * @throws DataPublishingException
    * @throws DataProcessingException
    * @throws DataValidationException
 * @throws AnalyticsEventPublisherException 
    */
  @RequestMapping(
		   value="/{clientId}",
		   params = { "trackingId", "office"},
           method = RequestMethod.DELETE)
   @ResponseStatus(HttpStatus.NO_CONTENT)
   public ResponseEntity<?> deleteAlert(
		   @PathVariable String clientId,
		   @RequestParam(value = "trackingId", required = true) String trackingId,
		   //@RequestParam(value = "orgId", required = true) String orgId,
		   @RequestParam(value = "office", required = true) String office)
					throws DataPublishingException, DataValidationException{ 
	  
		Map<String, String> map = new HashMap<String, String>();
		map.put("clientId", clientId);
		map.put("trackingId", trackingId);
		//map.put("orgId", orgId);
		map.put("office", office);
	   	log.info("*** Inside Delete Alert Controller ***");
	   	alertService.delete(null,map);
	   	return new ResponseEntity<Object>(
					new ResponseMessageBean(HttpStatus.NO_CONTENT.toString(), "IS has received delete Alert request."),
					HttpStatus.NO_CONTENT);
	   	
   }
   
   @RequestMapping(
           method = RequestMethod.GET
       )
   @ResponseStatus(HttpStatus.FORBIDDEN)
   public String query(HttpServletRequest request, HttpServletResponse response) 
		   throws DataPublishingException, DataProcessingException, DataValidationException {
       return "{message: GET is NOT ALLOWED}";
   }


    @RequestMapping(value = "/health",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Test", notes = "TEST")
    public
    @ResponseBody
    ResponseEntity<?> getHeath(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ResponseEntity<Object>(
				aPIServiceHealth.health(),
				HttpStatus.OK);
    }
}
