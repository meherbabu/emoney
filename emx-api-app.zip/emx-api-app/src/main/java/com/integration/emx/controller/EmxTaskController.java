package com.integration.emx.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.integration.bean.emx.ResponseMessageBean;
import com.integration.common.controller.AbstractRestHandler;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;

@RestController
@RequestMapping(value = "${emx.context.tasks}")
public class EmxTaskController extends AbstractRestHandler<Object> {

	//EmxTaskService emxTaskService;
	
	private ProcessMessageInterface processMessageInterface;
	
	
	@Autowired
	public EmxTaskController(@Qualifier ("EmxTaskServiceImpl") ProcessMessageInterface processMessageInterface) {
		this.processMessageInterface = processMessageInterface;	
	}

	/**
	 *
	 * @param message
	 * @return
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 */
	@PostMapping (consumes = { APPLICATION_JSON_VALUE }, produces = { APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> create(@RequestBody String message)
			throws DataPublishingException, DataValidationException{

		log.info("Start EmxTaskController.create");
		processMessageInterface.create(message, null);
		log.info("End EmxTaskController.create");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.CREATED.toString(), "IS has received create task request."),
				HttpStatus.CREATED);
	}

	/**
	 *
	 * @param message
	 * @return
	 * @throws DataPublishingException
	 * @throws DataValidationException
	 */
	@PutMapping (consumes = { APPLICATION_JSON_VALUE }, produces = { APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> update(@RequestBody String message) throws DataPublishingException,  DataValidationException {

		log.info("Start EmxTaskController.update");
		processMessageInterface.update(message, null);
		log.info("End EmxTaskController.update");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.OK.toString(), "IS has received update task request"),
				HttpStatus.OK);
	}

	/**
	 * 
	 *
	 * @throws DataPublishingException
	 * @throws DataProcessingException
	 * @throws DataValidationException
	 */
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@DeleteMapping(value = "/{eMoneyTaskId}",produces = { APPLICATION_JSON_VALUE })
	public ResponseEntity<?> delete(@PathVariable (value = "eMoneyTaskId", required = true) String eMoneyTaskId,
			@RequestParam (value = "trackingId", required = true) String trackingId,
			@RequestParam (value = "office", required = true) String office )
			throws DataPublishingException, DataValidationException {

		log.info("*** Inside Update Client Controller  taskId ***[" + eMoneyTaskId+"]");
		log.info("*** Inside Update Client Controller  trackingId ***[" + trackingId+"]");
		log.info("*** Inside Update Client Controller  office ***[" + office+"]");
		log.info("Start EmxTaskController.updateClient");
		// create a map of value pair for simple validation.
		Map<String,String> map = new HashMap<String,String>();
		map.put("eMoneyTaskId", eMoneyTaskId);
		map.put("trackingId", trackingId);
		map.put("office", office);		
		processMessageInterface.delete(null,map);
		
		log.info("End EmxTaskController.delete");
		return new ResponseEntity<Object>(
				new ResponseMessageBean(HttpStatus.NO_CONTENT.toString(), "IS has received delete task request."),
				HttpStatus.NO_CONTENT);
	}

}
