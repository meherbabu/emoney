package com.integration.emx.service;


import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.common.OperationTypes;
import com.integration.bean.emx.EmxAlert;
import com.integration.bean.emx.EmxAlertsAnalyticsEvent;
import com.integration.bean.emx.EmxAlertwithMetadata;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataProcessingException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidatorImpl;
import com.integration.service.validation.beans.ErrorBean;

/*
 * Service to Process a Create Clients Request From Sales Force
 */
@Service
@Qualifier("EmxAlertsServiceImpl")
public class EmxAlertsServiceImpl implements ProcessMessageInterface{

	Log log = LoggerUtil.getLog(this);
    
    @Value("${mq.emx.alert.create.exchange}")
    private String exchange;

    @Value("${mq.emx.alert.create.routingkey}")
    private String routingkey;
    
    @Value("${mq.emx.alert.update.exchange}")
    private String updateExchange;

    @Value("${mq.emx.alert.update.routingkey}")
    private String updateRoutingkey;
    
    @Value("${mq.emx.alert.delete.exchange}")
    private String deleteExchange;

    @Value("${mq.emx.alert.delete.routingkey}")
    private String deleteRoutingkey;
    
	@Value("${validator.emx.client.delete.template.name}")
	private String deleteTemplateName;

	@Value("${validator.emx.client.delete.template.id}")
	private String deleteTemplateId;
	
	@Value("${mq.emx.alert.create.persistence:false}")
	private boolean isEmxCreateAlertPersistent;
	
	 @Value("${mq.emx.alert.update.persistence: false}")
	 private boolean isEmxUpdateAlertPersistent;
	 
	 @Value("${mq.emx.alert.delete.persistence: false}")
	 private boolean isEmxDeleteAlertPersistent;
    
	private MessageSender emxMessageSender;
    private JsonValidatorImpl validator;
    private JsonUtility jsonUtility;
    private AnalyticsEventUtil analyticsEventUtil;
    private AnalyticsEventPublisher eventPublisher;
    private SforgEmxoffMapRepository SforgEmxoffMapRepository;
    private EmxToSfCommonUtil commonUtils;

    
    
	@Autowired
	public EmxAlertsServiceImpl(MessageSender emxMessageSender, JsonValidatorImpl validator, JsonUtility jsonUtility,
			AnalyticsEventUtil analyticsEventUtil, AnalyticsEventPublisher eventPublisher, 
			SforgEmxoffMapRepository SforgEmxoffMapRepository, EmxToSfCommonUtil commonUtils) {
		this.emxMessageSender = emxMessageSender;
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.analyticsEventUtil = analyticsEventUtil;
		this.eventPublisher = eventPublisher;
		this.SforgEmxoffMapRepository = SforgEmxoffMapRepository;
		this.commonUtils = commonUtils;
	}

	@Override
	public void update(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void create(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// TODO Auto-generated method stub
		
	}

    /**
     * Create or Udpate a Client Request from Sales Force
     *
     * @param sfClientRequest  - Request From SF
     * @param operationType - Create or Update
     * @throws DataValidationException
     * @throws DataProcessingException
     * @throws DataPublishingException
     * @throws AnalyticsEventPublisherException 
     */
	@Override
	public void upcert(Object messagep, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
   	
		AnalyticsEventWrapper wrapper = null;  	
    	try {    	
    		String message = String.valueOf(messagep);    		
    		
    		String trackingId = commonUtils.getTrackingIdEmxClient(message);
    		wrapper = analyticsEventUtil.getEvent("emx-alert-create").setTrackingIdValue(trackingId);
    		
    		eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));
			List<ErrorBean> errors = validator.validate("emx-alerts-upcert",  new ByteArrayInputStream(message.getBytes()));    		
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.success());
    		
			EmxAlertsAnalyticsEvent emoneyAlertsAnalyticsEvent = 
					(EmxAlertsAnalyticsEvent)jsonUtility.getObjectFromJsonString(message, EmxAlertsAnalyticsEvent.class);
			
			OperationTypes operationTypes = OperationTypes.CREATE.toString().equalsIgnoreCase(params.get("OperationTypes"))? OperationTypes.CREATE: OperationTypes.UPDATE;
    		
    		if ( operationTypes ==  OperationTypes.UPDATE)
    		{
    			analyticsEventUtil.getEvent("emx-alert-update").setTrackingIdValue(emoneyAlertsAnalyticsEvent.getTrackingID());
    		}
			eventPublisher.publish(wrapper);
    		
			
     		//validation success, calling splitter 
     		messageSplitSendtoRMQ(emoneyAlertsAnalyticsEvent, operationTypes, wrapper);     		 
			
		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EMXClientServiceImpl.create", e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EMXClientServiceImpl.create", e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		}		
         
    }        

    /**
     * 
     * @param sfClientRequest
     * @param operationType
     * @throws DataPublishingException
     * @throws DataValidationException
     * @throws AnalyticsEventPublisherException 
     */
    @Transactional
	void messageSplitSendtoRMQ(EmxAlertsAnalyticsEvent emoneyAlertsAnalyticsEvent, OperationTypes operationType, AnalyticsEventWrapper wrapper)
			throws DataPublishingException, DataProcessingException, 
			DataValidationException, AnalyticsEventPublisherException {
    	EmxAlertsAnalyticsEvent emoneyAlertsAnalyticsEventObj = null;
		// Validation Passed now split and publish to RMQ
    	log.info("*** Splitting the request EMoneyAlertsAnalyticsEvent and calling Publisher for each Client ***");
    	// Splitter
    	 List<EmxAlertwithMetadata> emxAlertwithMetadataObjTemp =  emoneyAlertsAnalyticsEvent.getAlerts();
    	 if(emxAlertwithMetadataObjTemp!=null){
        	 EmxAlertwithMetadata emoneyAlertwithMetadata  = emxAlertwithMetadataObjTemp.get(0);
        	 EmxAlertwithMetadata emxAlertwithMetadataNewObj = new EmxAlertwithMetadata();
        	 emxAlertwithMetadataNewObj.setEMoneyAlertsMetadata(emoneyAlertwithMetadata.getEMoneyAlertsMetadata());
        	 emxAlertwithMetadataNewObj.setAlert(null);
        	// List<EmxAlert> emxAlertsListTemp = emoneyAlertwithMetadata.getAlert();
            for (EmxAlert emoneyAlert : emoneyAlertwithMetadata.getAlert()) {
            	List<EmxAlert> alertList = new ArrayList<EmxAlert>();
            	alertList.add(emoneyAlert);
            	emxAlertwithMetadataNewObj.setAlert(alertList);
         		wrapper.setStatusValue(EnumEventCurrentStatus.SPLITTING);
         		wrapper.setFinalStatusValue(EnumEventFinalStatus.PROCESSING);
         		eventPublisher.publish(wrapper);
            	try {
    	        	emoneyAlertsAnalyticsEventObj = new EmxAlertsAnalyticsEvent();
    	        	emoneyAlertsAnalyticsEventObj.setTrackingID(emoneyAlertsAnalyticsEvent.getTrackingID());
    	        	emoneyAlertsAnalyticsEventObj.setSourceSystem(emoneyAlertsAnalyticsEvent.getSourceSystem());
    	        	List<EmxAlertwithMetadata> emoneyAlertwithMetadataList = new ArrayList<EmxAlertwithMetadata>();
    	        	emoneyAlertwithMetadataList.add(emxAlertwithMetadataNewObj);
    	        	emoneyAlertsAnalyticsEventObj.setAlerts(emoneyAlertwithMetadataList);
    				
    	        	//for(EmxAlert emoneyAlert: emoneyAlertwithMetadata.getAlert()){
	        		wrapper.setAdditionalProperty("sourcesystem", emoneyAlertsAnalyticsEvent.getSourceSystem());	
	        		wrapper.setAdditionalProperty("office", emoneyAlertwithMetadata.getEMoneyAlertsMetadata().getOffice());
	        		wrapper.setAdditionalProperty("clientId", emoneyAlert.getClientId());
	        		wrapper.setAdditionalProperty("eMoneyId", emoneyAlert.geteMoneyId());
    	        //	}		        	
    	        	eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
    	        	
    	        	wrapper.setStatusValue(EnumEventCurrentStatus.PUSHED_RMQ);
    	        	eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.PROCESSING));	
    	        	//validate
    	 			// TODO validateIdForOperation(operationType, sfClientData, sfClientRequestSplit); 
    	        	//publishing Operation
    	        	String 	jsonMessage = jsonUtility.getJsonStringFromObject(emoneyAlertsAnalyticsEventObj);
    	 			if(operationType == OperationTypes.CREATE ){
    	 				log.info("*** calling pubslisher for Create ***");
    					emxMessageSender.send(exchange, routingkey, isEmxCreateAlertPersistent, jsonMessage);
    	 			}else{
    	 				log.info("*** calling pubslisher for Update ***");
    					emxMessageSender.send(updateExchange, updateRoutingkey, isEmxUpdateAlertPersistent, jsonMessage);
    	 			}
    				eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS)); 
    			} catch (Exception e) {
    				eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR)); 
    	 			throw new DataValidationException("INTERNAL SERVER ERROR :"+e.getMessage());
    			}
            }  
    	 }        
	}

	@Override
	public void delete(Object messagep, Map<String, String> params) throws DataPublishingException, DataValidationException {
		
		log.info("Start EmxAlertsServiceImpl.delete");
		AnalyticsEventWrapper wrapper = null;
		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		try {
			String orgID =null;
			String clientId = params.get("clientId");
			String trackingId = params.get("trackingId");
			String officeId = params.get("office");
			if(officeId!=null){
				orgID = this.SforgEmxoffMapRepository.findOrgId(officeId);
			}
			params.put("orgId", orgID);
			log.info("****** officeId::"+officeId+"<=>orgId::"+orgID);
			wrapper = analyticsEventUtil.getEvent("emx-alert-delete").setClientIdValue(clientId)
					.setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			
			String message = jsonUtility.getJsonStringFromObject(params);
			
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.VALIDATING).
					setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
			
			errors = validator.validate(deleteTemplateId, deleteTemplateName, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));

				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.VALIDATING).
					setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
			
			log.info(" No Validation Errors.  Sending message to queue");
			
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.PUSHED_RMQ).
					setFinalStatusValue(EnumEventFinalStatus.PROCESSING));
			emxMessageSender.send(deleteExchange, deleteRoutingkey, isEmxDeleteAlertPersistent, message);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));

			
			// reset the message to Receive Status
			eventPublisher.publish(wrapper.setStatusValue(EnumEventCurrentStatus.RECEIVED)
					.setFinalStatusValue(EnumEventFinalStatus.SUCCESS));
			
			log.info("Sent message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EmxAlertsServiceImpl.delete", e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));			
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EmxAlertsServiceImpl.delete", e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EmxAlertsServiceImpl.delete");
		}
		
	}

}
