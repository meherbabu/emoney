package com.integration.emx.service;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.EnumEventFinalStatus;
import com.integration.bean.emx.EmxSfClientPiiDataImpl;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.dao.SforgEmxoffMapRepository;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.bean.common.PiiDataLog;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

@Service
@Qualifier("EmxClientServiceImpl")
public class EmxClientServiceImpl implements ProcessMessageInterface {

	Log log = LoggerUtil.getLog(this);
	@Value("${mq.emx.client.create.exchange}")
	private String createEmxExchange;

	@Value("${mq.emx.client.create.routingkey}")
	private String createEmxRoutingkey;
	
	@Value("${mq.emx.client.create.persistence: false}")
	private boolean isCreateEmxPersistent;

	@Value("${mq.emx.client.update.exchange}")
	private String updateEmxExchange;

	@Value("${mq.emx.client.update.routingkey}")
	private String updateEmxRoutingkey;
	
	@Value("${mq.emx.client.update.persistence: false}")
	private boolean isUpdateEmxPersistent;

	@Value("${mq.emx.client.delete.exchange}")
	private String deleteEmxExchange;

	@Value("${mq.emx.client.delete.routingkey}")
	private String deleteEmxRoutingkey;
	
	@Value("${mq.emx.client.delete.persistence: false}")
	private boolean isDeleteEmxPersistent;

	@Value("${validator.emx.client.create.template.name}")
	private String createTemplateName;

	@Value("${validator.emx.client.create.template.id}")
	private String createTemplateId;

	@Value("${validator.emx.client.update.template.name}")
	private String updateTemplateName;

	@Value("${validator.emx.client.update.template.id}")
	private String updateTemplateId;

	@Value("${validator.emx.client.delete.template.name}")
	private String deleteTemplateName;

	@Value("${validator.emx.client.delete.template.id}")
	private String deleteTemplateId;

	private MessageSender messageSender;

	private JsonValidator validator;

	private JsonUtility jsonUtility;

	private AnalyticsEventPublisher eventPublisher;

	private AnalyticsEventUtil analyticsEventUtil;

	private EmxToSfCommonUtil commonUtils;
	
	private SforgEmxoffMapRepository SforgEmxoffMapRepository;
	
	
	private PiiDataLog piiDataLog;


 
	@Autowired
	public EmxClientServiceImpl(MessageSender emxMessageSender, JsonValidator validator,
			JsonUtility jsonUtility, AnalyticsEventPublisher eventPublisher, AnalyticsEventUtil analyticsEventUtil,
			EmxToSfCommonUtil commonUtils,SforgEmxoffMapRepository SforgEmxoffMapRepository,
			EmxSfClientPiiDataImpl emxSfClientPiiDataImpl ) {
		this.messageSender = emxMessageSender;
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.eventPublisher = eventPublisher;
		this.analyticsEventUtil = analyticsEventUtil;
		this.commonUtils = commonUtils;
		this.SforgEmxoffMapRepository = SforgEmxoffMapRepository;
	    this.piiDataLog	= emxSfClientPiiDataImpl; 	
    }

	@Override
	@Transactional
	public void create(Object messagep, Map<String, String> map)
			throws DataPublishingException, DataValidationException {
		log.info("Start EMXClientServiceImpl.create");
		EmxSfClientPiiDataImpl emxSfClientPiiDataImpl = (EmxSfClientPiiDataImpl) piiDataLog;
		AnalyticsEventWrapper wrapper = null;
		
		String message = String.valueOf(messagep);

		try {
			String trackingId = commonUtils.getTrackingIdEmxClient(message);
			wrapper = analyticsEventUtil.getEvent("emx-client-create").setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			// Validate messages
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));
			// Validation
			List<ErrorBean> errors = validator.validate(createTemplateId, createTemplateName,
					new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.VALIDATING));

			log.info(" No Validation Errors.  Sending message to queue");
			// Slit message in two and send it one by one
			// Object[messageId,emoneyId,"Slit message by Client"]
			List<Object[]> splitMessage = commonUtils.splitEmxClientMessage(message);
			for (Object[] objects : splitMessage) {
				emxSfClientPiiDataImpl.setPiiData(null, String.valueOf(objects[1]),String.valueOf(objects[0]));
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ)
						.setMessageIdValue(String.valueOf(objects[0]))
						.setAdditionalPropertyValue("emoneyId", objects[1]));

				messageSender.send(createEmxExchange, createEmxRoutingkey, isCreateEmxPersistent, String.valueOf(objects[2]));
				eventPublisher.publish(wrapper.success());

			}
			// reset the message to Receive Status
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED));

			log.info("Sent message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EMXClientServiceImpl.create " + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EMXClientServiceImpl.create" + piiDataLog.logPiiData(), e);
			
		
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EMXClientServiceImpl.create");
		}
	}

	

	@Override
	@Transactional
	public void update(Object messagep, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		log.info("Start EmxClientServiceImpl.update");
		AnalyticsEventWrapper wrapper = null;
		EmxSfClientPiiDataImpl emxSfClientPiiDataImpl = (EmxSfClientPiiDataImpl) piiDataLog;
		String message = String.valueOf(messagep);

		try {
			wrapper = analyticsEventUtil.getEvent("emx-client-update");
			
			List<ErrorBean> errors = validator.validate(updateTemplateId, updateTemplateName,
					new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			String trackingId = commonUtils.getTrackingIdEmxClient(message);
			eventPublisher.publish(wrapper.setTrackingIdValue(trackingId));
			// Validate messages
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.VALIDATING));
			log.info(" No Validation Errors.  Sending message to queue");
			// Slit message in two and send it one by one

			// Object[messageId,emoneyId,"Slit message by Client"]
			List<Object[]> splitMessage = commonUtils.splitEmxClientMessage(message);
			for (Object[] objects : splitMessage) {
				emxSfClientPiiDataImpl.setPiiData(null, String.valueOf(objects[1]),String.valueOf(objects[0]));
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ)
						.setMessageIdValue(String.valueOf(objects[0]))
						.setAdditionalPropertyValue("emoneyId", objects[1]));

				messageSender.send(updateEmxExchange, updateEmxRoutingkey, isUpdateEmxPersistent, String.valueOf(objects[2]));
				eventPublisher.publish(wrapper.success());

			}
			// reset the message to Receive Status
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED));

			log.info("Sent message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EMXClientServiceImpl.update" + piiDataLog.logPiiData(), e);
		
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EMXClientServiceImpl.update" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.setFinalStatusValue(EnumEventFinalStatus.ERROR));
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EMXClientServiceImpl.update");
		}
	}

	@Override
	@Transactional
	public void delete(Object messagep, Map<String, String> map)
			throws DataPublishingException, DataValidationException {

		log.info("Start EmxTaskServiceImpl.delete");
		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		AnalyticsEventWrapper wrapper = null;
		EmxSfClientPiiDataImpl emxSfClientPiiDataImpl = (EmxSfClientPiiDataImpl) piiDataLog;		
		String orgId =null;
		try {
			String clientId = map.get("clientId");
			String trackingId = map.get("trackingId");
			String officeId = map.get("office");
			emxSfClientPiiDataImpl.setPiiData(null, clientId, null);
			if(officeId!=null){			
				orgId = this.SforgEmxoffMapRepository.findOrgId(officeId);
			}
			map.put("orgId", orgId);
			wrapper = analyticsEventUtil.getEvent("emx-client-delete").setClientIdValue(clientId)
					.setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			String message = jsonUtility.getJsonStringFromObject(map);
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));
			// validation
			errors = validator.validate(deleteTemplateId, deleteTemplateName,
					new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());

				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			// success
			// error
			// processing
			
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.VALIDATING));

			log.info(" No Validation Errors.  Sending message to queue");

			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ));
			
			messageSender.send(deleteEmxExchange, deleteEmxRoutingkey, isDeleteEmxPersistent, message);
			
			eventPublisher.publish(wrapper.success());

			// reset the message to Receive Status
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED));

			log.info("Sent message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EmxTaskServiceImpl.delete"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EmxTaskServiceImpl.delete" + piiDataLog.logPiiData(), e);		
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EmxTaskServiceImpl.delete");
		}
	}


	@Override
	public void upcert(Object message, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
		// This method is not being used

	}

}
