package com.integration.emx.service;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.integration.bean.common.AnalyticsEventWrapper;
import com.integration.bean.common.ConvertErrorBean;
import com.integration.bean.common.EnumEventCurrentStatus;
import com.integration.bean.common.PiiDataLog;
import com.integration.bean.emx.EmxSfNotesPiiDataImpl;
import com.integration.common.service.ProcessMessageInterface;
import com.integration.exception.AnalyticsEventPublisherException;
import com.integration.exception.DataPublishingException;
import com.integration.exception.DataValidationException;
import com.integration.service.AnalyticsEventPublisher;
import com.integration.service.AnalyticsEventUtil;
import com.integration.service.EmxToSfCommonUtil;
import com.integration.service.JsonUtility;
import com.integration.service.LoggerUtil;
import com.integration.service.MessageSender;
import com.integration.service.validation.JsonValidationException;
import com.integration.service.validation.JsonValidator;
import com.integration.service.validation.beans.ErrorBean;

/**
 * @author arindamchakraborty
 *
 */

@Service
@Qualifier("EmxNotesServiceImpl")
public class EmxNotesServiceImpl implements ProcessMessageInterface{
	
	Log log = LoggerUtil.getLog(this);
	
	@Value("${mq.emx.notes.create.exchange}")
    private String createNoteExchange;
	
    @Value("${mq.emx.notes.create.routingkey}")
    private String createNoteRoutingkey;
    
    @Value("${mq.emx.notes.create.persistence: false}")
    private boolean isEmxCreateNotesPersistent;
    
    @Value("${mq.emx.notes.create.queue}")
    private String createNoteQueue;
    
    @Value("${mq.emx.notes.update.exchange}")
    private String updateNoteExchange;
    
    @Value("${mq.emx.notes.update.routingkey}")
    private String updateNoteRoutingkey;
    
    @Value("${mq.emx.notes.update.persistence: false}")
    private boolean isEmxUpdateNotesPersistent;
    
    @Value("${mq.emx.notes.update.queue}")
    private String updateNoteQueue;
    
    @Value("${mq.emx.notes.delete.exchange}")
    private String deleteNoteExchange;
    
    @Value("${mq.emx.notes.delete.routingkey}")
    private String deleteNoteRoutingkey;
    
    @Value("${mq.emx.notes.delete.persistence: false}")
    private boolean isEmxDeleteeNotesPersistent;
    
    @Value("${mq.emx.notes.update.queue}")
    private String deleteNoteQueue;
    
    @Value("${validator.emx.notes.create.template.name}")
    private String createTemplateName;
    
    @Value("${validator.emx.notes.create.template.id}")
    private String createTemplateId;
    
    @Value("${validator.emx.notes.update.template.name}")
    private String updateTemplateName;
    
    @Value("${validator.emx.notes.update.template.id}")
    private String updateTemplateId;

    @Value("${validator.emx.notes.delete.template.name}")
    private String deleteTemplateName;
    
    
    private MessageSender emxMessageSender;

	private JsonValidator validator;

	private JsonUtility jsonUtility;

	private AnalyticsEventPublisher eventPublisher;

	private AnalyticsEventUtil analyticsEventUtil;

	private EmxToSfCommonUtil commonUtils;
     
    private PiiDataLog  piiDataLog;  
    
    
    /* (non-Javadoc)
     * @see com.integration.service.notes.EMXNotesService#create(java.lang.String)
     */
    @Autowired
    public EmxNotesServiceImpl(MessageSender emxMessageSender, JsonValidator validator,
			JsonUtility jsonUtility, AnalyticsEventPublisher eventPublisher, AnalyticsEventUtil analyticsEventUtil,
			EmxToSfCommonUtil commonUtils,
			EmxSfNotesPiiDataImpl emxSfNotesPiiDataImpl) {
		this.emxMessageSender = emxMessageSender;
		this.validator = validator;
		this.jsonUtility = jsonUtility;
		this.eventPublisher = eventPublisher;
		this.analyticsEventUtil = analyticsEventUtil;
		this.commonUtils = commonUtils;
		this.piiDataLog = emxSfNotesPiiDataImpl;
	}

	@Override
	@Transactional
	public void create(Object messagep, Map<String, String> map) throws DataPublishingException, DataValidationException

    {
		log.info("Start EMXNotesServiceImpl.create");
		EmxSfNotesPiiDataImpl emxSfNotesPiiDataImpl = (EmxSfNotesPiiDataImpl) piiDataLog;
		AnalyticsEventWrapper wrapper = null;

		try {
			String message = String.valueOf(messagep);
			//String eMoneyId = map.get("eMoneyId"); //Newly added 
			//String noteId = map.get("noteId"); //Newly added 
			//emxSfNotesPiiDataImpl.setPiiData(eMoneyId,noteId);  //Newly added 
			String trackingId = commonUtils.getTrackingIdEmxClient(message);
			wrapper = analyticsEventUtil.getEvent("emx-note-create").setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			// Validate messages
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));
			List<ErrorBean> errors = validator.validate(createTemplateId, createTemplateName, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.VALIDATING));
			log.info(" No Validation Errors.  Sending message to queue");
			
			// Split message in two and send it one by one
			List<Object[]> splitMessage =  commonUtils.splitNoteMessage(message);			
			for (Object[] objects : splitMessage) {
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ).
						setClientIdValue(String.valueOf(objects[0])).
						setNoteIdValue(String.valueOf(objects[1])));
				//emxSfNotesPiiDataImpl.(String.valueOf(objects[0]), String.valueOf(objects[1])); //Newly added
				String emoneyid = commonUtils.getNoteEmoneyIDEmxClient(message);          //Newly added 
				String emoneynoteid = commonUtils.getNoteEmoneyNoteIDEmxClient(message);  //Newly added 
				emxSfNotesPiiDataImpl.setPiiData(emoneyid,emoneynoteid);   
				emxMessageSender.send(createNoteExchange, createNoteRoutingkey, isEmxCreateNotesPersistent, String.valueOf(objects[2]));
				eventPublisher.publish(wrapper.success());
			
			}
			// reset the message to Receive Status
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED).setMessageIdValue("").clearAdd());
			
			log.info("Sent message to queue");
			

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EMXNotesServiceImpl.create"  + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());			
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			log.error("DataValidationException occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EMXNotesServiceImpl.create" + piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EMXNotesServiceImpl.create");
		}
	}
    
    
    
    
    
    /* (non-Javadoc)
     * @see com.integration.service.notes.EMXNotesService#update(java.lang.String)
     */
    @Override
	@Transactional
	public void update(Object messagep, Map<String, String> params) throws DataPublishingException, DataValidationException {
		log.info("Start EMXNotesServiceImpl.update");
		AnalyticsEventWrapper wrapper = null;
		EmxSfNotesPiiDataImpl emxSfNotesPiiDataImpl = (EmxSfNotesPiiDataImpl) piiDataLog;

		try {
			String message = String.valueOf(messagep);
			String trackingId = commonUtils.getTrackingIdEmxClient(message);
			wrapper = analyticsEventUtil.getEvent("emx-note-update").setTrackingIdValue(trackingId);
			eventPublisher.publish(wrapper);
			// Validate messages
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.VALIDATING));
			//String eMoneyId = params.get("eMoneyId"); //Newly added
			//String noteId = params.get("noteId");  //Newly added 
			//emxSfNotesPiiDataImpl.setPiiData(eMoneyId, noteId);  //Newly added 
			
			List<ErrorBean> errors = validator.validate(updateTemplateId, updateTemplateName, new ByteArrayInputStream(message.getBytes()));
			if (!CollectionUtils.isEmpty(errors)) {
				log.info("Validation errors : message(s)" + errors);
				eventPublisher.publish(wrapper.error());
				throw new DataValidationException(new ConvertErrorBean(errors).getErrors());
			}
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.VALIDATING));
			log.info(" No Validation Errors.  Sending message to queue");
			
			// Slit message in two and send it one by one
			List<Object[]> splitMessage =  commonUtils.splitNoteMessage(message);			
			for (Object[] objects : splitMessage) {
				eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ).
						setClientIdValue(String.valueOf(objects[0])).
						setNoteIdValue(String.valueOf(objects[1])));
				//emxSfNotesPiiDataImpl.setPiiData(String.valueOf(objects[0]), String.valueOf(objects[1])); //Newly added 
				String emoneyid = commonUtils.getNoteEmoneyIDEmxClient(message);          //Newly added 
				String emoneynoteid = commonUtils.getNoteEmoneyNoteIDEmxClient(message);  //Newly added 
				emxSfNotesPiiDataImpl.setPiiData(emoneyid,emoneynoteid); 
				emxMessageSender.send(updateNoteExchange, updateNoteRoutingkey, isEmxUpdateNotesPersistent, String.valueOf(objects[2]));
				eventPublisher.publish(wrapper.success());
			
			}
			// reset the message to Receive Status
			eventPublisher.publish(wrapper.success(EnumEventCurrentStatus.RECEIVED).setMessageIdValue("").clearAdd());
		
			log.info("Sent message to queue");

		} catch (JsonValidationException e) {
			log.error("JsonValidationException occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());			
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		} catch (DataValidationException e) {
			log.error("DataValidationException occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			throw e;
		} catch (Exception e) {
			log.error("Exception occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());
			throw new DataPublishingException("Internal Error " + e.getMessage());
		} finally {
			log.info("End EMXNotesServiceImpl.update");
		}
	}
    

    @Override
	@Transactional
	public void delete(Object messagep, Map<String, String> params)
			throws DataPublishingException, DataValidationException {
    	
		AnalyticsEventWrapper wrapper = null;
		EmxSfNotesPiiDataImpl emxSfNotesPiiDataImpl = (EmxSfNotesPiiDataImpl) piiDataLog; //Newly added 
        try {
			log.info(params);
			wrapper = analyticsEventUtil.getEvent("emx-note-delete").setTrackingIdValue(params.get("trackingId") );			
			eventPublisher.publish(wrapper.processing(EnumEventCurrentStatus.PUSHED_RMQ).
					setClientIdValue(params.get("eMoneyId")).
					setNoteIdValue(params.get("eMoneyNoteId")));
			emxSfNotesPiiDataImpl.setPiiData(params.get("eMoneyId"),params.get("eMoneyNoteId") ); //Newly added 
			
			String message = jsonUtility.getJsonStringFromObject(params);
			emxMessageSender.send(deleteNoteExchange, deleteNoteRoutingkey, isEmxDeleteeNotesPersistent, message);
			
		} catch (JsonProcessingException | AnalyticsEventPublisherException e) {
			log.error("JsonProcessingException occurs in EMXNotesServiceImpl.update"+ piiDataLog.logPiiData(), e);
			eventPublisher.publish(wrapper.error());			
			throw new DataPublishingException("JsonValidationException " + e.getMessage());
		}

    }
    
    @Override
    public void upcert(Object message, Map<String, String> params)
    		throws DataPublishingException, DataValidationException {
    	// no needed for this task
    	
    }

}
